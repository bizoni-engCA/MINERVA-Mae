import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import 'dotenv/config';

process.env.NODE_ENV = 'test';
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://amparo:amparo@localhost:5432/amparo_test';
process.env.STORAGE_DIR = mkdtempSync(join(tmpdir(), 'amparo-test-storage-'));
process.env.SIGA_PROVIDER = 'mock';
process.env.SIGA_MOCK_ACEITAR_QUALQUER_DRE = 'true';
