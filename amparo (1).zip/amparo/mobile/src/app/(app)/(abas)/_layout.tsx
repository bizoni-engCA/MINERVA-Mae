import { View } from 'react-native';
import { router } from 'expo-router';
import { Tabs } from 'expo-router/js-tabs';
import { SaidaRapida } from '@/components/SaidaRapida';
import { BotaoIcone, Icone, type NomeIcone } from '@/components/ui';
import { ehEquipe, useSessao } from '@/store/sessao';
import { cores, fontes } from '@/theme';

const icone =
  (nome: NomeIcone) =>
  ({ color, focused }: { color: unknown; focused: boolean }) => (
    <Icone nome={(focused ? nome : `${nome}-outline`) as NomeIcone} cor={String(color)} tamanho={23} />
  );

export default function AbasLayout() {
  const equipe = ehEquipe(useSessao((s) => s.usuaria));
  return (
    <Tabs
      screenOptions={{
        headerStyle: { backgroundColor: cores.papel },
        headerShadowVisible: false,
        headerTitleStyle: { fontFamily: fontes.titulo, fontSize: 22, color: cores.tinta },
        headerTitleAlign: 'left',
        headerRight: () => (
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginRight: 12 }}>
            <BotaoIcone icone="settings-outline" rotulo="Ajustes" onPress={() => router.push('/ajustes')} />
            <SaidaRapida />
          </View>
        ),
        tabBarActiveTintColor: cores.lilas,
        tabBarInactiveTintColor: cores.nevoa,
        tabBarLabelStyle: { fontFamily: fontes.textoMedio, fontSize: 12 },
        tabBarStyle: { backgroundColor: cores.superficie, borderTopColor: cores.linha },
      }}
    >
      <Tabs.Screen name="inicio" options={{ title: 'Comunidades', tabBarIcon: icone('chatbubbles') }} />
      <Tabs.Screen name="videos" options={{ title: 'Vídeos', tabBarIcon: icone('play-circle') }} />
      <Tabs.Screen name="denuncia" options={{ title: 'Denúncia', tabBarIcon: icone('shield-checkmark') }} />
      <Tabs.Screen name="equipe" options={{ title: 'Equipe', tabBarIcon: icone('people'), href: equipe ? undefined : null }} />
    </Tabs>
  );
}
