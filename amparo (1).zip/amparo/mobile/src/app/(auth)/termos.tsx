import { Markdown } from '@/components/Markdown';
import { Tela } from '@/components/ui';
import { TERMOS } from '@/lib/termos';



export default function Termos() {
  return (
    <Tela>
      <Markdown texto={TERMOS} />
    </Tela>
  );
}
