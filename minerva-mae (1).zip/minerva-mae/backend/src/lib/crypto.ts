/**
 * Criptografia da Minerva Mãe.
 *
 * Modelo de chaves (envelope encryption):
 *  - MASTER_KEY (no .env, idealmente num cofre/KMS em produção) deriva duas chaves via HKDF:
 *      • chave de embrulho → protege as chaves individuais (DEKs)
 *      • chave de campo    → protege campos de texto avulsos (ex.: detalhes só para moderação)
 *  - Cada caso tem sua própria DEK (relato, mensagens, metadados das provas).
 *  - Cada prova tem sua própria DEK (o arquivo em si).
 *  - Tudo com AES-256-GCM (confidencialidade + detecção de adulteração).
 */
import {
  createCipheriv,
  createDecipheriv,
  createHash,
  createHmac,
  createPrivateKey,
  createPublicKey,
  hkdfSync,
  randomBytes,
  randomInt,
  sign,
  timingSafeEqual,
  verify,
  type KeyObject,
} from 'node:crypto';
import { config } from '../config';

const ALG = 'aes-256-gcm';
const masterKey = Buffer.from(config.MASTER_KEY, 'base64');
const derivar = (info: string) => Buffer.from(hkdfSync('sha256', masterKey, Buffer.alloc(0), info, 32));

const chaveEmbrulho = derivar('amparo:embrulho:v1');
const chaveCampo = derivar('amparo:campo:v1');

// ── Texto ─────────────────────────────────────────────────────────
function cifrar(texto: string, chave: Buffer): string {
  const iv = randomBytes(12);
  const c = createCipheriv(ALG, chave, iv);
  const ct = Buffer.concat([c.update(texto, 'utf8'), c.final()]);
  return ['v1', iv.toString('base64url'), c.getAuthTag().toString('base64url'), ct.toString('base64url')].join('.');
}

function decifrar(pacote: string, chave: Buffer): string {
  const [versao, iv, tag, ct] = pacote.split('.');
  if (versao !== 'v1' || !iv || !tag || ct === undefined) throw new Error('Formato criptografado desconhecido');
  const d = createDecipheriv(ALG, chave, Buffer.from(iv, 'base64url'));
  d.setAuthTag(Buffer.from(tag, 'base64url'));
  return Buffer.concat([d.update(Buffer.from(ct, 'base64url')), d.final()]).toString('utf8');
}

export const cifrarCampo = (texto: string) => cifrar(texto, chaveCampo);
export const decifrarCampo = (pacote: string) => decifrar(pacote, chaveCampo);

// ── Chaves individuais (DEK) ──────────────────────────────────────
export const gerarDek = () => randomBytes(32);
export const protegerDek = (dek: Buffer) => cifrar(dek.toString('base64'), chaveEmbrulho);
export const abrirDek = (protegida: string) => Buffer.from(decifrar(protegida, chaveEmbrulho), 'base64');

export const cifrarJson = (obj: unknown, dek: Buffer) => cifrar(JSON.stringify(obj), dek);
export const decifrarJson = <T>(pacote: string, dek: Buffer): T => JSON.parse(decifrar(pacote, dek)) as T;
export const cifrarTexto = (texto: string, dek: Buffer) => cifrar(texto, dek);
export const decifrarTexto = (pacote: string, dek: Buffer) => decifrar(pacote, dek);

// ── Arquivos (streams) ────────────────────────────────────────────
export function criarCifradorArquivo(dek: Buffer) {
  const iv = randomBytes(12);
  return { iv, cifrador: createCipheriv(ALG, dek, iv) };
}

export function criarDecifradorArquivo(dek: Buffer, ivB64: string, tagB64: string) {
  const d = createDecipheriv(ALG, dek, Buffer.from(ivB64, 'base64url'));
  d.setAuthTag(Buffer.from(tagB64, 'base64url'));
  return d;
}

// ── Hashes ────────────────────────────────────────────────────────
/** Hash irreversível de identificadores institucionais (DRE/SIAPE). */
export const hashIdentificador = (tipo: string, valor: string) =>
  createHmac('sha256', config.HASH_PEPPER).update(`${tipo}:${valor.trim()}`).digest('hex');

export const sha256 = (dado: string | Buffer) => createHash('sha256').update(dado).digest('hex');

export const tokenAleatorio = (bytes = 48) => randomBytes(bytes).toString('base64url');

export const codigoNumerico = (digitos = 6) =>
  String(randomInt(0, 10 ** digitos)).padStart(digitos, '0');

export function igualSeguro(a: string, b: string) {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  return ba.length === bb.length && timingSafeEqual(ba, bb);
}

// ── Links assinados para mídia ────────────────────────────────────
export function assinarUrlMidia(recurso: string, validadeSeg = 2 * 60 * 60) {
  const exp = Math.floor(Date.now() / 1000) + validadeSeg;
  const sig = createHmac('sha256', config.MEDIA_URL_SECRET).update(`${recurso}.${exp}`).digest('base64url');
  return { exp, sig };
}

export function conferirUrlMidia(recurso: string, exp: number, sig: string) {
  if (!Number.isFinite(exp) || exp < Date.now() / 1000) return false;
  const esperado = createHmac('sha256', config.MEDIA_URL_SECRET).update(`${recurso}.${exp}`).digest('base64url');
  return igualSeguro(esperado, sig);
}

// ── Recibos de integridade (Ed25519) ──────────────────────────────
const chavePrivadaRecibo: KeyObject = createPrivateKey(Buffer.from(config.RECEIPT_PRIVATE_KEY, 'base64').toString('utf8'));
const chavePublicaRecibo = createPublicKey(chavePrivadaRecibo);

export const chavePublicaReciboPem = chavePublicaRecibo.export({ type: 'spki', format: 'pem' }).toString();
export const impressaoDigitalChavePublica = sha256(
  chavePublicaRecibo.export({ type: 'spki', format: 'der' }),
).slice(0, 32);

export type DadosRecibo = {
  provaId: string;
  casoId: string;
  sha256: string;
  tamanhoBytes: number;
  recebidoEm: string;
};

/** Texto canônico assinado — também impresso no dossiê para conferência independente. */
export const textoRecibo = (r: DadosRecibo) =>
  `amparo-recibo-v1|${r.provaId}|${r.casoId}|${r.sha256}|${r.tamanhoBytes}|${r.recebidoEm}`;

export const assinarRecibo = (r: DadosRecibo) =>
  sign(null, Buffer.from(textoRecibo(r)), chavePrivadaRecibo).toString('base64');

export const conferirRecibo = (r: DadosRecibo, assinatura: string) =>
  verify(null, Buffer.from(textoRecibo(r)), chavePublicaRecibo, Buffer.from(assinatura, 'base64'));
