import { and, desc, eq, lt, sql, type SQL } from 'drizzle-orm';
import { db, schema } from '../../db';
import { autoriaVisivel } from '../me/perfil';

const { posts, comunidades, usuarias } = schema;

const contarReacao = (tipo: 'APOIO' | 'ME_IDENTIFICO' | 'FORCA') =>
  sql<number>`(select count(*)::int from reacoes_post r where r.post_id = "posts"."id" and r.tipo = ${tipo})`;

/** Busca relatos já com contagens de reações/comentários e as reações da usuária atual. */
export async function buscarPosts(opts: { onde: SQL | undefined; usuariaId: string; limite?: number; cursor?: Date }) {
  const linhas = await db
    .select({
      id: posts.id,
      titulo: posts.titulo,
      corpo: posts.corpo,
      anonimo: posts.anonimo,
      sensivel: posts.sensivel,
      status: posts.status,
      visibilidade: posts.visibilidade,
      publicadoEm: posts.publicadoEm,
      criadoEm: posts.criadoEm,
      autoraId: posts.autoraId,
      apelido: usuarias.apelido,
      motivoModeracao: posts.motivoModeracao,
      respostaModeracao: posts.respostaModeracao,
      respondidoEm: posts.respondidoEm,
      temDetalhesModeracao: sql<boolean>`${posts.detalhesModeracaoEnc} is not null`,
      comunidade: {
        id: comunidades.id,
        slug: comunidades.slug,
        nome: comunidades.nome,
        cor: comunidades.cor,
        icone: comunidades.icone,
      },
      apoio: contarReacao('APOIO'),
      meIdentifico: contarReacao('ME_IDENTIFICO'),
      forca: contarReacao('FORCA'),
      comentarios: sql<number>`(select count(*)::int from comentarios c where c.post_id = "posts"."id" and c.status = 'PUBLICADO')`,
      minhasReacoes: sql<string[]>`coalesce((select array_agg(r.tipo::text) from reacoes_post r where r.post_id = "posts"."id" and r.usuaria_id = ${opts.usuariaId}), '{}')`,
    })
    .from(posts)
    .innerJoin(comunidades, eq(comunidades.id, posts.comunidadeId))
    .leftJoin(usuarias, eq(usuarias.id, posts.autoraId))
    .where(and(opts.onde, opts.cursor ? lt(sql`coalesce(${posts.publicadoEm}, ${posts.criadoEm})`, opts.cursor) : undefined))
    .orderBy(desc(sql`coalesce(${posts.publicadoEm}, ${posts.criadoEm})`))
    .limit(opts.limite ?? 20);

  return linhas.map((p) => serializarPost(p, opts.usuariaId));
}

type LinhaPost = {
  id: string;
  titulo: string;
  corpo: string;
  anonimo: boolean;
  sensivel: boolean;
  status: string;
  visibilidade: string;
  publicadoEm: Date | null;
  criadoEm: Date;
  autoraId: string;
  apelido: string | null;
  motivoModeracao: string | null;
  respostaModeracao: string | null;
  respondidoEm: Date | null;
  temDetalhesModeracao: boolean;
  comunidade: { id: string; slug: string; nome: string; cor: string; icone: string };
  apoio: number;
  meIdentifico: number;
  forca: number;
  comentarios: number;
  minhasReacoes: string[];
};

export function serializarPost(p: LinhaPost, usuariaId: string) {
  const souAutora = p.autoraId === usuariaId;
  return {
    id: p.id,
    titulo: p.titulo,
    corpo: p.corpo,
    sensivel: p.sensivel,
    publicadoEm: p.publicadoEm ?? p.criadoEm,
    comunidade: p.comunidade,
    autoria: autoriaVisivel(p.anonimo, p.apelido),
    reacoes: { APOIO: p.apoio, ME_IDENTIFICO: p.meIdentifico, FORCA: p.forca },
    minhasReacoes: p.minhasReacoes,
    totalComentarios: p.comentarios,
    souAutora,
    // Informações de moderação só para a própria autora.
    ...(souAutora
      ? {
          status: p.status,
          visibilidade: p.visibilidade,
          motivoModeracao: p.motivoModeracao,
          respostaModeracao: p.respostaModeracao,
          respondidoEm: p.respondidoEm,
          temDetalhesModeracao: p.temDetalhesModeracao,
        }
      : {}),
  };
}

export const postPublicado = and(eq(posts.status, 'PUBLICADO'), eq(posts.visibilidade, 'PUBLICO'));

/** Com 3 sinalizações abertas, o conteúdo sai do ar até a moderação revisar. */
export const LIMITE_SINALIZACOES = 3;
