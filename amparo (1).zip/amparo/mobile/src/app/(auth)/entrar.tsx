import { useState } from 'react';
import { router } from 'expo-router';
import { api, mensagemDeErro } from '@/api/cliente';
import type { Sessao } from '@/api/tipos';
import { Aviso, Botao, Campo, Espaco, Texto, Titulo, Tela } from '@/components/ui';
import { useSessao } from '@/store/sessao';
import { espaco } from '@/theme';

export default function Entrar() {
  const definirSessao = useSessao((s) => s.definir);
  const [apelido, setApelido] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState<string | null>(null);
  const [carregando, setCarregando] = useState(false);

  async function entrar() {
    setErro(null);
    setCarregando(true);
    try {
      await definirSessao(await api<Sessao>('/api/auth/entrar', { corpo: { apelido: apelido.trim(), senha }, semAuth: true }));
    } catch (e) {
      setErro(mensagemDeErro(e));
    } finally {
      setCarregando(false);
    }
  }

  return (
    <Tela>
      <Titulo>Que bom te ver</Titulo>
      <Texto fraco style={{ marginTop: espaco.s, marginBottom: espaco.xl }}>
        Entre com o apelido e a senha que você criou.
      </Texto>
      <Campo rotulo="Apelido" value={apelido} onChangeText={setApelido} autoCapitalize="none" autoCorrect={false} textContentType="username" autoFocus />
      <Campo rotulo="Senha" value={senha} onChangeText={setSenha} secureTextEntry autoCapitalize="none" textContentType="password" onSubmitEditing={entrar} />
      {erro ? <Aviso tom="perigo">{erro}</Aviso> : null}
      <Espaco />
      <Botao titulo="Entrar" onPress={entrar} carregando={carregando} desativado={!apelido || !senha} />
      <Botao titulo="Esqueci minha senha" variante="fantasma" estilo={{ marginTop: espaco.s }} onPress={() => router.push('/verificar?finalidade=REDEFINIR_SENHA')} />
    </Tela>
  );
}
