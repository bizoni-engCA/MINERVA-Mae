import PDFDocument from 'pdfkit';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { eq } from 'drizzle-orm';
import { db, schema } from '../../db';
import { abrirDek, criarDecifradorArquivo, impressaoDigitalChavePublica, chavePublicaReciboPem, textoRecibo } from '../../lib/crypto';
import { dataHora, dataHoraCurta, dataLonga, tamanhoLegivel } from '../../lib/datas';
import { storage } from '../../lib/storage';
import { ORIENTACOES_DOSSIE } from '../recursos/conteudo';
import { listarEventos, listarProvas, TIPOS_VIOLENCIA, VINCULOS_AUTOR, type DadosCaso } from './servico';

const FONTES = join(dirname(fileURLToPath(import.meta.url)), '../../../assets/fonts');
const COR = { titulo: '#3B1F66', texto: '#222222', suave: '#5F5A6B', linha: '#D9D2E6', fundo: '#F4EFFA', alerta: '#7A2E2E' };

const STATUS: Record<string, string> = {
  REGISTRADO: 'Registrado (guardado pela autora)',
  COMPARTILHADO: 'Compartilhado com a equipe de acolhimento',
  EM_ACOMPANHAMENTO: 'Em acompanhamento pela equipe de acolhimento',
  ENCAMINHADO: 'Encaminhado',
  ENCERRADO: 'Encerrado',
};

const EVENTOS_DOSSIE: Record<string, string> = {
  CRIADO: 'Caso registrado na Minerva Mãe',
  ATUALIZADO: 'Relato atualizado pela autora',
  PROVA_ADICIONADA: 'Prova adicionada',
  PROVA_REMOVIDA: 'Prova removida pela autora',
  COMPARTILHADO: 'Caso compartilhado com a equipe de acolhimento',
  COMPARTILHAMENTO_REVOGADO: 'Compartilhamento revogado pela autora',
  ASSUMIDO: 'Caso assumido pela equipe de acolhimento',
  STATUS_ALTERADO: 'Situação do caso alterada',
};

const TIPOS_PROVA: Record<string, string> = {
  IMAGEM: 'Imagem',
  VIDEO: 'Vídeo',
  AUDIO: 'Áudio',
  DOCUMENTO: 'Documento',
  OUTRO: 'Arquivo',
};

/** Remove emojis e caracteres de controle que a fonte não desenha. */
const limpar = (t?: string | null) =>
  (t ?? '').replace(/[\p{Extended_Pictographic}\u{FE0F}\u{200D}]/gu, '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');

async function lerArquivoProva(p: typeof schema.provas.$inferSelect): Promise<Buffer> {
  const partes: Buffer[] = [];
  const stream = storage.abrirLeitura(p.arquivoChave).pipe(criarDecifradorArquivo(abrirDek(p.chaveProtegida), p.iv, p.authTag));
  for await (const pedaco of stream) partes.push(pedaco as Buffer);
  return Buffer.concat(partes);
}

export async function gerarDossiePdf(ctx: { caso: typeof schema.casos.$inferSelect; dek: Buffer; dados: DadosCaso }) {
  const { caso, dek, dados } = ctx;
  const provas = await listarProvas(caso.id, dek);
  const brutas = await db.select().from(schema.provas).where(eq(schema.provas.casoId, caso.id));
  const eventos = (await listarEventos(caso.id)).filter((e) => EVENTOS_DOSSIE[e.tipo]).reverse();
  const codigo = caso.id.slice(0, 8).toUpperCase();
  const agora = new Date();

  const doc = new PDFDocument({
    size: 'A4',
    margins: { top: 64, bottom: 64, left: 58, right: 58 },
    bufferPages: true,
    info: {
      Title: `Dossiê de relato — ${limpar(dados.titulo)}`,
      Author: 'Minerva Mãe',
      Subject: 'Dossiê confidencial gerado a pedido da autora',
      CreationDate: agora,
    },
  });
  doc.registerFont('regular', join(FONTES, 'Inter-Regular.otf'));
  doc.registerFont('semibold', join(FONTES, 'Inter-SemiBold.otf'));
  doc.registerFont('bold', join(FONTES, 'Inter-Bold.otf'));

  const saida: Buffer[] = [];
  doc.on('data', (b: Buffer) => saida.push(b));
  const fim = new Promise<Buffer>((ok) => doc.on('end', () => ok(Buffer.concat(saida))));

  const largura = doc.page.width - doc.page.margins.left - doc.page.margins.right;
  const esq = doc.page.margins.left;

  const garantirEspaco = (altura: number) => {
    if (doc.y + altura > doc.page.height - doc.page.margins.bottom) doc.addPage();
  };
  const secao = (titulo: string) => {
    garantirEspaco(60);
    doc.moveDown(1.1);
    doc.font('bold').fontSize(13).fillColor(COR.titulo).text(titulo.toUpperCase(), { characterSpacing: 0.6 });
    const y = doc.y + 3;
    doc.moveTo(esq, y).lineTo(esq + largura, y).lineWidth(0.8).strokeColor(COR.linha).stroke();
    doc.moveDown(0.6);
  };
  const campo = (rotulo: string, valor?: string | null) => {
    if (!valor) return;
    garantirEspaco(30);
    doc.font('semibold').fontSize(9).fillColor(COR.suave).text(rotulo.toUpperCase(), { characterSpacing: 0.4 });
    doc.font('regular').fontSize(10.5).fillColor(COR.texto).text(limpar(valor), { lineGap: 2 });
    doc.moveDown(0.5);
  };
  const paragrafo = (texto: string, opcoes: PDFKit.Mixins.TextOptions = {}) => {
    doc.font('regular').fontSize(10.5).fillColor(COR.texto).text(limpar(texto), { lineGap: 2.5, align: 'left', ...opcoes });
  };

  // ── Capa ────────────────────────────────────────────────────────
  doc.font('semibold').fontSize(9).fillColor(COR.suave).text('MINERVA MÃE · DOSSIÊ DE RELATO', { characterSpacing: 1.2 });
  doc.moveDown(0.4);
  doc.font('bold').fontSize(22).fillColor(COR.titulo).text(limpar(dados.titulo), { lineGap: 2 });
  doc.moveDown(0.6);
  doc.font('regular').fontSize(10).fillColor(COR.suave);
  doc.text(`Código do caso: ${codigo}`);
  doc.text(`Registrado em: ${dataHora(caso.criadoEm)}`);
  doc.text(`Dossiê gerado em: ${dataHora(agora)}`);
  doc.text(`Situação: ${STATUS[caso.status] ?? caso.status}`);
  doc.moveDown(1);

  const yAviso = doc.y;
  const textoAviso =
    'Documento confidencial. Contém relato de violência e dados pessoais sensíveis, protegidos pela LGPD (Lei 13.709/2018). ' +
    'Foi gerado a pedido da autora e deve ser entregue apenas a canais oficiais ou a pessoas de sua confiança.';
  const hAviso = doc.font('regular').fontSize(9.5).heightOfString(textoAviso, { width: largura - 24 }) + 20;
  doc.roundedRect(esq, yAviso, largura, hAviso, 6).fill(COR.fundo);
  doc.fillColor(COR.alerta).text(textoAviso, esq + 12, yAviso + 10, { width: largura - 24, lineGap: 1.5 });
  doc.x = esq;
  doc.y = yAviso + hAviso;

  // ── 1. Resumo ───────────────────────────────────────────────────
  secao('1. Resumo');
  campo('Tipos de violência', dados.tiposViolencia.map((t) => TIPOS_VIOLENCIA[t]).join(' · ') || 'Não informado');
  campo('Quando aconteceu', [dados.dataOcorrido, dados.periodo].filter(Boolean).join(' — ') || 'Não informado');
  campo('Onde aconteceu', dados.local || 'Não informado');
  campo('Vínculo de quem cometeu a violência com a UFRJ', dados.vinculoAutor ? VINCULOS_AUTOR[dados.vinculoAutor] : 'Não informado');
  campo('Número de provas anexadas', String(provas.length));

  // ── 2. Relato ───────────────────────────────────────────────────
  secao('2. Relato da autora');
  paragrafo(dados.relato || '(A autora ainda não escreveu o relato.)');

  // ── 3. Pessoas ──────────────────────────────────────────────────
  if (dados.pessoasEnvolvidas || dados.testemunhas) {
    secao('3. Pessoas envolvidas');
    campo('Quem cometeu a violência', dados.pessoasEnvolvidas);
    campo('Testemunhas ou pessoas que sabem do ocorrido', dados.testemunhas);
  }

  // ── 4. Impactos ─────────────────────────────────────────────────
  if (dados.impactos || dados.providenciasTomadas || dados.observacoes) {
    secao('4. Impactos e providências');
    campo('Como isso afetou a autora', dados.impactos);
    campo('Providências já tomadas', dados.providenciasTomadas);
    campo('Observações', dados.observacoes);
  }

  // ── 5. Provas ───────────────────────────────────────────────────
  secao('5. Provas');
  if (!provas.length) {
    paragrafo('Nenhuma prova foi anexada até a geração deste dossiê.');
  } else {
    paragrafo(
      'Cada arquivo foi recebido e criptografado pela Minerva Mãe. O código SHA-256 abaixo é a "impressão digital" do arquivo original: ' +
        'qualquer alteração, por menor que seja, gera um código completamente diferente. A data de recebimento foi registrada pelo servidor ' +
        'e assinada digitalmente (veja o Anexo).',
      { width: largura },
    );
    doc.moveDown(0.6);
  }

  for (const [i, p] of provas.entries()) {
    garantirEspaco(110);
    doc.font('semibold').fontSize(11).fillColor(COR.titulo).text(`Prova ${i + 1} — ${TIPOS_PROVA[p.tipo]}: ${limpar(p.nomeOriginal)}`);
    doc.font('regular').fontSize(9.5).fillColor(COR.texto);
    if (p.descricao) doc.text(`Descrição: ${limpar(p.descricao)}`, { lineGap: 1.5 });
    if (p.dataCaptura) doc.text(`Data informada pela autora: ${limpar(p.dataCaptura)}`);
    doc.text(`Recebida pela Minerva Mãe em: ${dataHora(p.recebidoEm)}`);
    doc.text(`Tamanho: ${tamanhoLegivel(p.tamanhoBytes)}  ·  Formato: ${p.mimeType}`);
    doc.font('Courier').fontSize(8.5).fillColor(COR.suave).text(`SHA-256: ${p.sha256}`);

    const bruta = brutas.find((b) => b.id === p.id);
    if (bruta && /image\/(jpeg|png)/.test(p.mimeType) && p.tamanhoBytes < 15 * 1024 * 1024) {
      try {
        const imagem = await lerArquivoProva(bruta);
        garantirEspaco(250);
        doc.moveDown(0.4);
        doc.image(imagem, esq, doc.y, { fit: [260, 240] });
        doc.y += 248;
      } catch {
        doc.font('regular').fontSize(9).fillColor(COR.suave).text('(Não foi possível exibir a imagem — consulte o arquivo original.)');
      }
    }
    doc.x = esq;
    doc.moveDown(0.9);
  }

  // ── 6. Linha do tempo ───────────────────────────────────────────
  if (eventos.length) {
    secao('6. Linha do tempo do registro');
    doc.font('regular').fontSize(9).fillColor(COR.suave).text('Horários de Brasília, registrados pelo servidor.');
    doc.moveDown(0.4);
    for (const e of eventos) {
      garantirEspaco(20);
      const extra =
        e.tipo === 'PROVA_ADICIONADA' || e.tipo === 'PROVA_REMOVIDA'
          ? ` (SHA-256 ${String((e.detalhe as { sha256?: string } | null)?.sha256 ?? '').slice(0, 16)}…)`
          : '';
      doc.font('semibold').fontSize(9.5).fillColor(COR.suave).text(dataHoraCurta(e.criadoEm), { continued: true });
      doc.font('regular').fillColor(COR.texto).text(`   ${EVENTOS_DOSSIE[e.tipo]}${extra}`);
    }
  }

  // ── 7. Como usar ────────────────────────────────────────────────
  secao('7. Como usar este dossiê');
  for (const o of ORIENTACOES_DOSSIE) {
    garantirEspaco(30);
    doc.font('regular').fontSize(10).fillColor(COR.texto).text(`•  ${o}`, { lineGap: 2, indent: 0 });
    doc.moveDown(0.3);
  }

  // ── Anexo: recibos ──────────────────────────────────────────────
  if (provas.length) {
    doc.addPage();
    doc.font('bold').fontSize(13).fillColor(COR.titulo).text('ANEXO — RECIBOS DE INTEGRIDADE', { characterSpacing: 0.6 });
    doc.moveDown(0.5);
    paragrafo(
      'Cada recibo abaixo é o texto exato assinado pelo servidor da Minerva Mãe com o algoritmo Ed25519 no momento em que a prova foi recebida. ' +
        'Para conferir, use a chave pública ao final desta página: a assinatura só é válida se o texto (incluindo o SHA-256 e a data) não tiver sido alterado.',
    );
    doc.moveDown(0.6);
    for (const [i, p] of provas.entries()) {
      garantirEspaco(70);
      const texto = textoRecibo({
        provaId: p.id,
        casoId: caso.id,
        sha256: p.sha256,
        tamanhoBytes: p.tamanhoBytes,
        recebidoEm: new Date(p.recebidoEm).toISOString(),
      });
      doc.font('semibold').fontSize(9.5).fillColor(COR.titulo).text(`Prova ${i + 1}`);
      doc.font('Courier').fontSize(7.5).fillColor(COR.texto).text(`Texto assinado: ${texto}`, { lineGap: 1 });
      doc.text(`Assinatura (base64): ${p.assinatura}`, { lineGap: 1 });
      doc.moveDown(0.6);
    }
    garantirEspaco(120);
    doc.moveDown(0.4);
    doc.font('semibold').fontSize(9.5).fillColor(COR.titulo).text(`Chave pública do servidor (impressão digital ${impressaoDigitalChavePublica})`);
    doc.font('Courier').fontSize(7.5).fillColor(COR.texto).text(chavePublicaReciboPem.trim());
  }

  // ── Rodapé em todas as páginas ──────────────────────────────────
  const paginas = doc.bufferedPageRange();
  for (let i = 0; i < paginas.count; i++) {
    doc.switchToPage(paginas.start + i);
    const margemOriginal = doc.page.margins.bottom;
    doc.page.margins.bottom = 0;
    const y = doc.page.height - 40;
    doc.font('regular').fontSize(8).fillColor(COR.suave);
    doc.text(`Minerva Mãe · Dossiê confidencial · Caso ${codigo} · ${dataLonga(agora)}`, esq, y, { lineBreak: false });
    doc.text(`Página ${i + 1} de ${paginas.count}`, esq, y, { width: largura, align: 'right', lineBreak: false });
    doc.page.margins.bottom = margemOriginal;
  }

  doc.end();
  return fim;
}
