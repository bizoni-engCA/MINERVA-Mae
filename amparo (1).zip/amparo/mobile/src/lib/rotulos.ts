import type { CasoStatus, ConteudoStatus, ReacaoTipo } from '@/api/tipos';
import { cores } from '@/theme';

export const TIPOS_VIOLENCIA: Record<string, string> = {
  ASSEDIO_SEXUAL: 'Assédio sexual',
  IMPORTUNACAO_SEXUAL: 'Importunação sexual',
  VIOLENCIA_SEXUAL: 'Violência sexual',
  ASSEDIO_MORAL: 'Assédio moral',
  VIOLENCIA_PSICOLOGICA: 'Violência psicológica',
  VIOLENCIA_FISICA: 'Violência física',
  PERSEGUICAO: 'Perseguição (stalking)',
  VIOLENCIA_DIGITAL: 'Violência digital',
  DISCRIMINACAO: 'Discriminação',
  OUTRA: 'Outra',
};

export const VINCULOS_AUTOR: Record<string, string> = {
  DOCENTE: 'Docente',
  ESTUDANTE: 'Estudante',
  TECNICO: 'Técnico(a)',
  TERCEIRIZADO: 'Terceirizado(a)',
  EXTERNO: 'De fora da UFRJ',
  NAO_SEI: 'Não sei / prefiro não dizer',
};

export const STATUS_CASO: Record<CasoStatus, { rotulo: string; cor: string; fundo: string; explicacao: string }> = {
  REGISTRADO: {
    rotulo: 'Guardado',
    cor: cores.tintaSuave,
    fundo: cores.lilasClaro,
    explicacao: 'Só você tem acesso a este caso.',
  },
  COMPARTILHADO: {
    rotulo: 'Aguardando acolhimento',
    cor: cores.ambar,
    fundo: cores.ambarClaro,
    explicacao: 'A equipe de acolhimento recebeu seu caso e vai responder por aqui.',
  },
  EM_ACOMPANHAMENTO: {
    rotulo: 'Em acompanhamento',
    cor: cores.mata,
    fundo: cores.mataClaro,
    explicacao: 'Uma pessoa da equipe de acolhimento está acompanhando seu caso.',
  },
  ENCAMINHADO: {
    rotulo: 'Encaminhado',
    cor: cores.mata,
    fundo: cores.mataClaro,
    explicacao: 'O caso foi encaminhado (por exemplo, à Ouvidoria).',
  },
  ENCERRADO: {
    rotulo: 'Encerrado',
    cor: cores.nevoa,
    fundo: cores.linha,
    explicacao: 'O acompanhamento foi encerrado. Você continua com acesso a tudo.',
  },
};

export const STATUS_CONTEUDO: Record<ConteudoStatus, { rotulo: string; cor: string; fundo: string }> = {
  PUBLICADO: { rotulo: 'Publicado', cor: cores.mata, fundo: cores.mataClaro },
  EM_REVISAO: { rotulo: 'Em revisão', cor: cores.ambar, fundo: cores.ambarClaro },
  REJEITADO: { rotulo: 'Não publicado', cor: cores.sinal, fundo: cores.sinalClaro },
  REMOVIDO: { rotulo: 'Removido', cor: cores.sinal, fundo: cores.sinalClaro },
};

export const REACOES: { tipo: ReacaoTipo; rotulo: string; icone: 'heart' | 'hand-left' | 'sparkles' }[] = [
  { tipo: 'APOIO', rotulo: 'Te apoio', icone: 'heart' },
  { tipo: 'ME_IDENTIFICO', rotulo: 'Me identifico', icone: 'hand-left' },
  { tipo: 'FORCA', rotulo: 'Força', icone: 'sparkles' },
];

export const MOTIVOS_SINALIZACAO: Record<string, string> = {
  IDENTIFICA_PESSOA: 'Expõe ou identifica alguém',
  ASSEDIO_OU_ATAQUE: 'Assédio ou ataque',
  DISCURSO_DE_ODIO: 'Discurso de ódio',
  CONTEUDO_FALSO: 'Conteúdo falso ou enganoso',
  SPAM: 'Spam',
  OUTRO: 'Outro motivo',
};

export const EVENTOS_CASO: Record<string, string> = {
  CRIADO: 'Caso registrado',
  ATUALIZADO: 'Você atualizou o relato',
  PROVA_ADICIONADA: 'Prova adicionada',
  PROVA_REMOVIDA: 'Prova removida',
  COMPARTILHADO: 'Compartilhado com o acolhimento',
  COMPARTILHAMENTO_REVOGADO: 'Compartilhamento encerrado por você',
  VISUALIZADO_PELA_EQUIPE: 'A equipe abriu o caso',
  PROVA_ACESSADA_PELA_EQUIPE: 'A equipe abriu uma prova',
  ASSUMIDO: 'A equipe assumiu o caso',
  STATUS_ALTERADO: 'Situação alterada',
  DOSSIE_GERADO: 'Dossiê gerado',
  PACOTE_GERADO: 'Pacote completo gerado',
  MENSAGEM: 'Nova mensagem',
};
