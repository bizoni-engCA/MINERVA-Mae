import { FlatList, RefreshControl, StyleSheet, View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { router } from 'expo-router';
import { Image } from 'expo-image';
import { useQueryClient } from '@tanstack/react-query';
import { useMeusVideos } from '@/api/consultas';
import { api, mensagemDeErro, urlMidia } from '@/api/cliente';
import { Botao, BotaoIcone, Carregando, ErroTela, Etiqueta, Icone, Texto, Vazio } from '@/components/ui';
import { data } from '@/lib/formatar';
import { STATUS_CONTEUDO } from '@/lib/rotulos';
import { cores, espaco, raio } from '@/theme';

export default function MeusVideos() {
  const q = useMeusVideos();
  const qc = useQueryClient();
  if (q.isLoading) return <Carregando />;
  if (q.isError) return <ErroTela mensagem={mensagemDeErro(q.error)} tentarDeNovo={q.refetch} />;

  const apagar = (id: string) =>
    Alert.alert('Apagar vídeo?', 'O vídeo sai do app e o arquivo é apagado do servidor.', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Apagar',
        style: 'destructive',
        onPress: async () => {
          try {
            await api(`/api/videos/${id}`, { metodo: 'DELETE' });
            qc.invalidateQueries({ queryKey: ['meus-videos'] });
            qc.invalidateQueries({ queryKey: ['videos'] });
          } catch (e) {
            Alert.alert('Erro', mensagemDeErro(e));
          }
        },
      },
    ]);

  return (
    <FlatList
      style={{ backgroundColor: cores.papel }}
      contentContainerStyle={{ padding: espaco.l }}
      data={q.data}
      keyExtractor={(v) => v.id}
      refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => void q.refetch()} tintColor={cores.lilas} />}
      renderItem={({ item: v }) => {
        const s = v.status ? STATUS_CONTEUDO[v.status] : null;
        return (
          <View style={estilos.linha}>
            <View style={estilos.capa}>
              {v.capaUrl ? <Image source={{ uri: urlMidia(v.capaUrl) }} style={StyleSheet.absoluteFill} contentFit="cover" /> : <Icone nome="videocam" cor="#FFF" />}
            </View>
            <View style={{ flex: 1, gap: 4 }}>
              <Texto negrito numberOfLines={2}>
                {v.titulo}
              </Texto>
              {s ? <Etiqueta texto={s.rotulo} cor={s.cor} fundo={s.fundo} /> : null}
              {v.motivoModeracao ? (
                <Texto pequeno cor={cores.sinal}>
                  {v.motivoModeracao}
                </Texto>
              ) : null}
              <Texto pequeno fraco>
                Enviado em {data(v.publicadoEm)}
              </Texto>
            </View>
            <BotaoIcone icone="trash-outline" rotulo="Apagar vídeo" cor={cores.sinal} onPress={() => apagar(v.id)} />
          </View>
        );
      }}
      ListEmptyComponent={
        <Vazio
          icone="videocam-outline"
          titulo="Você ainda não enviou vídeos"
          acao={<Botao titulo="Compartilhar minha história" compacto onPress={() => router.push('/video-novo')} />}
        />
      }
    />
  );
}

const estilos = StyleSheet.create({
  linha: { flexDirection: 'row', gap: espaco.m, alignItems: 'center', paddingVertical: espaco.m, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: cores.linha },
  capa: { width: 64, height: 96, borderRadius: raio.pequeno, backgroundColor: cores.cofre, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' },
});
