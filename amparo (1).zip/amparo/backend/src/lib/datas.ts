const fmtDataHora = new Intl.DateTimeFormat('pt-BR', {
  timeZone: 'America/Sao_Paulo',
  dateStyle: 'short',
  timeStyle: 'short',
});
const fmtData = new Intl.DateTimeFormat('pt-BR', { timeZone: 'America/Sao_Paulo', dateStyle: 'long' });

export const dataHora = (d: Date | string) => `${fmtDataHora.format(new Date(d))} (horário de Brasília)`;
export const dataHoraCurta = (d: Date | string) => fmtDataHora.format(new Date(d));
export const dataLonga = (d: Date | string) => fmtData.format(new Date(d));

export const tamanhoLegivel = (bytes: number) =>
  bytes < 1024
    ? `${bytes} B`
    : bytes < 1024 ** 2
      ? `${(bytes / 1024).toFixed(1).replace('.', ',')} KB`
      : `${(bytes / 1024 ** 2).toFixed(1).replace('.', ',')} MB`;
