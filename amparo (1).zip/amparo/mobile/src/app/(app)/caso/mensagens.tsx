import { useRef, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, StyleSheet, TextInput, View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery } from '@tanstack/react-query';
import { useInvalidarCaso } from '@/api/consultas';
import { api, mensagemDeErro } from '@/api/cliente';
import type { MensagemCaso } from '@/api/tipos';
import { BotaoIcone, Carregando, Texto, Vazio } from '@/components/ui';
import { dataHora } from '@/lib/formatar';
import { cores, espaco, fontes, raio } from '@/theme';

export default function Mensagens() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const invalidar = useInvalidarCaso(id);
  const lista = useRef<FlatList<MensagemCaso>>(null);
  const q = useQuery({
    queryKey: ['mensagens', id],
    queryFn: () => api<MensagemCaso[]>(`/api/casos/${id}/mensagens`),
    refetchInterval: 15_000,
  });
  const [texto, setTexto] = useState('');
  const [enviando, setEnviando] = useState(false);

  async function enviar() {
    if (!texto.trim()) return;
    setEnviando(true);
    try {
      await api(`/api/casos/${id}/mensagens`, { corpo: { corpo: texto.trim() } });
      setTexto('');
      await q.refetch();
      invalidar();
      setTimeout(() => lista.current?.scrollToEnd({ animated: true }), 100);
    } catch (e) {
      Alert.alert('Não foi possível enviar', mensagemDeErro(e));
    } finally {
      setEnviando(false);
    }
  }

  if (q.isLoading) return <Carregando />;

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: cores.papel }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={90}>
      <FlatList
        ref={lista}
        data={q.data ?? []}
        keyExtractor={(m) => m.id}
        contentContainerStyle={{ padding: espaco.l, gap: espaco.m, flexGrow: 1 }}
        onContentSizeChange={() => lista.current?.scrollToEnd({ animated: false })}
        ListEmptyComponent={<Vazio icone="chatbubbles-outline" titulo="Nenhuma mensagem ainda" texto="As mensagens ficam criptografadas e só aparecem para você e para a equipe de acolhimento." />}
        renderItem={({ item: m }) => {
          const minha = m.minha;
          return (
            <View style={[estilos.balao, minha ? estilos.minha : estilos.equipe]}>
              <Texto pequeno negrito cor={m.daEquipe ? cores.mata : cores.lilas}>
                {m.autoria}
              </Texto>
              <Texto style={{ marginTop: 2 }}>{m.corpo}</Texto>
              <Texto pequeno fraco style={{ marginTop: 4, fontSize: 12 }}>
                {dataHora(m.criadoEm)}
              </Texto>
            </View>
          );
        }}
      />
      <View style={[estilos.compositor, { paddingBottom: insets.bottom + espaco.s }]}>
        <TextInput
          value={texto}
          onChangeText={setTexto}
          placeholder="Escreva uma mensagem"
          placeholderTextColor={cores.nevoa}
          multiline
          maxLength={5000}
          style={estilos.entrada}
          accessibilityLabel="Mensagem"
        />
        <BotaoIcone icone="paper-plane" rotulo="Enviar mensagem" cor={texto.trim() && !enviando ? cores.lilas : cores.nevoa} onPress={enviar} />
      </View>
    </KeyboardAvoidingView>
  );
}

const estilos = StyleSheet.create({
  balao: { maxWidth: '85%', padding: espaco.m, borderRadius: raio.medio },
  minha: { alignSelf: 'flex-end', backgroundColor: cores.lilasClaro, borderBottomRightRadius: 4 },
  equipe: { alignSelf: 'flex-start', backgroundColor: cores.superficie, borderBottomLeftRadius: 4, borderWidth: StyleSheet.hairlineWidth, borderColor: cores.linha },
  compositor: { flexDirection: 'row', alignItems: 'flex-end', gap: espaco.s, paddingHorizontal: espaco.l, paddingTop: espaco.s, backgroundColor: cores.superficie, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: cores.linha },
  entrada: { flex: 1, minHeight: 44, maxHeight: 130, backgroundColor: cores.papel, borderRadius: raio.medio, paddingHorizontal: espaco.m, paddingVertical: 10, fontFamily: fontes.texto, fontSize: 16, color: cores.tinta },
});
