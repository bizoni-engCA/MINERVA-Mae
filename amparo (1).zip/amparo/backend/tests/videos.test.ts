import { randomBytes } from 'node:crypto';
import { beforeAll, describe, expect, it } from 'vitest';
import { api, cadastrar } from './helpers';

let autora: Awaited<ReturnType<typeof cadastrar>>;
let outra: Awaited<ReturnType<typeof cadastrar>>;
let mod: Awaited<ReturnType<typeof cadastrar>>;

beforeAll(async () => {
  autora = await cadastrar('voz.forte');
  outra = await cadastrar('espectadora');
  mod = await cadastrar('mod.videos', 'MODERADORA');
});

describe('vídeos curtos', () => {
  it('só aparecem depois de aprovados e são entregues por link assinado com Range', async () => {
    const bytes = randomBytes(4096);
    const up = await api()
      .post('/api/videos')
      .set(autora.auth)
      .field('titulo', 'Minha história de superação')
      .field('mostrarApelido', 'false')
      .field('sensivel', 'true')
      .attach('arquivo', bytes, { filename: 'v.mp4', contentType: 'video/mp4' });
    expect(up.status).toBe(201);
    expect(up.body.status).toBe('EM_REVISAO');

    expect((await api().get('/api/videos').set(outra.auth)).body.itens).toHaveLength(0);

    const fila = await api().get('/api/equipe/moderacao/videos').set(mod.auth);
    expect(fila.body[0].autoria.rotulo).toMatch(/^Anônima #/);
    await api().post(`/api/equipe/moderacao/videos/${up.body.id}/decisao`).set(mod.auth).send({ acao: 'APROVAR' });

    const feed = await api().get('/api/videos').set(outra.auth);
    expect(feed.body.itens).toHaveLength(1);
    const v = feed.body.itens[0];
    expect(v.autoria).toEqual({ apelido: 'Anônima', anonimo: true });
    expect(v.sensivel).toBe(true);

    const parcial = await api().get(v.url).set('Range', 'bytes=0-99');
    expect(parcial.status).toBe(206);
    expect(parcial.headers['content-range']).toBe('bytes 0-99/4096');

    const adulterado = v.url.replace(/sig=[^&]+/, 'sig=abc');
    expect((await api().get(adulterado)).status).toBe(403);

    const reacao = await api().post(`/api/videos/${v.id}/reacoes`).set(outra.auth).send({ tipo: 'APOIO' });
    expect(reacao.body.reacoes.APOIO).toBe(1);
  });

  it('recusa formatos que não são vídeo', async () => {
    const r = await api()
      .post('/api/videos')
      .set(autora.auth)
      .field('titulo', 'Arquivo errado')
      .field('mostrarApelido', 'true')
      .field('sensivel', 'false')
      .attach('arquivo', Buffer.from('%PDF'), { filename: 'x.pdf', contentType: 'application/pdf' });
    expect(r.status).toBe(415);
  });
});
