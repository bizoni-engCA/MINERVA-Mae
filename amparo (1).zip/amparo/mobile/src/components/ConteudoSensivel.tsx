import { useState, type ReactNode } from 'react';
import { Platform, Pressable, StyleSheet, View } from 'react-native';
import { BlurView } from 'expo-blur';
import { useSeguranca } from '@/store/seguranca';
import { cores, espaco, raio } from '@/theme';
import { Icone, Texto } from './ui';

/** Esconde conteúdo marcado como sensível até a pessoa escolher ver. */
export function ConteudoSensivel({ sensivel, children, escuro }: { sensivel: boolean; children: ReactNode; escuro?: boolean }) {
  const mostrarSempre = useSeguranca((s) => s.mostrarSensiveis);
  const [revelado, setRevelado] = useState(false);
  const esconder = sensivel && !mostrarSempre && !revelado;

  return (
    <View style={{ position: 'relative' }}>
      <View importantForAccessibility={esconder ? 'no-hide-descendants' : 'auto'} accessibilityElementsHidden={esconder}>
        {children}
      </View>
      {esconder ? (
        <Pressable
          onPress={() => setRevelado(true)}
          style={StyleSheet.absoluteFill}
          accessibilityRole="button"
          accessibilityLabel="Conteúdo sensível. Toque para ver."
        >
          <BlurView
            intensity={Platform.OS === 'android' ? 60 : 40}
            tint={escuro ? 'dark' : 'light'}
            experimentalBlurMethod="dimezisBlurView"
            style={[StyleSheet.absoluteFill, estilos.veu, escuro && { backgroundColor: 'rgba(20,10,35,0.55)' }]}
          >
            <Icone nome="eye-off" tamanho={22} cor={escuro ? '#FFF' : cores.tinta} />
            <Texto negrito cor={escuro ? '#FFF' : cores.tinta} style={{ marginTop: espaco.s }}>
              Conteúdo sensível
            </Texto>
            <Texto pequeno cor={escuro ? '#EEE' : cores.tintaSuave}>
              Pode falar de violência. Toque para ver.
            </Texto>
          </BlurView>
        </Pressable>
      ) : null}
    </View>
  );
}

const estilos = StyleSheet.create({
  veu: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: raio.medio,
    overflow: 'hidden',
    backgroundColor: 'rgba(245,242,249,0.55)',
    padding: espaco.l,
  },
});
