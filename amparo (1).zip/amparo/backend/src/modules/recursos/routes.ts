import { Router } from 'express';
import { naoEncontrado } from '../../lib/errors';
import { exigirLogin } from '../../middleware/auth';
import { CONTATOS, CONTEUDO_ATUALIZADO_EM, GUIAS } from './conteudo';

export const recursosRouter = Router();
recursosRouter.use(exigirLogin);

recursosRouter.get('/', (_req, res) => {
  res.json({
    atualizadoEm: CONTEUDO_ATUALIZADO_EM,
    guias: GUIAS.map(({ corpo: _corpo, ...g }) => g),
    contatos: CONTATOS,
  });
});

recursosRouter.get('/guias/:slug', (req, res) => {
  const guia = GUIAS.find((g) => g.slug === req.params.slug);
  if (!guia) throw naoEncontrado('Guia');
  res.json(guia);
});
