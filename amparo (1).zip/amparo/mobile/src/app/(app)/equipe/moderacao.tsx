import { useState } from 'react';
import { FlatList, Modal, RefreshControl, ScrollView, StyleSheet, View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { useLocalSearchParams } from 'expo-router';
import { useVideoPlayer, VideoView } from 'expo-video';
import { useQueryClient } from '@tanstack/react-query';
import { useFilaComentarios, useFilaPosts, useFilaVideos, useSinalizacoes } from '@/api/consultas';
import { api, mensagemDeErro, urlMidia } from '@/api/cliente';
import type { AutoriaModeracao } from '@/api/tipos';
import { PedirTexto } from '@/components/PedirTexto';
import { Aviso, Botao, Carregando, Chip, ErroTela, Etiqueta, Linha, Texto, Titulo, Vazio } from '@/components/ui';
import { duracao, tamanho, tempoRelativo } from '@/lib/formatar';
import { MOTIVOS_SINALIZACAO } from '@/lib/rotulos';
import { cores, espaco, raio } from '@/theme';

const ABAS = [
  { id: 'revisao', rotulo: 'Em revisão' },
  { id: 'so-moderacao', rotulo: 'Só p/ moderação' },
  { id: 'com-detalhes', rotulo: 'Com reservado' },
  { id: 'comentarios', rotulo: 'Comentários' },
  { id: 'videos', rotulo: 'Vídeos' },
  { id: 'sinalizacoes', rotulo: 'Sinalizações' },
] as const;
type Aba = (typeof ABAS)[number]['id'];

type Dialogo = { titulo: string; descricao?: string; rotulo: string; confirmar: string; perigo?: boolean; acao: (t: string) => Promise<unknown> };

export default function Moderacao() {
  const params = useLocalSearchParams<{ aba?: Aba }>();
  const [aba, setAba] = useState<Aba>(params.aba ?? 'revisao');
  const [dialogo, setDialogo] = useState<Dialogo | null>(null);
  const qc = useQueryClient();

  const executar = async (fn: () => Promise<unknown>) => {
    try {
      await fn();
      qc.invalidateQueries({ queryKey: ['equipe'] });
      qc.invalidateQueries({ queryKey: ['feed'] });
      qc.invalidateQueries({ queryKey: ['videos'] });
    } catch (e) {
      Alert.alert('Erro', mensagemDeErro(e));
    }
  };
  const pedir = (d: Dialogo) => setDialogo(d);
  const suspender = (autoria: AutoriaModeracao) =>
    pedir({
      titulo: `Suspender ${autoria.rotulo}?`,
      descricao: 'A conta fica sem acesso até ser reativada. Todas as sessões são encerradas.',
      rotulo: 'Motivo (fica na auditoria)',
      confirmar: 'Suspender',
      perigo: true,
      acao: (motivo) => api(`/api/equipe/moderacao/usuarias/${autoria.autoraId}/status`, { corpo: { status: 'SUSPENSA', motivo } }),
    });

  return (
    <View style={{ flex: 1, backgroundColor: cores.papel }}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }} contentContainerStyle={{ gap: espaco.s, padding: espaco.l, paddingBottom: espaco.s }}>
        {ABAS.map((a) => (
          <Chip key={a.id} rotulo={a.rotulo} ativo={aba === a.id} onPress={() => setAba(a.id)} />
        ))}
      </ScrollView>

      {aba === 'revisao' || aba === 'so-moderacao' || aba === 'com-detalhes' ? (
        <FilaPosts fila={aba} executar={executar} pedir={pedir} suspender={suspender} />
      ) : aba === 'comentarios' ? (
        <FilaComentarios executar={executar} pedir={pedir} suspender={suspender} />
      ) : aba === 'videos' ? (
        <FilaVideos executar={executar} pedir={pedir} />
      ) : (
        <FilaSinalizacoes executar={executar} pedir={pedir} />
      )}

      <PedirTexto
        visivel={!!dialogo}
        titulo={dialogo?.titulo ?? ''}
        descricao={dialogo?.descricao}
        rotulo={dialogo?.rotulo ?? ''}
        confirmar={dialogo?.confirmar ?? 'Confirmar'}
        perigo={dialogo?.perigo}
        aoFechar={() => setDialogo(null)}
        aoConfirmar={async (t) => {
          if (!dialogo) return;
          await executar(() => dialogo.acao(t));
          setDialogo(null);
        }}
      />
    </View>
  );
}

type Props = { executar: (fn: () => Promise<unknown>) => Promise<void>; pedir: (d: Dialogo) => void; suspender?: (a: AutoriaModeracao) => void };

function FilaPosts({ fila, executar, pedir, suspender }: Props & { fila: string }) {
  const q = useFilaPosts(fila);
  if (q.isLoading) return <Carregando />;
  if (q.isError) return <ErroTela mensagem={mensagemDeErro(q.error)} tentarDeNovo={q.refetch} />;
  const decidir = (id: string, acao: string, motivo?: string) => api(`/api/equipe/moderacao/posts/${id}/decisao`, { corpo: { acao, motivo } });

  return (
    <FlatList
      data={q.data}
      keyExtractor={(p) => p.id}
      contentContainerStyle={{ padding: espaco.l, paddingTop: espaco.s, gap: espaco.m }}
      refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => void q.refetch()} tintColor={cores.lilas} />}
      ListEmptyComponent={<Vazio icone="checkmark-done-outline" titulo="Fila vazia" texto="Nada para revisar por aqui." />}
      renderItem={({ item: p }) => (
        <View style={[estilos.cartao, { borderLeftColor: p.comunidade.cor }]}>
          <Linha estilo={{ justifyContent: 'space-between' }}>
            <Texto pequeno fraco>
              {p.comunidade.nome} · {tempoRelativo(p.criadoEm)}
            </Texto>
            {p.sinalizacoes ? <Etiqueta texto={`${p.sinalizacoes} sinalizações`} cor={cores.sinal} fundo={cores.sinalClaro} /> : null}
          </Linha>
          <Titulo nivel={3} style={{ marginTop: espaco.s }}>
            {p.titulo}
          </Titulo>
          <Texto style={{ marginTop: 4 }}>{p.corpo}</Texto>
          <Texto pequeno fraco style={{ marginTop: espaco.s }}>
            Autoria: {p.autoria.rotulo}
          </Texto>
          {p.alertas.length ? (
            <View style={{ marginTop: espaco.m }}>
              <Aviso tom="cuidado" titulo="Alertas do filtro">
                {p.alertas.join('\n')}
              </Aviso>
            </View>
          ) : null}
          {p.detalhesModeracao ? (
            <View style={{ marginTop: espaco.m }}>
              <Aviso tom="info" titulo="Reservado para a moderação">
                {p.detalhesModeracao}
              </Aviso>
            </View>
          ) : null}
          {p.respostaModeracao ? (
            <Texto pequeno style={{ marginTop: espaco.s }}>
              Resposta enviada: {p.respostaModeracao}
            </Texto>
          ) : null}
          <View style={estilos.acoes}>
            {fila === 'revisao' ? (
              <>
                <Botao titulo="Aprovar" variante="apoio" compacto onPress={() => executar(() => decidir(p.id, 'APROVAR'))} />
                <Botao
                  titulo="Não publicar"
                  variante="perigo"
                  compacto
                  onPress={() =>
                    pedir({
                      titulo: 'Não publicar este relato',
                      descricao: 'A autora vê este motivo. Seja acolhedora e explique o que ela pode ajustar.',
                      rotulo: 'Motivo',
                      confirmar: 'Enviar',
                      acao: (m) => decidir(p.id, 'REJEITAR', m),
                    })
                  }
                />
              </>
            ) : null}
            {fila === 'so-moderacao' ? (
              <Botao
                titulo="Responder"
                compacto
                onPress={() =>
                  pedir({
                    titulo: 'Responder à autora',
                    descricao: 'Ela vê esta resposta no relato. Indique caminhos de apoio e denúncia quando fizer sentido.',
                    rotulo: 'Resposta',
                    confirmar: 'Enviar resposta',
                    acao: (r) => api(`/api/equipe/moderacao/posts/${p.id}/responder`, { corpo: { resposta: r } }),
                  })
                }
              />
            ) : null}
            {fila === 'com-detalhes' ? (
              <>
                <Botao titulo="Ciente" variante="secundario" compacto onPress={() => executar(() => decidir(p.id, 'CIENTE'))} />
                <Botao
                  titulo="Remover"
                  variante="perigo"
                  compacto
                  onPress={() => pedir({ titulo: 'Remover relato publicado', rotulo: 'Motivo (a autora vê)', confirmar: 'Remover', perigo: true, acao: (m) => decidir(p.id, 'REMOVER', m) })}
                />
              </>
            ) : null}
            {suspender ? <Botao titulo="Suspender conta" variante="fantasma" compacto onPress={() => suspender(p.autoria)} /> : null}
          </View>
        </View>
      )}
    />
  );
}

function FilaComentarios({ executar, pedir, suspender }: Props) {
  const q = useFilaComentarios();
  if (q.isLoading) return <Carregando />;
  if (q.isError) return <ErroTela mensagem={mensagemDeErro(q.error)} tentarDeNovo={q.refetch} />;
  const decidir = (id: string, acao: string, motivo?: string) => api(`/api/equipe/moderacao/comentarios/${id}/decisao`, { corpo: { acao, motivo } });
  return (
    <FlatList
      data={q.data}
      keyExtractor={(c) => c.id}
      contentContainerStyle={{ padding: espaco.l, paddingTop: espaco.s, gap: espaco.m }}
      refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => void q.refetch()} tintColor={cores.lilas} />}
      ListEmptyComponent={<Vazio icone="checkmark-done-outline" titulo="Fila vazia" />}
      renderItem={({ item: c }) => (
        <View style={[estilos.cartao, { borderLeftColor: cores.lilas }]}>
          <Texto pequeno fraco>
            No relato “{c.post.titulo}” · {tempoRelativo(c.criadoEm)}
          </Texto>
          <Texto style={{ marginTop: espaco.s }}>{c.corpo}</Texto>
          <Texto pequeno fraco style={{ marginTop: espaco.s }}>
            Autoria: {c.autoria.rotulo}
          </Texto>
          {c.alertas.length ? (
            <View style={{ marginTop: espaco.m }}>
              <Aviso tom="cuidado">{c.alertas.join('\n')}</Aviso>
            </View>
          ) : null}
          <View style={estilos.acoes}>
            <Botao titulo="Aprovar" variante="apoio" compacto onPress={() => executar(() => decidir(c.id, 'APROVAR'))} />
            <Botao
              titulo="Não publicar"
              variante="perigo"
              compacto
              onPress={() => pedir({ titulo: 'Não publicar comentário', rotulo: 'Motivo (a autora vê)', confirmar: 'Enviar', acao: (m) => decidir(c.id, 'REJEITAR', m) })}
            />
            {suspender ? <Botao titulo="Suspender conta" variante="fantasma" compacto onPress={() => suspender(c.autoria)} /> : null}
          </View>
        </View>
      )}
    />
  );
}

function FilaVideos({ executar, pedir }: Props) {
  const q = useFilaVideos();
  const [assistindo, setAssistindo] = useState<string | null>(null);
  if (q.isLoading) return <Carregando />;
  if (q.isError) return <ErroTela mensagem={mensagemDeErro(q.error)} tentarDeNovo={q.refetch} />;
  const decidir = (id: string, acao: string, motivo?: string) => api(`/api/equipe/moderacao/videos/${id}/decisao`, { corpo: { acao, motivo } });
  return (
    <>
      <FlatList
        data={q.data}
        keyExtractor={(v) => v.id}
        contentContainerStyle={{ padding: espaco.l, paddingTop: espaco.s, gap: espaco.m }}
        refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => void q.refetch()} tintColor={cores.lilas} />}
        ListEmptyComponent={<Vazio icone="checkmark-done-outline" titulo="Nenhum vídeo aguardando" />}
        renderItem={({ item: v }) => (
          <View style={[estilos.cartao, { borderLeftColor: cores.lilas }]}>
            <Titulo nivel={3}>{v.titulo}</Titulo>
            {v.descricao ? <Texto style={{ marginTop: 4 }}>{v.descricao}</Texto> : null}
            <Texto pequeno fraco style={{ marginTop: espaco.s }}>
              {v.autoria.rotulo} · {duracao(v.duracaoSeg)} · {tamanho(v.tamanhoBytes)} {v.sensivel ? '· marcado como sensível' : ''}
            </Texto>
            <View style={estilos.acoes}>
              <Botao titulo="Assistir" icone="play" variante="secundario" compacto onPress={() => setAssistindo(urlMidia(v.url))} />
              <Botao titulo="Aprovar" variante="apoio" compacto onPress={() => executar(() => decidir(v.id, 'APROVAR'))} />
              <Botao
                titulo="Não publicar"
                variante="perigo"
                compacto
                onPress={() => pedir({ titulo: 'Não publicar vídeo', rotulo: 'Motivo (a autora vê)', confirmar: 'Enviar', acao: (m) => decidir(v.id, 'REJEITAR', m) })}
              />
            </View>
          </View>
        )}
      />
      <Modal visible={!!assistindo} animationType="slide" onRequestClose={() => setAssistindo(null)}>
        {assistindo ? <Player url={assistindo} fechar={() => setAssistindo(null)} /> : null}
      </Modal>
    </>
  );
}

function Player({ url, fechar }: { url: string; fechar: () => void }) {
  const player = useVideoPlayer({ uri: url }, (p) => p.play());
  return (
    <View style={{ flex: 1, backgroundColor: '#000', justifyContent: 'center' }}>
      <VideoView player={player} style={{ width: '100%', height: '80%' }} contentFit="contain" nativeControls />
      <Botao titulo="Fechar" variante="secundario" estilo={{ margin: espaco.l }} onPress={fechar} />
    </View>
  );
}

function FilaSinalizacoes({ executar, pedir }: Props) {
  const q = useSinalizacoes();
  if (q.isLoading) return <Carregando />;
  if (q.isError) return <ErroTela mensagem={mensagemDeErro(q.error)} tentarDeNovo={q.refetch} />;
  const resolver = (alvoId: string, acao: string, motivo?: string) => api(`/api/equipe/moderacao/sinalizacoes/${alvoId}/resolver`, { corpo: { acao, motivo } });
  return (
    <FlatList
      data={q.data}
      keyExtractor={(g) => g.alvoId}
      contentContainerStyle={{ padding: espaco.l, paddingTop: espaco.s, gap: espaco.m }}
      refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => void q.refetch()} tintColor={cores.lilas} />}
      ListEmptyComponent={<Vazio icone="checkmark-done-outline" titulo="Nenhuma sinalização aberta" />}
      renderItem={({ item: g }) => (
        <View style={[estilos.cartao, { borderLeftColor: cores.sinal }]}>
          <Linha estilo={{ justifyContent: 'space-between' }}>
            <Etiqueta texto={{ POST: 'Relato', COMENTARIO: 'Comentário', VIDEO: 'Vídeo' }[g.alvoTipo]} cor={cores.tintaSuave} fundo={cores.linha} />
            <Texto pequeno negrito cor={cores.sinal}>
              {g.total} {g.total === 1 ? 'sinalização' : 'sinalizações'}
            </Texto>
          </Linha>
          <Titulo nivel={3} style={{ marginTop: espaco.s }}>
            {g.conteudo.titulo}
          </Titulo>
          <Texto numberOfLines={6}>{g.conteudo.texto}</Texto>
          {g.conteudo.status === 'EM_REVISAO' ? (
            <Texto pequeno cor={cores.ambar} style={{ marginTop: 4 }}>
              Fora do ar automaticamente até a revisão.
            </Texto>
          ) : null}
          <View style={{ marginTop: espaco.m, gap: 4 }}>
            {g.motivos.map((m) => (
              <Texto key={m.id} pequeno>
                • {MOTIVOS_SINALIZACAO[m.motivo] ?? m.motivo}
                {m.detalhes ? `: ${m.detalhes}` : ''}
              </Texto>
            ))}
          </View>
          <View style={estilos.acoes}>
            <Botao titulo="Manter" variante="secundario" compacto onPress={() => executar(() => resolver(g.alvoId, 'MANTER'))} />
            <Botao
              titulo="Remover conteúdo"
              variante="perigo"
              compacto
              onPress={() => pedir({ titulo: 'Remover conteúdo', rotulo: 'Motivo (a autora vê)', confirmar: 'Remover', perigo: true, acao: (m) => resolver(g.alvoId, 'REMOVER_CONTEUDO', m) })}
            />
          </View>
        </View>
      )}
    />
  );
}

const estilos = StyleSheet.create({
  cartao: { backgroundColor: cores.superficie, borderLeftWidth: 4, borderTopRightRadius: raio.medio, borderBottomRightRadius: raio.medio, padding: espaco.l },
  acoes: { flexDirection: 'row', flexWrap: 'wrap', gap: espaco.s, marginTop: espaco.l },
});
