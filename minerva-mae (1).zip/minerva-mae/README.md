# Minerva Mãe — MVP

Aplicativo de apoio e denúncia para estudantes da UFRJ que são mulheres (cis ou trans) ou pessoas não-binárias. Tem três abas:

| Aba | O que faz |
| --- | --- |
| **Comunidades** (estilo Reddit) | Subcomunidades com relatos com apelido ou anônimos, comentários e reações de apoio (sem votos negativos). Um filtro manda para a moderação os relatos que parecem identificar alguém. Cada relato tem um campo **só para a moderação** (para nomes) e pode ser enviado **só para a moderação**. |
| **Vídeos** (estilo TikTok) | Feed vertical de relatos de superação. Os vídeos só aparecem depois de aprovados e a autora escolhe se mostra o apelido. |
| **Denúncia** | O "cofre": casos e provas criptografados, cada prova com SHA-256 e recibo assinado. Gera **dossiê em PDF** e **pacote ZIP** com os originais. O caso pode ser compartilhado com a **equipe de acolhimento**, que tem mensagens e acompanhamento. Inclui guias psicológicos e jurídicos e contatos verificados. |

Moderadoras e equipe de acolhimento usam o mesmo app, numa quarta aba (**Equipe**) que só aparece para elas.

**Segurança no aparelho:** PIN e biometria, botão de **saída rápida** em todas as telas (esconde o app atrás de uma calculadora que funciona de verdade), **disfarce** do ícone e do nome do app, bloqueio automático, bloqueio de prints e conteúdo sensível borrado.

---

## Como rodar (MVP local)

**Pré-requisitos:** Node.js 20 ou mais novo, Docker (ou um PostgreSQL 14+) e o app **Expo Go** no celular, com o celular e o computador no mesmo Wi-Fi.

### 1. Backend (API + banco)

```bash
cd backend
node scripts/init-env.mjs        # cria o .env com chaves novas (guarde o MASTER_KEY!)
```

**Opção A, tudo no Docker:**

```bash
cd ..
docker compose up --build        # API em http://localhost:3333, já com dados de exemplo
```

**Opção B, API rodando local (melhor para desenvolver):**

```bash
docker compose up -d db          # só o PostgreSQL
cd backend
npm install
npm run setup                    # cria as tabelas e os dados de exemplo
npm run dev                      # API em http://localhost:3333
```

O terminal mostra o endereço da API para usar no celular, por exemplo `http://192.168.0.10:3333`.

### 2. App

```bash
cd mobile
npm install
npx expo start
```

Escaneie o QR code com o Expo Go. O app procura a API no mesmo computador que roda o Expo. Se não encontrar, crie `mobile/.env` com `EXPO_PUBLIC_API_URL=http://SEU-IP:3333` e reinicie o `expo start`.

### 3. Contas de demonstração

Todas usam a senha `minerva123`:

| Apelido | Papel |
| --- | --- |
| `estudante.demo` | Usuária com relatos, um caso e duas provas |
| `moderadora.demo` | Moderação (filas de relatos, comentários, vídeos e sinalizações) |
| `acolhimento.demo` | Equipe de acolhimento (casos compartilhados) |
| `equipe.admin` | Administração (tudo isso, mais papéis e auditoria) |

Para **criar uma conta nova**, use qualquer DRE de 9 dígitos. O simulador do SIGA mostra o código de verificação na própria tela (modo de teste). Alguns DREs servem para testar recusas: `120000005` (matrícula cancelada), `120000006` (concluída) e `999999999` (inexistente).

Para dar um papel de equipe a uma conta, entre como `equipe.admin` e chame `POST /api/equipe/papeis` com `{ "apelido": "...", "papel": "MODERADORA" }`.

### 4. Testes

```bash
cd backend
npm test        # 20 testes: cadastro, filtro de nomes, moderação, vídeos, casos, criptografia, PDF, ZIP
```

Os testes usam um banco separado, `amparo_test`, criado automaticamente no mesmo servidor (ou defina `TEST_DATABASE_URL`).

---

## Disfarce do ícone: precisa do app instalado

Trocar o ícone (e, no Android, o nome) exige código nativo, que **não funciona no Expo Go**. No Expo Go a escolha fica salva e o resto do app funciona normalmente. Para testar o disfarce, gere um build de desenvolvimento:

```bash
cd mobile
npx expo run:android                  # precisa do Android Studio
# ou, na nuvem:
npx eas-cli@latest build --profile development --platform android
```

No iOS o sistema só deixa trocar o ícone, não o nome, e mostra um aviso quando a troca acontece.

---

## Arquitetura

```
mobile/  (Expo SDK 58 · React Native · Expo Router · TanStack Query · Zustand)
  src/app/(auth)        boas-vindas, verificação por DRE, cadastro, login, nova senha
  src/app/(app)/(abas)  Comunidades · Vídeos · Denúncia · Equipe
  src/app/bloqueio      PIN e biometria        src/app/calculadora   disfarce
        │  HTTPS + JWT (15 min) + refresh rotativo
        ▼
backend/ (Node 22 · Express 5 · TypeScript · Drizzle ORM · PostgreSQL)
  modules/auth          DRE → código no e-mail institucional → conta (simulador do SIGA)
  modules/posts         relatos, comentários, reações, sinalizações, filtro de nomes
  modules/videos        upload, aprovação, streaming por link assinado
  modules/casos         casos, provas criptografadas, dossiê PDF, pacote ZIP, mensagens
  modules/equipe        filas de moderação, acolhimento, papéis, auditoria
  modules/recursos      guias e contatos (conteúdo em recursos/conteudo.ts)
  modules/integridade   chave pública e verificação pública dos recibos
```

### Privacidade e segurança implementadas

- **DRE nunca é guardado em claro**: fica só um HMAC com segredo próprio, usado para impedir contas duplicadas e aplicar banimentos. Também não guardamos nome, e-mail nem gênero, só a data da autodeclaração.
- O app não revela se um DRE já tem conta antes de a pessoa confirmar o código enviado ao e-mail institucional.
- **Criptografia em envelope (AES-256-GCM).** A chave-mestra gera, via HKDF, a chave que protege as chaves individuais. Cada **caso** tem a sua chave, que cifra o relato, os metadados e as mensagens, e cada **prova** tem outra chave, só para o arquivo. As informações "só para a moderação" também são cifradas.
- **Integridade das provas.** O SHA-256 é calculado sobre o original no momento do recebimento, junto com um **recibo Ed25519** assinado pelo servidor (prova, caso, hash, tamanho e data). Qualquer pessoa pode conferir o recibo em `POST /api/integridade/verificar-recibo`, e o dossiê traz a chave pública.
- **Acesso aos casos.** Só a dona vê o caso. A equipe de acolhimento só entra depois de consentimento explícito e perde o acesso quando a dona revoga. **Moderadoras nunca acessam casos.** Cada acesso da equipe aparece na linha do tempo que a dona vê, e a equipe nunca vê o apelido da estudante.
- **Anonimato também para a moderação.** Quando o relato é anônimo, a moderação vê só um código (`Anônima #a1b2c3`), mas ainda consegue suspender a conta.
- **Sessões.** Senhas usam argon2id. O token de acesso dura 15 minutos e o de renovação é rotativo, com detecção de reuso. Existe "encerrar todas as sessões", e há limite de tentativas no cadastro e no login.
- **Logs mínimos:** sem IP, sem corpo das requisições, sem tokens.
- **LGPD.** Excluir a conta apaga relatos, comentários, vídeos, casos, provas e arquivos.
- **No aparelho:** o PIN fica como hash com sal no cofre do sistema, com 5 erros levando a 30 s de espera e 10 erros encerrando a sessão. A tela é coberta no seletor de apps, os prints são bloqueados (`expo-screen-capture`), o backup do Android fica desativado e as cópias baixadas são apagadas depois de compartilhadas.

### Principais rotas da API

| Área | Rotas |
| --- | --- |
| Cadastro | `POST /api/auth/verificacao/iniciar`, `…/confirmar`, `/cadastro`, `/entrar`, `/renovar`, `/redefinir-senha` |
| Comunidades | `GET /api/comunidades`, `GET /api/comunidades/:id/posts`, `POST /api/comunidades/:id/participar` |
| Relatos | `GET /api/posts/feed`, `POST /api/posts`, `POST /api/posts/verificar-texto`, `POST /api/posts/:id/reacoes`, `…/comentarios` |
| Vídeos | `GET /api/videos`, `POST /api/videos` (multipart), `GET /api/midia/videos/:id?exp&sig` (com Range) |
| Casos | `GET/POST /api/casos`, `POST /api/casos/:id/provas`, `GET /api/casos/:id/dossie.pdf`, `GET /api/casos/:id/pacote.zip`, `POST /api/casos/:id/compartilhar` |
| Equipe | `GET /api/equipe/resumo`, `/moderacao/posts?fila=`, `/moderacao/videos`, `/moderacao/sinalizacoes`, `/casos?filtro=` |

---

## O que falta para um piloto real

O MVP funciona de ponta a ponta, mas algumas partes são simuladas ou precisam de decisões institucionais:

1. **Verificação real de vínculo.** Hoje é o simulador do SIGA. O caminho recomendado é um acordo com a TIC/UFRJ para login via **CAFe (SAML)** ou uma API do SIGA. O contrato esperado já está em `backend/src/modules/auth/siga/http.ts`. Para abrir o app a docentes, técnicas e terceirizadas, o modelo já tem `vinculoTipo` (SIAPE ou aprovação manual).
2. **E-mail de verdade.** Defina `SMTP_URL` e instale o `nodemailer`.
3. **Infraestrutura.** HTTPS obrigatório, chave-mestra num cofre ou KMS (não no `.env`), armazenamento S3 ou MinIO com backup, transcodificação de vídeo (vídeos `.mov`/HEVC do iPhone podem não tocar em alguns Androids), rate limit compartilhado (Redis) e monitoramento.
4. **LGPD e jurídico.** Encarregado(a) de dados, relatório de impacto (RIPD), revisão dos termos e da política de retenção, e um protocolo para pedidos judiciais de dados.
5. **Conteúdo.** Os guias e contatos (`backend/src/modules/recursos/conteudo.ts`) foram conferidos em fontes oficiais em novembro de 2026, mas devem ser validados com a **Ouvidoria da Mulher**, o **CRM-SSA** e a **Defensoria**, e revisados periodicamente.
6. **Operação.** Escala de moderação e acolhimento, protocolo para relatos de risco imediato, notificações push para respostas, e testes de acessibilidade e de segurança (pentest).

## Estrutura

```
minerva-mae/
├── docker-compose.yml
├── backend/   API (src/), migrações (drizzle/), testes (tests/), fontes do PDF (assets/fonts, OFL)
└── mobile/    app Expo (src/), ícones e disfarces (assets/), plugin de nomes do Android (plugins/), scripts/gerar-icones.py
```
