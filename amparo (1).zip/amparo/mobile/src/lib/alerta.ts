import { Alert as AlertNativo, Platform, type AlertButton } from 'react-native';

/**
 * Mesmo uso do Alert do React Native, mas também funciona no navegador
 * (útil para a equipe usar o app no computador): lá vira window.alert/confirm.
 */
export const Alert = {
  alert(titulo: string, mensagem?: string, botoes?: AlertButton[]) {
    if (Platform.OS !== 'web') return AlertNativo.alert(titulo, mensagem, botoes);
    const texto = [titulo, mensagem].filter(Boolean).join('\n\n');
    const cancelar = botoes?.find((b) => b.style === 'cancel');
    const acoes = botoes?.filter((b) => b.style !== 'cancel') ?? [];
    if (cancelar && acoes.length) {
      if (globalThis.confirm(texto)) acoes.at(-1)?.onPress?.();
      else cancelar.onPress?.();
      return;
    }
    globalThis.alert(texto);
    acoes[0]?.onPress?.();
  },
};
