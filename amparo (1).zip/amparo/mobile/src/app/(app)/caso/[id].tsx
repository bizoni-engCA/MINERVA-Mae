import { useState } from 'react';
import { Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import { useCaso, useInvalidarCaso } from '@/api/consultas';
import { api, baixarECompartilhar, mensagemDeErro } from '@/api/cliente';
import type { Caso, Prova } from '@/api/tipos';
import { Opcoes } from '@/components/Opcoes';
import { SaidaRapida } from '@/components/SaidaRapida';
import { Aviso, Bloco, Botao, BotaoIcone, Carregando, Chip, Divisor, ErroTela, Etiqueta, Icone, Linha, Texto, Titulo, type NomeIcone } from '@/components/ui';
import { dataHora, plural, tamanho, tempoRelativo } from '@/lib/formatar';
import { EVENTOS_CASO, STATUS_CASO, TIPOS_VIOLENCIA, VINCULOS_AUTOR } from '@/lib/rotulos';
import { cores, espaco, fontes, raio } from '@/theme';

const ICONES_PROVA: Record<Prova['tipo'], NomeIcone> = {
  IMAGEM: 'image-outline',
  VIDEO: 'videocam-outline',
  AUDIO: 'mic-outline',
  DOCUMENTO: 'document-text-outline',
  OUTRO: 'attach-outline',
};

export default function DetalheCaso() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const q = useCaso(id);
  const invalidar = useInvalidarCaso(id);
  const [menu, setMenu] = useState(false);
  const [prova, setProva] = useState<Prova | null>(null);
  const [baixando, setBaixando] = useState<string | null>(null);
  const [relatoAberto, setRelatoAberto] = useState(false);
  const [todosEventos, setTodosEventos] = useState(false);

  if (q.isLoading) return <Carregando />;
  if (q.isError || !q.data) return <ErroTela mensagem={mensagemDeErro(q.error)} tentarDeNovo={q.refetch} />;
  const c = q.data;
  const s = STATUS_CASO[c.status];
  const dona = c.souDona;

  async function baixar(caminho: string, nome: string, mime: string, chave: string) {
    setBaixando(chave);
    try {
      await baixarECompartilhar(caminho, nome, mime);
      invalidar();
    } catch (e) {
      Alert.alert('Não foi possível baixar', mensagemDeErro(e));
    } finally {
      setBaixando(null);
    }
  }

  async function acao(fn: () => Promise<unknown>, sucesso?: string) {
    try {
      await fn();
      invalidar();
      if (sucesso) Alert.alert(sucesso);
    } catch (e) {
      Alert.alert('Erro', mensagemDeErro(e));
    }
  }

  const apagarCaso = () =>
    Alert.alert('Apagar este caso?', 'O relato e todas as provas serão apagados definitivamente. Gere o dossiê antes, se quiser guardar uma cópia.', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Apagar',
        style: 'destructive',
        onPress: () =>
          acao(async () => {
            await api(`/api/casos/${id}`, { metodo: 'DELETE' });
            router.back();
          }),
      },
    ]);

  const eventos = todosEventos ? c.eventos : c.eventos.slice(0, 5);

  return (
    <>
      <Stack.Screen
        options={{
          title: c.acessoEquipe ? 'Caso compartilhado' : 'Seu caso',
          headerRight: () => (
            <Linha espacamento={4}>
              {dona ? <BotaoIcone icone="ellipsis-horizontal" rotulo="Opções do caso" onPress={() => setMenu(true)} /> : null}
              <SaidaRapida />
            </Linha>
          ),
        }}
      />
      <ScrollView
        style={{ backgroundColor: cores.papel }}
        contentContainerStyle={{ padding: espaco.l, paddingBottom: espaco.xxl * 2 }}
        refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => void q.refetch()} tintColor={cores.lilas} />}
      >
        <Etiqueta texto={s.rotulo} cor={s.cor} fundo={s.fundo} />
        <Titulo style={{ marginTop: espaco.s }}>{c.dados.titulo}</Titulo>
        <Texto pequeno fraco style={{ marginTop: 4 }}>
          {c.acessoEquipe ? 'Compartilhado pela estudante. Cada acesso seu fica registrado na linha do tempo que ela vê.' : s.explicacao}
        </Texto>

        {/* Resumo */}
        <Bloco estilo={{ marginTop: espaco.l, gap: espaco.m }}>
          <Dado rotulo="Tipo de situação" valor={c.dados.tiposViolencia.map((t) => TIPOS_VIOLENCIA[t]).join(', ')} />
          <Dado rotulo="Quando" valor={[c.dados.dataOcorrido, c.dados.periodo].filter(Boolean).join(' — ')} />
          <Dado rotulo="Onde" valor={c.dados.local} />
          <Dado rotulo="Vínculo de quem cometeu" valor={c.dados.vinculoAutor ? VINCULOS_AUTOR[c.dados.vinculoAutor] : undefined} />
          {dona ? <Botao titulo="Editar relato" icone="create-outline" variante="secundario" compacto estilo={{ alignSelf: 'flex-start' }} onPress={() => router.push(`/caso/formulario?id=${id}`)} /> : null}
        </Bloco>

        <Secao titulo="O que aconteceu">
          {c.dados.relato ? (
            <Pressable onPress={() => setRelatoAberto(!relatoAberto)} accessibilityRole="button" accessibilityState={{ expanded: relatoAberto }}>
              <Texto numberOfLines={relatoAberto ? undefined : 8}>{c.dados.relato}</Texto>
              {c.dados.relato.length > 400 ? <Text style={estilos.link}>{relatoAberto ? 'Mostrar menos' : 'Ler tudo'}</Text> : null}
            </Pressable>
          ) : (
            <Texto fraco>Ainda sem relato. {dona ? 'Toque em “Editar relato” para escrever.' : ''}</Texto>
          )}
          {c.dados.pessoasEnvolvidas ? <Dado rotulo="Pessoas envolvidas" valor={c.dados.pessoasEnvolvidas} espaco /> : null}
          {c.dados.testemunhas ? <Dado rotulo="Testemunhas" valor={c.dados.testemunhas} espaco /> : null}
          {c.dados.impactos ? <Dado rotulo="Como isso afetou" valor={c.dados.impactos} espaco /> : null}
          {c.dados.providenciasTomadas ? <Dado rotulo="Providências já tomadas" valor={c.dados.providenciasTomadas} espaco /> : null}
          {c.dados.observacoes ? <Dado rotulo="Observações" valor={c.dados.observacoes} espaco /> : null}
        </Secao>

        {/* Provas */}
        <Secao titulo={`Provas (${c.provas.length})`}>
          {c.provas.length === 0 ? (
            <Texto fraco>Prints, fotos, áudios, e-mails e documentos ficam aqui, criptografados, com data e impressão digital.</Texto>
          ) : (
            c.provas.map((p) => (
              <Pressable key={p.id} onPress={() => setProva(p)} style={({ pressed }) => [estilos.prova, pressed && { opacity: 0.7 }]} accessibilityRole="button">
                <View style={estilos.provaIcone}>
                  <Icone nome={ICONES_PROVA[p.tipo]} cor={cores.lilas} />
                </View>
                <View style={{ flex: 1 }}>
                  <Texto negrito numberOfLines={1}>
                    {p.nomeOriginal}
                  </Texto>
                  {p.descricao ? (
                    <Texto pequeno numberOfLines={2}>
                      {p.descricao}
                    </Texto>
                  ) : null}
                  <Texto pequeno fraco>
                    Guardada {tempoRelativo(p.recebidoEm)} · {tamanho(p.tamanhoBytes)}
                  </Texto>
                </View>
                {baixando === p.id ? <Carregando /> : <Icone nome="ellipsis-vertical" cor={cores.nevoa} tamanho={18} />}
              </Pressable>
            ))
          )}
          {dona ? <Botao titulo="Adicionar prova" icone="add" variante="secundario" estilo={{ marginTop: espaco.m }} onPress={() => router.push(`/caso/prova?id=${id}`)} /> : null}
        </Secao>

        {/* Dossiê */}
        <Secao titulo="Dossiê">
          <Texto fraco style={{ marginBottom: espaco.m }}>
            Um PDF com o relato, a linha do tempo e a lista de provas com a impressão digital (SHA-256) e o recibo assinado de cada uma. O pacote
            completo inclui também os arquivos originais.
          </Texto>
          <Linha>
            <Botao
              titulo="Dossiê (PDF)"
              icone="document-text-outline"
              compacto
              carregando={baixando === 'pdf'}
              onPress={() => baixar(`/api/casos/${id}/dossie.pdf`, `dossie-${id.slice(0, 8)}.pdf`, 'application/pdf', 'pdf')}
            />
            <Botao
              titulo="Pacote (ZIP)"
              icone="archive-outline"
              variante="secundario"
              compacto
              carregando={baixando === 'zip'}
              onPress={() => baixar(`/api/casos/${id}/pacote.zip`, `pacote-${id.slice(0, 8)}.zip`, 'application/zip', 'zip')}
            />
          </Linha>
          {dona ? (
            <Pressable onPress={() => router.push('/orientacao/usar-dossie')} style={{ marginTop: espaco.m }}>
              <Text style={estilos.link}>Onde e como entregar o dossiê</Text>
            </Pressable>
          ) : null}
        </Secao>

        {/* Acolhimento */}
        {dona ? <Acolhimento caso={c} acao={acao} /> : <PainelEquipe caso={c} acao={acao} />}

        {/* Linha do tempo */}
        <Secao titulo="Linha do tempo">
          {eventos.map((e) => (
            <Linha key={e.id} estilo={estilos.evento} espacamento={espaco.m}>
              <View style={[estilos.eventoPonto, e.daEquipe && { backgroundColor: cores.ambar }]} />
              <View style={{ flex: 1 }}>
                <Texto pequeno negrito>
                  {EVENTOS_CASO[e.tipo] ?? e.tipo}
                  {e.daEquipe && e.apelido ? ` (${e.apelido})` : ''}
                  {e.tipo === 'STATUS_ALTERADO' && e.detalhe?.status ? `: ${STATUS_CASO[e.detalhe.status as keyof typeof STATUS_CASO]?.rotulo ?? ''}` : ''}
                </Texto>
                <Texto pequeno fraco>
                  {dataHora(e.criadoEm)}
                </Texto>
              </View>
            </Linha>
          ))}
          {c.eventos.length > 5 ? <Botao titulo={todosEventos ? 'Mostrar menos' : `Ver tudo (${c.eventos.length})`} variante="fantasma" compacto onPress={() => setTodosEventos(!todosEventos)} /> : null}
        </Secao>
      </ScrollView>

      <Opcoes visivel={menu} aoFechar={() => setMenu(false)} opcoes={[{ rotulo: 'Apagar caso', icone: 'trash-outline', perigo: true, onPress: apagarCaso }]} />
      <Opcoes
        visivel={!!prova}
        titulo={prova?.nomeOriginal}
        aoFechar={() => setProva(null)}
        opcoes={
          prova
            ? [
                {
                  rotulo: 'Abrir ou compartilhar',
                  icone: 'share-outline',
                  onPress: () => baixar(`/api/casos/${id}/provas/${prova.id}/arquivo`, prova.nomeOriginal, prova.mimeType, prova.id),
                },
                {
                  rotulo: 'Ver impressão digital',
                  icone: 'finger-print',
                  onPress: () =>
                    Alert.alert(
                      'Impressão digital (SHA-256)',
                      `${prova.sha256}\n\nRecebida pelo servidor em ${dataHora(prova.recebidoEm)}.\n\nSe o arquivo for alterado, mesmo que um pouco, este código muda.`,
                    ),
                },
                ...(dona
                  ? [
                      {
                        rotulo: 'Apagar prova',
                        icone: 'trash-outline' as const,
                        perigo: true,
                        onPress: () =>
                          Alert.alert('Apagar prova?', 'O arquivo será apagado definitivamente. A linha do tempo mantém o registro de que ele existiu.', [
                            { text: 'Cancelar', style: 'cancel' },
                            { text: 'Apagar', style: 'destructive', onPress: () => acao(() => api(`/api/casos/${id}/provas/${prova.id}`, { metodo: 'DELETE' })) },
                          ]),
                      },
                    ]
                  : []),
              ]
            : []
        }
      />
    </>
  );
}

function Acolhimento({ caso, acao }: { caso: Caso; acao: (fn: () => Promise<unknown>, ok?: string) => void }) {
  if (!caso.compartilhadoEm) {
    return (
      <Secao titulo="Orientação da equipe de acolhimento">
        <Texto fraco style={{ marginBottom: espaco.m }}>
          Quer ajuda para decidir os próximos passos ou entender como usar o dossiê? Compartilhe este caso com a equipe de acolhimento. Você pode
          parar de compartilhar quando quiser.
        </Texto>
        <Botao titulo="Pedir orientação" icone="people-outline" variante="apoio" onPress={() => router.push(`/caso/compartilhar?id=${caso.id}`)} />
      </Secao>
    );
  }
  return (
    <Secao titulo="Acolhimento">
      <Aviso tom="sucesso">{`Compartilhado em ${dataHora(caso.compartilhadoEm)}. ${STATUS_CASO[caso.status].explicacao}`}</Aviso>
      <Botao
        titulo={caso.mensagens.length ? `Abrir conversa (${plural(caso.mensagens.length, 'mensagem', 'mensagens')})` : 'Abrir conversa'}
        icone="chatbubbles-outline"
        estilo={{ marginTop: espaco.m }}
        onPress={() => router.push(`/caso/mensagens?id=${caso.id}`)}
      />
      <Botao
        titulo="Parar de compartilhar"
        variante="perigo"
        compacto
        estilo={{ marginTop: espaco.m, alignSelf: 'flex-start' }}
        onPress={() =>
          Alert.alert('Parar de compartilhar?', 'A equipe de acolhimento perde o acesso ao caso. A conversa fica guardada aqui para você.', [
            { text: 'Cancelar', style: 'cancel' },
            { text: 'Parar', style: 'destructive', onPress: () => acao(() => api(`/api/casos/${caso.id}/revogar-compartilhamento`, { metodo: 'POST' })) },
          ])
        }
      />
    </Secao>
  );
}

function PainelEquipe({ caso, acao }: { caso: Caso; acao: (fn: () => Promise<unknown>, ok?: string) => void }) {
  return (
    <Secao titulo="Acompanhamento">
      {caso.status === 'COMPARTILHADO' ? (
        <Botao titulo="Assumir este caso" icone="hand-left-outline" variante="apoio" onPress={() => acao(() => api(`/api/equipe/casos/${caso.id}/assumir`, { metodo: 'POST' }), 'Caso assumido')} />
      ) : (
        <>
          <Texto negrito style={{ marginBottom: espaco.s }}>Situação</Texto>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: espaco.s }}>
            {(['EM_ACOMPANHAMENTO', 'ENCAMINHADO', 'ENCERRADO'] as const).map((st) => (
              <Chip
                key={st}
                rotulo={STATUS_CASO[st].rotulo}
                ativo={caso.status === st}
                onPress={() => acao(() => api(`/api/equipe/casos/${caso.id}/status`, { metodo: 'PATCH', corpo: { status: st } }))}
              />
            ))}
          </View>
        </>
      )}
      <Botao titulo="Conversar com a estudante" icone="chatbubbles-outline" variante="secundario" estilo={{ marginTop: espaco.m }} onPress={() => router.push(`/caso/mensagens?id=${caso.id}`)} />
    </Secao>
  );
}

const Secao = ({ titulo, children }: { titulo: string; children: React.ReactNode }) => (
  <View>
    <Divisor />
    <Titulo nivel={3} style={{ marginBottom: espaco.m }}>
      {titulo}
    </Titulo>
    {children}
  </View>
);

const Dado = ({ rotulo, valor, espaco: comEspaco }: { rotulo: string; valor?: string; espaco?: boolean }) =>
  valor ? (
    <View style={comEspaco ? { marginTop: espaco.m } : undefined}>
      <Text style={estilos.dadoRotulo}>{rotulo}</Text>
      <Texto>{valor}</Texto>
    </View>
  ) : null;

const estilos = StyleSheet.create({
  link: { fontFamily: fontes.textoNegrito, color: cores.lilas, fontSize: 14, marginTop: 6 },
  dadoRotulo: { fontFamily: fontes.textoMedio, fontSize: 13, color: cores.nevoa, marginBottom: 2 },
  prova: { flexDirection: 'row', alignItems: 'center', gap: espaco.m, paddingVertical: espaco.m, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: cores.linha },
  provaIcone: { width: 42, height: 42, borderRadius: raio.medio, backgroundColor: cores.lilasClaro, alignItems: 'center', justifyContent: 'center' },
  evento: { alignItems: 'flex-start', paddingVertical: 6 },
  eventoPonto: { width: 9, height: 9, borderRadius: 5, backgroundColor: cores.lilas, marginTop: 6 },
});
