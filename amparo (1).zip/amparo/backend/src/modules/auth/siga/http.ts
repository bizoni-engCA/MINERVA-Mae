import { config } from '../../../config';
import { HttpError } from '../../../lib/errors';
import type { EstudanteSiga, SigaProvider } from './provider';

/**
 * Integração com uma API do SIGA (a ser disponibilizada pela TIC/UFRJ).
 *
 * Contrato esperado:
 *   GET {SIGA_API_URL}/estudantes/{dre}
 *   Authorization: Bearer {SIGA_API_TOKEN}
 *   200 → { "dre": "…", "situacao": "ATIVA|TRANCADA|CANCELADA|CONCLUIDA",
 *           "nivel": "GRADUACAO|POS_GRADUACAO", "emailInstitucional": "…@ufrj.br" }
 *   404 → DRE inexistente
 *
 * Só esses campos são usados. Nome, curso e demais dados pessoais NÃO devem ser pedidos.
 */
export class HttpSigaProvider implements SigaProvider {
  readonly nome = 'siga-http';

  async consultarEstudante(dre: string): Promise<EstudanteSiga | null> {
    if (!config.SIGA_API_URL || !config.SIGA_API_TOKEN) {
      throw new HttpError(503, 'Verificação com o SIGA não configurada.', 'SIGA_NAO_CONFIGURADO');
    }
    const resp = await fetch(`${config.SIGA_API_URL.replace(/\/$/, '')}/estudantes/${encodeURIComponent(dre)}`, {
      headers: { Authorization: `Bearer ${config.SIGA_API_TOKEN}`, Accept: 'application/json' },
      signal: AbortSignal.timeout(8000),
    });
    if (resp.status === 404) return null;
    if (!resp.ok) throw new HttpError(503, 'O SIGA não respondeu. Tente de novo em alguns minutos.', 'SIGA_INDISPONIVEL');
    const dados = (await resp.json()) as EstudanteSiga;
    return {
      dre: dados.dre,
      situacao: dados.situacao,
      nivel: dados.nivel,
      emailInstitucional: dados.emailInstitucional,
    };
  }
}
