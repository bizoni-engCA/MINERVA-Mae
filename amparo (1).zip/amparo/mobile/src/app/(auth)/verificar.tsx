import { useState } from 'react';
import { router, useLocalSearchParams } from 'expo-router';
import { ApiErro, api, mensagemDeErro } from '@/api/cliente';
import { Aviso, Botao, Campo, Espaco, Texto, Titulo, Tela } from '@/components/ui';
import { useFluxo } from '@/store/fluxo';
import { espaco } from '@/theme';

type Desafio = { desafioId: string; emailMascarado: string; codigoDev?: string };

export default function Verificar() {
  const { finalidade = 'CADASTRO' } = useLocalSearchParams<{ finalidade?: 'CADASTRO' | 'REDEFINIR_SENHA' }>();
  const definirToken = useFluxo((s) => s.definir);
  const [dre, setDre] = useState('');
  const [codigo, setCodigo] = useState('');
  const [desafio, setDesafio] = useState<Desafio | null>(null);
  const [erro, setErro] = useState<{ texto: string; codigo?: string } | null>(null);
  const [carregando, setCarregando] = useState(false);
  const recuperar = finalidade === 'REDEFINIR_SENHA';

  async function enviarDre() {
    setErro(null);
    setCarregando(true);
    try {
      setDesafio(await api<Desafio>('/api/auth/verificacao/iniciar', { corpo: { dre, finalidade }, semAuth: true }));
    } catch (e) {
      setErro({ texto: mensagemDeErro(e) });
    } finally {
      setCarregando(false);
    }
  }

  async function confirmar() {
    if (!desafio) return;
    setErro(null);
    setCarregando(true);
    try {
      const r = await api<{ tokenVerificacao: string }>('/api/auth/verificacao/confirmar', {
        corpo: { desafioId: desafio.desafioId, codigo },
        semAuth: true,
      });
      definirToken(r.tokenVerificacao);
      router.replace(recuperar ? '/nova-senha' : '/cadastro');
    } catch (e) {
      setErro({ texto: mensagemDeErro(e), codigo: e instanceof ApiErro ? e.codigo : undefined });
    } finally {
      setCarregando(false);
    }
  }

  return (
    <Tela>
      <Titulo>{recuperar ? 'Recuperar acesso' : 'Confirme que você é da UFRJ'}</Titulo>
      <Texto fraco style={{ marginTop: espaco.s, marginBottom: espaco.xl }}>
        {recuperar
          ? 'Informe seu DRE. Vamos enviar um código para o seu e-mail institucional para você criar uma nova senha.'
          : 'Por enquanto o Amparo é aberto a estudantes. Informe seu DRE: vamos enviar um código para o e-mail institucional cadastrado no SIGA.'}
      </Texto>

      {!desafio ? (
        <>
          <Campo
            rotulo="DRE"
            value={dre}
            onChangeText={(t) => setDre(t.replace(/\D/g, '').slice(0, 9))}
            keyboardType="number-pad"
            placeholder="9 dígitos"
            autoFocus
            ajuda="Seu DRE não fica guardado: o Amparo guarda só uma versão embaralhada e irreversível dele, que serve para evitar contas duplicadas."
          />
          {erro ? <Aviso tom="perigo">{erro.texto}</Aviso> : null}
          <Espaco />
          <Botao titulo="Enviar código" onPress={enviarDre} carregando={carregando} desativado={dre.length !== 9} />
        </>
      ) : (
        <>
          <Aviso tom="sucesso" titulo="Código enviado">
            {`Confira a caixa de entrada (e o spam) de ${desafio.emailMascarado}. O código vale por 10 minutos.`}
          </Aviso>
          {desafio.codigoDev ? (
            <>
              <Espaco altura={espaco.m} />
              <Aviso tom="cuidado" titulo="Modo de teste">
                {`O servidor está usando o simulador do SIGA. Seu código é ${desafio.codigoDev}.`}
              </Aviso>
            </>
          ) : null}
          <Espaco />
          <Campo
            rotulo="Código de 6 dígitos"
            value={codigo}
            onChangeText={(t) => setCodigo(t.replace(/\D/g, '').slice(0, 6))}
            keyboardType="number-pad"
            autoFocus
            textContentType="oneTimeCode"
            autoComplete="one-time-code"
          />
          {erro ? <Aviso tom="perigo">{erro.texto}</Aviso> : null}
          {erro?.codigo === 'CONTA_EXISTENTE' ? (
            <Botao titulo="Recuperar minha conta" variante="secundario" estilo={{ marginTop: espaco.m }} onPress={() => router.replace('/verificar?finalidade=REDEFINIR_SENHA')} />
          ) : null}
          {erro?.codigo === 'SEM_CONTA' ? (
            <Botao titulo="Criar uma conta" variante="secundario" estilo={{ marginTop: espaco.m }} onPress={() => router.replace('/verificar?finalidade=CADASTRO')} />
          ) : null}
          <Espaco />
          <Botao titulo="Confirmar" onPress={confirmar} carregando={carregando} desativado={codigo.length !== 6} />
          <Botao
            titulo="Usar outro DRE"
            variante="fantasma"
            estilo={{ marginTop: espaco.s }}
            onPress={() => {
              setDesafio(null);
              setCodigo('');
              setErro(null);
            }}
          />
        </>
      )}
    </Tela>
  );
}
