import { Router } from 'express';
import argon2 from 'argon2';
import rateLimit from 'express-rate-limit';
import { and, eq, gt, isNull, sql } from 'drizzle-orm';
import { config, isTest } from '../../config';
import { db, schema } from '../../db';
import { codigoNumerico, hashIdentificador, igualSeguro, sha256 } from '../../lib/crypto';
import { enviarEmail } from '../../lib/email';
import { HttpError } from '../../lib/errors';
import { emitirSessao, emitirVerificacao, lerVerificacao, renovarSessao, revogarSessao } from '../../lib/tokens';
import { validar, z } from '../../lib/validar';
import { perfilPublico } from '../me/perfil';
import { SITUACOES_ACEITAS, dreValido, sigaProvider } from './siga/provider';

export const authRouter = Router();

const limitar = (max: number) =>
  rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: max,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    skip: () => isTest,
    message: { erro: 'Muitas tentativas. Aguarde alguns minutos e tente de novo.', codigo: 'LIMITE' },
  });

const APELIDOS_RESERVADOS = ['anonima', 'anônima', 'moderacao', 'moderação', 'equipe', 'admin', 'amparo', 'minerva', 'minervamae', 'minerva.mae', 'minerva_mae', 'minerva-mae', 'acolhimento', 'ufrj'];

export const apelidoSchema = z
  .string()
  .trim()
  .min(3, 'O apelido precisa ter pelo menos 3 caracteres')
  .max(24, 'O apelido pode ter no máximo 24 caracteres')
  .regex(/^[\p{L}\p{N}._-]+$/u, 'Use só letras, números, ponto, hífen ou sublinhado')
  .refine((a) => !APELIDOS_RESERVADOS.includes(a.toLowerCase()), 'Este apelido é reservado');

export const senhaSchema = z
  .string()
  .min(8, 'A senha precisa ter pelo menos 8 caracteres')
  .max(128, 'A senha é longa demais');

const mascararEmail = (email: string) => {
  const [usuario, dominio] = email.split('@');
  if (!usuario || !dominio) return '***';
  return `${usuario.slice(0, 2)}${'*'.repeat(Math.max(usuario.length - 2, 3))}@${dominio}`;
};

const apelidoEmUso = async (apelido: string) => {
  const [r] = await db
    .select({ id: schema.usuarias.id })
    .from(schema.usuarias)
    .where(sql`lower(${schema.usuarias.apelido}) = lower(${apelido})`);
  return Boolean(r);
};

// 1) Informa o DRE → o código vai para o e-mail institucional cadastrado no SIGA.
authRouter.post('/verificacao/iniciar', limitar(8), async (req, res) => {
  const { dre, finalidade } = validar(
    z.object({
      dre: z.string().trim().transform((d) => d.replace(/\D/g, '')),
      finalidade: z.enum(['CADASTRO', 'REDEFINIR_SENHA']).default('CADASTRO'),
    }),
    req.body,
  );
  if (!dreValido(dre)) throw new HttpError(400, 'O DRE tem 9 dígitos. Confira e tente de novo.', 'DRE_INVALIDO');

  const estudante = await sigaProvider.consultarEstudante(dre);
  if (!estudante) throw new HttpError(404, 'Não encontramos esse DRE no SIGA.', 'DRE_NAO_ENCONTRADO');
  if (!SITUACOES_ACEITAS.includes(estudante.situacao)) {
    throw new HttpError(
      403,
      'Por enquanto a Minerva Mãe está aberta só para estudantes com matrícula ativa ou trancada.',
      'MATRICULA_INATIVA',
    );
  }

  const vinculoHash = hashIdentificador('ESTUDANTE', dre);

  // Limite por DRE, além do limite por IP.
  const [{ recentes }] = await db
    .select({ recentes: sql<number>`count(*)::int` })
    .from(schema.desafiosVerificacao)
    .where(
      and(
        eq(schema.desafiosVerificacao.vinculoHash, vinculoHash),
        gt(schema.desafiosVerificacao.criadoEm, new Date(Date.now() - 15 * 60 * 1000)),
      ),
    );
  if (recentes >= 3 && !isTest) {
    throw new HttpError(429, 'Já enviamos vários códigos para este DRE. Aguarde 15 minutos.', 'LIMITE');
  }

  const codigo = codigoNumerico();
  const [desafio] = await db
    .insert(schema.desafiosVerificacao)
    .values({
      vinculoTipo: 'ESTUDANTE',
      vinculoHash,
      codigoHash: 'pendente',
      finalidade,
      expiraEm: new Date(Date.now() + 10 * 60 * 1000),
    })
    .returning();
  await db
    .update(schema.desafiosVerificacao)
    .set({ codigoHash: sha256(`${desafio.id}:${codigo}`) })
    .where(eq(schema.desafiosVerificacao.id, desafio.id));

  // Não revelamos aqui se o DRE já tem conta: só quem recebe o código fica sabendo.
  await enviarEmail({
    para: estudante.emailInstitucional,
    assunto: 'Seu código de verificação',
    texto: `Seu código é ${codigo}. Ele vale por 10 minutos.\n\nSe não foi você quem pediu, ignore este e-mail.`,
  });

  res.status(201).json({
    desafioId: desafio.id,
    emailMascarado: mascararEmail(estudante.emailInstitucional),
    expiraEm: desafio.expiraEm,
    ...(config.DEV_MOSTRAR_CODIGOS || isTest ? { codigoDev: codigo } : {}),
  });
});

// 2) Confirma o código → recebe um token de verificação de curta duração.
authRouter.post('/verificacao/confirmar', limitar(20), async (req, res) => {
  const { desafioId, codigo } = validar(
    z.object({ desafioId: z.uuid(), codigo: z.string().trim().regex(/^\d{6}$/, 'O código tem 6 dígitos') }),
    req.body,
  );

  const [desafio] = await db
    .select()
    .from(schema.desafiosVerificacao)
    .where(and(eq(schema.desafiosVerificacao.id, desafioId), isNull(schema.desafiosVerificacao.usadoEm)));
  if (!desafio || desafio.expiraEm < new Date()) {
    throw new HttpError(400, 'Código expirado. Peça um novo.', 'CODIGO_EXPIRADO');
  }
  if (desafio.tentativas >= 5) throw new HttpError(429, 'Tentativas esgotadas. Peça um novo código.', 'CODIGO_BLOQUEADO');

  await db
    .update(schema.desafiosVerificacao)
    .set({ tentativas: desafio.tentativas + 1 })
    .where(eq(schema.desafiosVerificacao.id, desafio.id));

  if (!igualSeguro(sha256(`${desafio.id}:${codigo}`), desafio.codigoHash)) {
    throw new HttpError(400, 'Código incorreto.', 'CODIGO_INCORRETO');
  }
  await db
    .update(schema.desafiosVerificacao)
    .set({ usadoEm: new Date() })
    .where(eq(schema.desafiosVerificacao.id, desafio.id));

  const [existente] = await db
    .select({ id: schema.usuarias.id })
    .from(schema.usuarias)
    .where(eq(schema.usuarias.vinculoHash, desafio.vinculoHash));

  if (desafio.finalidade === 'CADASTRO' && existente) {
    throw new HttpError(409, 'Já existe uma conta para este DRE. Use "Esqueci minha senha" para recuperar o acesso.', 'CONTA_EXISTENTE');
  }
  if (desafio.finalidade === 'REDEFINIR_SENHA' && !existente) {
    throw new HttpError(404, 'Não há conta para este DRE. Você pode criar uma.', 'SEM_CONTA');
  }

  res.json({
    tokenVerificacao: emitirVerificacao({
      vinculoTipo: desafio.vinculoTipo,
      vinculoHash: desafio.vinculoHash,
      finalidade: desafio.finalidade,
    }),
  });
});

authRouter.get('/apelido-disponivel', async (req, res) => {
  const r = apelidoSchema.safeParse(req.query.apelido);
  if (!r.success) return void res.json({ disponivel: false, motivo: r.error.issues[0]?.message });
  res.json({ disponivel: !(await apelidoEmUso(r.data)) });
});

// 3) Cria a conta.
authRouter.post('/cadastro', limitar(10), async (req, res) => {
  const dados = validar(
    z.object({
      tokenVerificacao: z.string(),
      apelido: apelidoSchema,
      senha: senhaSchema,
      autodeclaracao: z.literal(true, 'Confirme a autodeclaração para continuar'),
      aceiteTermos: z.literal(true, 'É preciso aceitar os termos de uso'),
    }),
    req.body,
  );
  const verificacao = lerVerificacao(dados.tokenVerificacao, 'CADASTRO');

  if (await apelidoEmUso(dados.apelido)) throw new HttpError(409, 'Esse apelido já está em uso.', 'APELIDO_EM_USO');

  const senhaHash = await argon2.hash(dados.senha, { type: argon2.argon2id });
  let usuaria;
  try {
    [usuaria] = await db
      .insert(schema.usuarias)
      .values({
        apelido: dados.apelido,
        senhaHash,
        vinculoTipo: verificacao.vinculoTipo,
        vinculoHash: verificacao.vinculoHash,
        autodeclaracaoEm: new Date(),
        termosVersao: config.TERMOS_VERSAO,
      })
      .returning();
  } catch (e) {
    if ((e as { cause?: { code?: string }; code?: string }).cause?.code === '23505' || (e as { code?: string }).code === '23505') {
      throw new HttpError(409, 'Já existe uma conta para este DRE ou apelido.', 'CONTA_EXISTENTE');
    }
    throw e;
  }

  res.status(201).json({ usuaria: perfilPublico(usuaria), ...(await emitirSessao(usuaria)) });
});

// Hash fixo usado quando o apelido não existe, para o tempo de resposta não revelar isso.
const HASH_FALSO = argon2.hash('senha-que-ninguem-usa', { type: argon2.argon2id });

authRouter.post('/entrar', limitar(15), async (req, res) => {
  const { apelido, senha } = validar(z.object({ apelido: z.string().trim(), senha: z.string() }), req.body);
  const [usuaria] = await db
    .select()
    .from(schema.usuarias)
    .where(sql`lower(${schema.usuarias.apelido}) = lower(${apelido})`);

  const ok = await argon2.verify(usuaria?.senhaHash ?? (await HASH_FALSO), senha);
  if (!usuaria || !ok) throw new HttpError(401, 'Apelido ou senha incorretos.', 'CREDENCIAIS_INVALIDAS');
  if (usuaria.status === 'BANIDA') throw new HttpError(403, 'Esta conta foi banida por violar as regras.', 'CONTA_BANIDA');
  if (usuaria.status === 'SUSPENSA') throw new HttpError(403, 'Esta conta está suspensa temporariamente.', 'CONTA_SUSPENSA');

  res.json({ usuaria: perfilPublico(usuaria), ...(await emitirSessao(usuaria)) });
});

authRouter.post('/renovar', async (req, res) => {
  const { tokenRenovacao } = validar(z.object({ tokenRenovacao: z.string().min(10) }), req.body);
  const { usuaria, ...sessao } = await renovarSessao(tokenRenovacao);
  res.json({ usuaria: perfilPublico(usuaria), ...sessao });
});

authRouter.post('/sair', async (req, res) => {
  const { tokenRenovacao } = validar(z.object({ tokenRenovacao: z.string() }), req.body);
  await revogarSessao(tokenRenovacao);
  res.status(204).end();
});

authRouter.post('/redefinir-senha', limitar(10), async (req, res) => {
  const { tokenVerificacao, novaSenha } = validar(
    z.object({ tokenVerificacao: z.string(), novaSenha: senhaSchema }),
    req.body,
  );
  const verificacao = lerVerificacao(tokenVerificacao, 'REDEFINIR_SENHA');
  const [usuaria] = await db
    .update(schema.usuarias)
    .set({
      senhaHash: await argon2.hash(novaSenha, { type: argon2.argon2id }),
      versaoToken: sql`${schema.usuarias.versaoToken} + 1`,
    })
    .where(eq(schema.usuarias.vinculoHash, verificacao.vinculoHash))
    .returning();
  if (!usuaria) throw new HttpError(404, 'Conta não encontrada.', 'SEM_CONTA');

  await db
    .update(schema.refreshTokens)
    .set({ revogadoEm: new Date() })
    .where(and(eq(schema.refreshTokens.usuariaId, usuaria.id), isNull(schema.refreshTokens.revogadoEm)));

  res.json({ usuaria: perfilPublico(usuaria), ...(await emitirSessao(usuaria)) });
});
