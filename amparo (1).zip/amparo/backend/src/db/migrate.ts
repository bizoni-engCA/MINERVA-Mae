import { migrate } from 'drizzle-orm/node-postgres/migrator';
import { db, pool } from './index';

await migrate(db, { migrationsFolder: './drizzle' });
console.log('✅ Banco de dados atualizado.');
await pool.end();
