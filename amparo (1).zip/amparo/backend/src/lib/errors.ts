export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
    public codigo?: string,
  ) {
    super(message);
  }
}

export const naoEncontrado = (o = 'Item') => new HttpError(404, `${o} não encontrado.`, 'NAO_ENCONTRADO');
export const proibido = (m = 'Você não tem permissão para isso.') => new HttpError(403, m, 'PROIBIDO');
export const invalido = (m: string, codigo = 'INVALIDO') => new HttpError(400, m, codigo);
