import { useCallback, useEffect, useState } from 'react';
import { View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { queryClient } from '@/api/consultas';
import { PinPad } from '@/components/PinPad';
import { Botao, Texto, Titulo } from '@/components/ui';
import { autenticarComBiometria } from '@/lib/biometria';
import { useSeguranca } from '@/store/seguranca';
import { useSessao } from '@/store/sessao';
import { cores, espaco } from '@/theme';

export default function Bloqueio() {
  const insets = useSafeAreaInsets();
  const { biometria, conferirPin, desbloquear } = useSeguranca();
  const [pin, setPin] = useState('');
  const [mensagem, setMensagem] = useState<string | null>(null);
  const [erro, setErro] = useState(false);

  const usarBiometria = useCallback(async () => {
    if (await autenticarComBiometria()) desbloquear();
  }, [desbloquear]);

  useEffect(() => {
    if (biometria) usarBiometria();
  }, [biometria, usarBiometria]);

  useEffect(() => {
    if (pin.length !== 6) return;
    conferirPin(pin).then(async (r) => {
      if (r === 'ok') return;
      setErro(true);
      if (r === 'aguarde') setMensagem('Muitas tentativas. Aguarde 30 segundos.');
      else if (r === 'excedido') {
        await sairDaConta();
        return;
      } else setMensagem('PIN incorreto.');
      setTimeout(() => {
        setPin('');
        setErro(false);
      }, 600);
    });
  }, [pin, conferirPin]);

  return (
    <View style={{ flex: 1, backgroundColor: cores.papel, alignItems: 'center', paddingTop: insets.top + espaco.xxl * 1.5, paddingHorizontal: espaco.xl }}>
      <Titulo centro>Digite seu PIN</Titulo>
      <Texto fraco centro style={{ marginTop: espaco.s, marginBottom: espaco.xxl, minHeight: 24 }}>
        {mensagem ?? ' '}
      </Texto>
      <PinPad
        valor={pin}
        aoMudar={(v) => {
          setMensagem(null);
          setPin(v);
        }}
        erro={erro}
        acaoExtra={biometria ? { icone: 'finger-print', rotulo: 'Usar biometria', onPress: usarBiometria } : undefined}
      />
      <Botao
        titulo="Esqueci meu PIN"
        variante="fantasma"
        estilo={{ marginTop: espaco.xl }}
        onPress={() =>
          Alert.alert('Esqueceu o PIN?', 'Você vai sair da conta neste aparelho. Seus dados continuam guardados: entre de novo com apelido e senha e crie um novo PIN.', [
            { text: 'Cancelar', style: 'cancel' },
            { text: 'Sair da conta', style: 'destructive', onPress: sairDaConta },
          ])
        }
      />
    </View>
  );
}

async function sairDaConta() {
  queryClient.clear();
  await useSeguranca.getState().apagarTudo();
  await useSessao.getState().limpar();
}
