import request from 'supertest';
import { eq } from 'drizzle-orm';
import { criarApp } from '../src/app';
import { db, schema } from '../src/db';

export const app = criarApp();
export const api = () => request(app);

let contador = 0;
/** DRE de 9 dígitos único por execução. */
export const novoDre = () => `7${String(Date.now()).slice(-5)}${String(contador++).padStart(3, '0')}`;

export async function cadastrar(apelido: string, papel?: 'MODERADORA' | 'ACOLHIMENTO' | 'ADMIN') {
  const dre = novoDre();
  const ini = await api().post('/api/auth/verificacao/iniciar').send({ dre });
  if (ini.status !== 201) throw new Error(`iniciar: ${ini.status} ${JSON.stringify(ini.body)}`);
  const conf = await api()
    .post('/api/auth/verificacao/confirmar')
    .send({ desafioId: ini.body.desafioId, codigo: ini.body.codigoDev });
  const cad = await api().post('/api/auth/cadastro').send({
    tokenVerificacao: conf.body.tokenVerificacao,
    apelido,
    senha: 'senha-segura-123',
    autodeclaracao: true,
    aceiteTermos: true,
  });
  if (cad.status !== 201) throw new Error(`cadastro: ${cad.status} ${JSON.stringify(cad.body)}`);
  let token = cad.body.tokenAcesso as string;
  if (papel) {
    await db.update(schema.usuarias).set({ papel }).where(eq(schema.usuarias.id, cad.body.usuaria.id));
    const login = await api().post('/api/auth/entrar').send({ apelido, senha: 'senha-segura-123' });
    token = login.body.tokenAcesso;
  }
  return { id: cad.body.usuaria.id as string, token, dre, auth: { Authorization: `Bearer ${token}` } };
}

export async function criarComunidade(slug = `teste-${Date.now()}`) {
  const [c] = await db
    .insert(schema.comunidades)
    .values({ slug, nome: `Comunidade ${slug}`, descricao: 'Comunidade usada nos testes automatizados.' })
    .returning();
  return c;
}
