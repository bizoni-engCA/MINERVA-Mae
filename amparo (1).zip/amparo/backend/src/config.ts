import 'dotenv/config';
import { z } from 'zod';

const bool = z
  .enum(['true', 'false', '1', '0'])
  .transform((v) => v === 'true' || v === '1');

const base64Key = (nome: string) =>
  z.string().refine((v) => Buffer.from(v, 'base64').length === 32, {
    message: `${nome} precisa ser uma chave de 32 bytes em base64 (rode "npm run init")`,
  });

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().default(3333),
  DATABASE_URL: z.string().min(1, 'Defina DATABASE_URL'),

  // Segredos — gerados por `npm run init`
  JWT_SECRET: z.string().min(32),
  MASTER_KEY: base64Key('MASTER_KEY'),
  HASH_PEPPER: z.string().min(32),
  MEDIA_URL_SECRET: z.string().min(32),
  RECEIPT_PRIVATE_KEY: z.string().min(40),

  STORAGE_DIR: z.string().default('./storage'),
  CORS_ORIGINS: z.string().default('*'),

  // Verificação de vínculo (SIGA)
  SIGA_PROVIDER: z.enum(['mock', 'http']).default('mock'),
  SIGA_API_URL: z.string().optional(),
  SIGA_API_TOKEN: z.string().optional(),
  SIGA_MOCK_ACEITAR_QUALQUER_DRE: bool.default(true),

  // Em desenvolvimento, devolve o código de verificação na resposta da API
  DEV_MOSTRAR_CODIGOS: bool.default(false),
  SMTP_URL: z.string().optional(),
  EMAIL_REMETENTE: z.string().default('Amparo <nao-responda@amparo.local>'),

  MAX_PROVA_MB: z.coerce.number().default(50),
  MAX_VIDEO_MB: z.coerce.number().default(100),
  TERMOS_VERSAO: z.string().default('2026-11'),
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  console.error('\n❌ Configuração inválida no .env:\n');
  for (const issue of parsed.error.issues) {
    console.error(`  • ${issue.path.join('.')}: ${issue.message}`);
  }
  console.error('\nDica: rode "npm run init" para criar o .env com chaves novas.\n');
  process.exit(1);
}

export const config = parsed.data;
export const isProd = config.NODE_ENV === 'production';
export const isTest = config.NODE_ENV === 'test';
