import { Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { cores, espaco, fontes, raio } from '@/theme';
import { Icone, type NomeIcone } from './ui';

export type Opcao = { rotulo: string; icone?: NomeIcone; perigo?: boolean; onPress: () => void };

/** Folha de opções na parte de baixo da tela. */
export function Opcoes({ visivel, titulo, opcoes, aoFechar }: { visivel: boolean; titulo?: string; opcoes: Opcao[]; aoFechar: () => void }) {
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={visivel} transparent animationType="slide" onRequestClose={aoFechar}>
      <Pressable style={estilos.fundo} onPress={aoFechar} accessibilityLabel="Fechar" />
      <View style={[estilos.folha, { paddingBottom: insets.bottom + espaco.m }]}>
        <View style={estilos.alca} />
        {titulo ? <Text style={estilos.titulo}>{titulo}</Text> : null}
        {opcoes.map((o) => (
          <Pressable
            key={o.rotulo}
            onPress={() => {
              aoFechar();
              o.onPress();
            }}
            style={({ pressed }) => [estilos.opcao, pressed && { backgroundColor: cores.papel }]}
            accessibilityRole="button"
          >
            {o.icone ? <Icone nome={o.icone} cor={o.perigo ? cores.sinal : cores.tintaSuave} /> : null}
            <Text style={[estilos.rotulo, o.perigo && { color: cores.sinal }]}>{o.rotulo}</Text>
          </Pressable>
        ))}
        <Pressable onPress={aoFechar} style={[estilos.opcao, { justifyContent: 'center' }]} accessibilityRole="button">
          <Text style={[estilos.rotulo, { color: cores.nevoa }]}>Cancelar</Text>
        </Pressable>
      </View>
    </Modal>
  );
}

const estilos = StyleSheet.create({
  fundo: { flex: 1, backgroundColor: 'rgba(30,15,50,0.35)' },
  folha: { backgroundColor: cores.superficie, borderTopLeftRadius: raio.grande, borderTopRightRadius: raio.grande, paddingHorizontal: espaco.l, paddingTop: espaco.s },
  alca: { alignSelf: 'center', width: 40, height: 4, borderRadius: 2, backgroundColor: cores.linha, marginBottom: espaco.m },
  titulo: { fontFamily: fontes.tituloMedio, fontSize: 17, color: cores.tinta, marginBottom: espaco.s, paddingHorizontal: 4 },
  opcao: { flexDirection: 'row', alignItems: 'center', gap: espaco.m, paddingVertical: 14, paddingHorizontal: 4, borderRadius: raio.pequeno },
  rotulo: { fontFamily: fontes.textoMedio, fontSize: 16, color: cores.tinta },
});
