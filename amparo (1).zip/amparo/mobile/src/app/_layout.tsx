import { useEffect, useRef, useState } from 'react';
import { AppState, Platform, StyleSheet, View } from 'react-native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import * as ScreenCapture from 'expo-screen-capture';
import { QueryClientProvider } from '@tanstack/react-query';
import { BricolageGrotesque_600SemiBold } from '@expo-google-fonts/bricolage-grotesque/600SemiBold';
import { BricolageGrotesque_700Bold } from '@expo-google-fonts/bricolage-grotesque/700Bold';
import { AtkinsonHyperlegibleNext_400Regular } from '@expo-google-fonts/atkinson-hyperlegible-next/400Regular';
import { AtkinsonHyperlegibleNext_600SemiBold } from '@expo-google-fonts/atkinson-hyperlegible-next/600SemiBold';
import { AtkinsonHyperlegibleNext_700Bold } from '@expo-google-fonts/atkinson-hyperlegible-next/700Bold';
import { queryClient } from '@/api/consultas';
import { useSeguranca } from '@/store/seguranca';
import { useSessao } from '@/store/sessao';
import { useEstadoApp } from '@/lib/estado';
import { cores } from '@/theme';

// Quando a tela atual deixa de ser permitida (ex.: bloqueio), o app volta para a porta de entrada.
export const unstable_settings = { initialRouteName: 'index' };

export default function RaizLayout() {
  const [fontesProntas] = useFonts({
    BricolageGrotesque_600SemiBold,
    BricolageGrotesque_700Bold,
    AtkinsonHyperlegibleNext_400Regular,
    AtkinsonHyperlegibleNext_600SemiBold,
    AtkinsonHyperlegibleNext_700Bold,
  });
  const sessaoCarregada = useSessao((s) => s.carregada);
  const segurancaCarregada = useSeguranca((s) => s.carregada);
  const estado = useEstadoApp();
  const telaBloqueio = useSeguranca((s) => s.telaBloqueio);
  const [privacidade, setPrivacidade] = useState(false);

  useEffect(() => {
    useSessao.getState().carregar();
    useSeguranca.getState().carregar();
  }, []);

  // Impede prints/gravação de tela e esconde o conteúdo na lista de apps recentes (Android).
  useEffect(() => {
    if (Platform.OS !== 'web') ScreenCapture.preventScreenCaptureAsync('amparo').catch(() => {});
  }, []);

  useBloqueioAutomatico(setPrivacidade);

  if (!fontesProntas || !sessaoCarregada || !segurancaCarregada) {
    return <View style={{ flex: 1, backgroundColor: cores.papel }} />;
  }

  const telasBloqueio =
    telaBloqueio === 'calculadora'
      ? [<Stack.Screen key="c" name="calculadora" />, <Stack.Screen key="p" name="bloqueio" />]
      : [<Stack.Screen key="p" name="bloqueio" />, <Stack.Screen key="c" name="calculadora" />];

  return (
    <QueryClientProvider client={queryClient}>
      <StatusBar style="dark" />
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: cores.papel }, animation: 'fade' }}>
        <Stack.Screen name="index" />
        <Stack.Protected guard={estado === 'anonima'}>
          <Stack.Screen name="(auth)" />
        </Stack.Protected>
        <Stack.Protected guard={estado === 'configurar'}>
          <Stack.Screen name="configurar-seguranca" />
        </Stack.Protected>
        <Stack.Protected guard={estado === 'bloqueada'}>{telasBloqueio}</Stack.Protected>
        <Stack.Protected guard={estado === 'liberada'}>
          <Stack.Screen name="(app)" />
        </Stack.Protected>
      </Stack>
      {privacidade && estado === 'liberada' ? <View style={[StyleSheet.absoluteFill, { backgroundColor: cores.papel }]} /> : null}
    </QueryClientProvider>
  );
}

/**
 * Bloqueia o app quando ele fica em segundo plano por mais tempo que o
 * configurado, e cobre a tela enquanto está inativo (seletor de apps do iOS).
 */
function useBloqueioAutomatico(setPrivacidade: (v: boolean) => void) {
  const saiuEm = useRef<number | null>(null);
  useEffect(() => {
    const sub = AppState.addEventListener('change', (estado) => {
      const seg = useSeguranca.getState();
      if (estado === 'active') {
        setPrivacidade(false);
        if (saiuEm.current && seg.pinHash && Date.now() - saiuEm.current >= seg.bloqueioAutomaticoSeg * 1000) {
          seg.bloquear();
          queryClient.clear();
        }
        saiuEm.current = null;
      } else {
        setPrivacidade(true);
        if (estado === 'background' && !saiuEm.current) saiuEm.current = Date.now();
        if (seg.pinHash && seg.bloqueioAutomaticoSeg === 0 && estado === 'background') seg.bloquear();
      }
    });
    return () => sub.remove();
  }, [setPrivacidade]);
}
