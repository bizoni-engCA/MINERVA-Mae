/**
 * Verificação de vínculo com a UFRJ.
 *
 * O MVP usa um SIMULADOR do SIGA. Para produção existem dois caminhos, ambos
 * dependentes de acordo com a TIC/UFRJ:
 *   1. CAFe (Comunidade Acadêmica Federada/RNP) — login SAML pela própria UFRJ,
 *      que devolve atributos como vínculo de estudante. Elimina o código por e-mail.
 *   2. Uma API do SIGA que responda ao contrato abaixo (HttpSigaProvider).
 */
import { config } from '../../../config';
import { HttpSigaProvider } from './http';
import { MockSigaProvider } from './mock';

export type SituacaoMatricula = 'ATIVA' | 'TRANCADA' | 'CANCELADA' | 'CONCLUIDA';

export type EstudanteSiga = {
  dre: string;
  situacao: SituacaoMatricula;
  nivel: 'GRADUACAO' | 'POS_GRADUACAO';
  /** Para onde vai o código de confirmação (prova de que a pessoa é dona do DRE). */
  emailInstitucional: string;
};

export interface SigaProvider {
  readonly nome: string;
  consultarEstudante(dre: string): Promise<EstudanteSiga | null>;
}

export const SITUACOES_ACEITAS: SituacaoMatricula[] = ['ATIVA', 'TRANCADA'];

export const sigaProvider: SigaProvider =
  config.SIGA_PROVIDER === 'http' ? new HttpSigaProvider() : new MockSigaProvider();

export const dreValido = (dre: string) => /^\d{9}$/.test(dre);
