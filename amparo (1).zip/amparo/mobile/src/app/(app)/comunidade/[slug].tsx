import { useState } from 'react';
import { FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import { useComunidade, useParticipar, usePostsComunidade } from '@/api/consultas';
import { mensagemDeErro } from '@/api/cliente';
import { CartaoRelato } from '@/components/CartaoRelato';
import { Botao, Carregando, ErroTela, Icone, Linha, Texto, Vazio, type NomeIcone } from '@/components/ui';
import { plural } from '@/lib/formatar';
import { cores, espaco, fontes } from '@/theme';

export default function PaginaComunidade() {
  const { slug } = useLocalSearchParams<{ slug: string }>();
  const c = useComunidade(slug);
  const posts = usePostsComunidade(c.data?.id);
  const participar = useParticipar();
  const [regras, setRegras] = useState(false);

  if (c.isLoading) return <Carregando />;
  if (c.isError || !c.data) return <ErroTela mensagem={mensagemDeErro(c.error)} tentarDeNovo={c.refetch} />;
  const com = c.data;
  const itens = posts.data?.pages.flatMap((p) => p.itens) ?? [];

  return (
    <>
      <Stack.Screen options={{ title: com.nome }} />
      <FlatList
        style={{ backgroundColor: cores.papel }}
        contentContainerStyle={{ padding: espaco.l, paddingBottom: espaco.xxl }}
        data={itens}
        keyExtractor={(p) => p.id}
        renderItem={({ item }) => <CartaoRelato post={item} />}
        onEndReached={() => posts.hasNextPage && !posts.isFetchingNextPage && posts.fetchNextPage()}
        refreshControl={<RefreshControl refreshing={posts.isRefetching} onRefresh={() => void posts.refetch()} tintColor={cores.lilas} />}
        ListHeaderComponent={
          <View style={{ marginBottom: espaco.l }}>
            <View style={[estilos.faixa, { backgroundColor: com.cor }]}>
              <Icone nome={com.icone as NomeIcone} cor="#FFF" tamanho={26} />
            </View>
            <Texto style={{ marginTop: espaco.m }}>{com.descricao}</Texto>
            <Texto pequeno fraco style={{ marginTop: 4 }}>
              {plural(com.membros, 'participante', 'participantes')} · {plural(com.relatos, 'relato', 'relatos')}
            </Texto>
            {com.regras ? (
              <Pressable onPress={() => setRegras(!regras)} style={{ marginTop: espaco.m }} accessibilityRole="button" accessibilityState={{ expanded: regras }}>
                <Linha espacamento={6}>
                  <Icone nome="document-text-outline" tamanho={16} cor={cores.lilas} />
                  <Text style={estilos.link}>{regras ? 'Esconder regras' : 'Ver regras da comunidade'}</Text>
                </Linha>
                {regras ? (
                  <Texto pequeno style={{ marginTop: espaco.s }}>
                    {com.regras}
                  </Texto>
                ) : null}
              </Pressable>
            ) : null}
            <Linha estilo={{ marginTop: espaco.l }}>
              <Botao titulo="Escrever aqui" icone="create-outline" compacto onPress={() => router.push(`/relato/novo?comunidadeId=${com.id}`)} />
              <Botao
                compacto
                variante="secundario"
                titulo={com.souMembro ? 'Participando' : 'Participar'}
                carregando={participar.isPending}
                onPress={() => participar.mutate({ id: com.id, participar: !com.souMembro })}
              />
            </Linha>
          </View>
        }
        ListEmptyComponent={
          posts.isLoading ? <Carregando /> : <Vazio icone="leaf-outline" titulo="Ainda sem relatos" texto="Os relatos publicados aqui aparecem nesta lista." />
        }
      />
    </>
  );
}

const estilos = StyleSheet.create({
  faixa: { width: 52, height: 52, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  link: { fontFamily: fontes.textoNegrito, color: cores.lilas, fontSize: 14 },
});
