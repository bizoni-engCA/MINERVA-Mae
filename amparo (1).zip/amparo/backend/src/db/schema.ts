import { sql } from 'drizzle-orm';
import {
  boolean,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  primaryKey,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from 'drizzle-orm/pg-core';

const criadoEm = () => timestamp('criado_em', { withTimezone: true }).notNull().defaultNow();

// ── Enums ─────────────────────────────────────────────────────────
export const papelEnum = pgEnum('papel', ['USUARIA', 'MODERADORA', 'ACOLHIMENTO', 'ADMIN']);
export const vinculoEnum = pgEnum('vinculo_tipo', ['ESTUDANTE', 'DOCENTE', 'TECNICA', 'TERCEIRIZADA']);
export const contaStatusEnum = pgEnum('conta_status', ['ATIVA', 'SUSPENSA', 'BANIDA']);
export const desafioFinalidadeEnum = pgEnum('desafio_finalidade', ['CADASTRO', 'REDEFINIR_SENHA']);
export const conteudoStatusEnum = pgEnum('conteudo_status', [
  'PUBLICADO',
  'EM_REVISAO',
  'REJEITADO',
  'REMOVIDO',
]);
export const visibilidadeEnum = pgEnum('visibilidade', ['PUBLICO', 'SO_MODERACAO']);
export const reacaoEnum = pgEnum('reacao_tipo', ['APOIO', 'ME_IDENTIFICO', 'FORCA']);
export const alvoEnum = pgEnum('alvo_tipo', ['POST', 'COMENTARIO', 'VIDEO']);
export const motivoSinalizacaoEnum = pgEnum('motivo_sinalizacao', [
  'IDENTIFICA_PESSOA',
  'ASSEDIO_OU_ATAQUE',
  'DISCURSO_DE_ODIO',
  'CONTEUDO_FALSO',
  'SPAM',
  'OUTRO',
]);
export const sinalizacaoStatusEnum = pgEnum('sinalizacao_status', ['ABERTA', 'RESOLVIDA', 'DESCARTADA']);
export const casoStatusEnum = pgEnum('caso_status', [
  'REGISTRADO',
  'COMPARTILHADO',
  'EM_ACOMPANHAMENTO',
  'ENCAMINHADO',
  'ENCERRADO',
]);
export const provaTipoEnum = pgEnum('prova_tipo', ['IMAGEM', 'VIDEO', 'AUDIO', 'DOCUMENTO', 'OUTRO']);

// ── Contas ────────────────────────────────────────────────────────
export const usuarias = pgTable('usuarias', {
  id: uuid('id').primaryKey().defaultRandom(),
  apelido: varchar('apelido', { length: 32 }).notNull(),
  senhaHash: text('senha_hash').notNull(),
  papel: papelEnum('papel').notNull().default('USUARIA'),
  vinculoTipo: vinculoEnum('vinculo_tipo').notNull(),
  /** HMAC do identificador institucional (DRE/SIAPE). Nunca guardamos o número em claro. */
  vinculoHash: text('vinculo_hash').notNull(),
  autodeclaracaoEm: timestamp('autodeclaracao_em', { withTimezone: true }).notNull(),
  termosVersao: varchar('termos_versao', { length: 16 }).notNull(),
  status: contaStatusEnum('status').notNull().default('ATIVA'),
  /** Incrementar invalida todas as sessões abertas. */
  versaoToken: integer('versao_token').notNull().default(0),
  criadoEm: criadoEm(),
}, (t) => [
  uniqueIndex('usuarias_apelido_lower_idx').on(sql`lower(${t.apelido})`),
  uniqueIndex('usuarias_vinculo_hash_idx').on(t.vinculoHash),
]);

export const desafiosVerificacao = pgTable('desafios_verificacao', {
  id: uuid('id').primaryKey().defaultRandom(),
  vinculoTipo: vinculoEnum('vinculo_tipo').notNull(),
  vinculoHash: text('vinculo_hash').notNull(),
  codigoHash: text('codigo_hash').notNull(),
  finalidade: desafioFinalidadeEnum('finalidade').notNull(),
  tentativas: integer('tentativas').notNull().default(0),
  expiraEm: timestamp('expira_em', { withTimezone: true }).notNull(),
  usadoEm: timestamp('usado_em', { withTimezone: true }),
  criadoEm: criadoEm(),
});

export const refreshTokens = pgTable('refresh_tokens', {
  id: uuid('id').primaryKey().defaultRandom(),
  usuariaId: uuid('usuaria_id').notNull().references(() => usuarias.id, { onDelete: 'cascade' }),
  tokenHash: text('token_hash').notNull().unique(),
  expiraEm: timestamp('expira_em', { withTimezone: true }).notNull(),
  revogadoEm: timestamp('revogado_em', { withTimezone: true }),
  criadoEm: criadoEm(),
}, (t) => [index('refresh_usuaria_idx').on(t.usuariaId)]);

// ── Subcomunidades ────────────────────────────────────────────────
export const comunidades = pgTable('comunidades', {
  id: uuid('id').primaryKey().defaultRandom(),
  slug: varchar('slug', { length: 48 }).notNull().unique(),
  nome: varchar('nome', { length: 64 }).notNull(),
  descricao: text('descricao').notNull(),
  regras: text('regras'),
  icone: varchar('icone', { length: 32 }).notNull().default('chatbubbles'),
  cor: varchar('cor', { length: 16 }).notNull().default('#7C4DBA'),
  ativa: boolean('ativa').notNull().default(true),
  criadaPorId: uuid('criada_por_id').references(() => usuarias.id, { onDelete: 'set null' }),
  criadoEm: criadoEm(),
});

export const membrosComunidade = pgTable('membros_comunidade', {
  usuariaId: uuid('usuaria_id').notNull().references(() => usuarias.id, { onDelete: 'cascade' }),
  comunidadeId: uuid('comunidade_id').notNull().references(() => comunidades.id, { onDelete: 'cascade' }),
  criadoEm: criadoEm(),
}, (t) => [primaryKey({ columns: [t.usuariaId, t.comunidadeId] })]);

export const posts = pgTable('posts', {
  id: uuid('id').primaryKey().defaultRandom(),
  comunidadeId: uuid('comunidade_id').notNull().references(() => comunidades.id, { onDelete: 'cascade' }),
  autoraId: uuid('autora_id').notNull().references(() => usuarias.id, { onDelete: 'cascade' }),
  titulo: varchar('titulo', { length: 140 }).notNull(),
  corpo: text('corpo').notNull(),
  anonimo: boolean('anonimo').notNull().default(false),
  sensivel: boolean('sensivel').notNull().default(false),
  visibilidade: visibilidadeEnum('visibilidade').notNull().default('PUBLICO'),
  status: conteudoStatusEnum('status').notNull(),
  /** Motivos detectados pelo filtro automático (ex.: "possível nome próprio"). */
  alertas: jsonb('alertas').$type<string[]>().notNull().default([]),
  /** Informações só para a moderação (nomes, cargos…) — criptografadas. */
  detalhesModeracaoEnc: text('detalhes_moderacao_enc'),
  motivoModeracao: text('motivo_moderacao'),
  respostaModeracao: text('resposta_moderacao'),
  respondidoEm: timestamp('respondido_em', { withTimezone: true }),
  revisadoPorId: uuid('revisado_por_id').references(() => usuarias.id, { onDelete: 'set null' }),
  revisadoEm: timestamp('revisado_em', { withTimezone: true }),
  publicadoEm: timestamp('publicado_em', { withTimezone: true }),
  criadoEm: criadoEm(),
}, (t) => [
  index('posts_comunidade_idx').on(t.comunidadeId, t.status, t.publicadoEm),
  index('posts_autora_idx').on(t.autoraId),
]);

export const comentarios = pgTable('comentarios', {
  id: uuid('id').primaryKey().defaultRandom(),
  postId: uuid('post_id').notNull().references(() => posts.id, { onDelete: 'cascade' }),
  autoraId: uuid('autora_id').notNull().references(() => usuarias.id, { onDelete: 'cascade' }),
  corpo: text('corpo').notNull(),
  anonimo: boolean('anonimo').notNull().default(false),
  status: conteudoStatusEnum('status').notNull(),
  alertas: jsonb('alertas').$type<string[]>().notNull().default([]),
  motivoModeracao: text('motivo_moderacao'),
  revisadoPorId: uuid('revisado_por_id').references(() => usuarias.id, { onDelete: 'set null' }),
  revisadoEm: timestamp('revisado_em', { withTimezone: true }),
  criadoEm: criadoEm(),
}, (t) => [index('comentarios_post_idx').on(t.postId, t.criadoEm)]);

export const reacoesPost = pgTable('reacoes_post', {
  postId: uuid('post_id').notNull().references(() => posts.id, { onDelete: 'cascade' }),
  usuariaId: uuid('usuaria_id').notNull().references(() => usuarias.id, { onDelete: 'cascade' }),
  tipo: reacaoEnum('tipo').notNull(),
  criadoEm: criadoEm(),
}, (t) => [primaryKey({ columns: [t.postId, t.usuariaId, t.tipo] })]);

export const sinalizacoes = pgTable('sinalizacoes', {
  id: uuid('id').primaryKey().defaultRandom(),
  alvoTipo: alvoEnum('alvo_tipo').notNull(),
  alvoId: uuid('alvo_id').notNull(),
  autoraId: uuid('autora_id').notNull().references(() => usuarias.id, { onDelete: 'cascade' }),
  motivo: motivoSinalizacaoEnum('motivo').notNull(),
  detalhes: text('detalhes'),
  status: sinalizacaoStatusEnum('status').notNull().default('ABERTA'),
  resolvidaPorId: uuid('resolvida_por_id').references(() => usuarias.id, { onDelete: 'set null' }),
  resolvidaEm: timestamp('resolvida_em', { withTimezone: true }),
  criadoEm: criadoEm(),
}, (t) => [index('sinalizacoes_status_idx').on(t.status, t.criadoEm)]);

// ── Vídeos curtos ─────────────────────────────────────────────────
export const videos = pgTable('videos', {
  id: uuid('id').primaryKey().defaultRandom(),
  autoraId: uuid('autora_id').notNull().references(() => usuarias.id, { onDelete: 'cascade' }),
  titulo: varchar('titulo', { length: 100 }).notNull(),
  descricao: text('descricao'),
  mostrarApelido: boolean('mostrar_apelido').notNull().default(true),
  sensivel: boolean('sensivel').notNull().default(false),
  status: conteudoStatusEnum('status').notNull().default('EM_REVISAO'),
  motivoModeracao: text('motivo_moderacao'),
  arquivoChave: text('arquivo_chave').notNull(),
  capaChave: text('capa_chave'),
  mimeType: varchar('mime_type', { length: 64 }).notNull(),
  tamanhoBytes: integer('tamanho_bytes').notNull(),
  duracaoSeg: integer('duracao_seg'),
  revisadoPorId: uuid('revisado_por_id').references(() => usuarias.id, { onDelete: 'set null' }),
  revisadoEm: timestamp('revisado_em', { withTimezone: true }),
  publicadoEm: timestamp('publicado_em', { withTimezone: true }),
  criadoEm: criadoEm(),
}, (t) => [index('videos_status_idx').on(t.status, t.publicadoEm)]);

export const reacoesVideo = pgTable('reacoes_video', {
  videoId: uuid('video_id').notNull().references(() => videos.id, { onDelete: 'cascade' }),
  usuariaId: uuid('usuaria_id').notNull().references(() => usuarias.id, { onDelete: 'cascade' }),
  tipo: reacaoEnum('tipo').notNull(),
  criadoEm: criadoEm(),
}, (t) => [primaryKey({ columns: [t.videoId, t.usuariaId, t.tipo] })]);

// ── Casos (denúncias) e provas ────────────────────────────────────
export const casos = pgTable('casos', {
  id: uuid('id').primaryKey().defaultRandom(),
  donaId: uuid('dona_id').notNull().references(() => usuarias.id, { onDelete: 'cascade' }),
  status: casoStatusEnum('status').notNull().default('REGISTRADO'),
  /** Chave do caso (DEK), protegida pela chave-mestra. */
  chaveProtegida: text('chave_protegida').notNull(),
  /** Relato, datas, local, pessoas envolvidas… tudo em JSON criptografado. */
  dadosEnc: text('dados_enc').notNull(),
  compartilhadoEm: timestamp('compartilhado_em', { withTimezone: true }),
  responsavelId: uuid('responsavel_id').references(() => usuarias.id, { onDelete: 'set null' }),
  criadoEm: criadoEm(),
  atualizadoEm: timestamp('atualizado_em', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('casos_dona_idx').on(t.donaId), index('casos_compartilhado_idx').on(t.compartilhadoEm)]);

export const provas = pgTable('provas', {
  id: uuid('id').primaryKey().defaultRandom(),
  casoId: uuid('caso_id').notNull().references(() => casos.id, { onDelete: 'cascade' }),
  tipo: provaTipoEnum('tipo').notNull(),
  mimeType: varchar('mime_type', { length: 128 }).notNull(),
  tamanhoBytes: integer('tamanho_bytes').notNull(),
  /** SHA-256 do arquivo ORIGINAL (antes de criptografar). */
  sha256: varchar('sha256', { length: 64 }).notNull(),
  recebidoEm: timestamp('recebido_em', { withTimezone: true }).notNull(),
  /** Recibo de integridade assinado (Ed25519) pelo servidor. */
  assinatura: text('assinatura').notNull(),
  chaveProtegida: text('chave_protegida').notNull(),
  iv: varchar('iv', { length: 32 }).notNull(),
  authTag: varchar('auth_tag', { length: 32 }).notNull(),
  arquivoChave: text('arquivo_chave').notNull(),
  /** Nome original, descrição e data de captura — criptografados com a chave do caso. */
  metaEnc: text('meta_enc').notNull(),
  criadoEm: criadoEm(),
}, (t) => [index('provas_caso_idx').on(t.casoId)]);

export const mensagensCaso = pgTable('mensagens_caso', {
  id: uuid('id').primaryKey().defaultRandom(),
  casoId: uuid('caso_id').notNull().references(() => casos.id, { onDelete: 'cascade' }),
  autoraId: uuid('autora_id').references(() => usuarias.id, { onDelete: 'set null' }),
  daEquipe: boolean('da_equipe').notNull(),
  corpoEnc: text('corpo_enc').notNull(),
  criadoEm: criadoEm(),
}, (t) => [index('mensagens_caso_idx').on(t.casoId, t.criadoEm)]);

/** Linha do tempo do caso — inclui todo acesso da equipe, visível para a dona. */
export const eventosCaso = pgTable('eventos_caso', {
  id: uuid('id').primaryKey().defaultRandom(),
  casoId: uuid('caso_id').notNull().references(() => casos.id, { onDelete: 'cascade' }),
  atorId: uuid('ator_id').references(() => usuarias.id, { onDelete: 'set null' }),
  daEquipe: boolean('da_equipe').notNull().default(false),
  tipo: varchar('tipo', { length: 48 }).notNull(),
  detalhe: jsonb('detalhe').$type<Record<string, unknown>>(),
  criadoEm: criadoEm(),
}, (t) => [index('eventos_caso_idx').on(t.casoId, t.criadoEm)]);

/** Registro das ações da equipe (moderação, banimentos…). */
export const auditoria = pgTable('auditoria', {
  id: uuid('id').primaryKey().defaultRandom(),
  atorId: uuid('ator_id').references(() => usuarias.id, { onDelete: 'set null' }),
  acao: varchar('acao', { length: 64 }).notNull(),
  alvoTipo: varchar('alvo_tipo', { length: 32 }),
  alvoId: uuid('alvo_id'),
  detalhe: jsonb('detalhe').$type<Record<string, unknown>>(),
  criadoEm: criadoEm(),
});

export type Usuaria = typeof usuarias.$inferSelect;
export type Papel = (typeof papelEnum.enumValues)[number];
export type ReacaoTipo = (typeof reacaoEnum.enumValues)[number];
export type CasoStatus = (typeof casoStatusEnum.enumValues)[number];
