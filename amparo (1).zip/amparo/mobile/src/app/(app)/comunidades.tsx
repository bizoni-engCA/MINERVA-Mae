import { FlatList, RefreshControl } from 'react-native';
import { useComunidades } from '@/api/consultas';
import { mensagemDeErro } from '@/api/cliente';
import { LinhaComunidade } from '@/components/LinhaComunidade';
import { Carregando, ErroTela, Texto } from '@/components/ui';
import { cores, espaco } from '@/theme';

export default function TodasComunidades() {
  const q = useComunidades();
  if (q.isLoading) return <Carregando />;
  if (q.isError) return <ErroTela mensagem={mensagemDeErro(q.error)} tentarDeNovo={q.refetch} />;
  return (
    <FlatList
      style={{ backgroundColor: cores.papel }}
      contentContainerStyle={{ paddingHorizontal: espaco.l, paddingBottom: espaco.xxl }}
      data={q.data}
      keyExtractor={(c) => c.id}
      renderItem={({ item }) => <LinhaComunidade c={item} />}
      refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => void q.refetch()} tintColor={cores.lilas} />}
      ListHeaderComponent={
        <Texto fraco style={{ marginVertical: espaco.m }}>
          Participe das subcomunidades que fazem sentido para você. Os relatos delas aparecem no seu feed.
        </Texto>
      }
    />
  );
}
