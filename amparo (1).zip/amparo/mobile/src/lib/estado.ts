import type { Href } from 'expo-router';
import { useSeguranca } from '@/store/seguranca';
import { useSessao } from '@/store/sessao';

export type EstadoApp = 'anonima' | 'configurar' | 'bloqueada' | 'liberada';

/** Em que "porta" do app a pessoa está: sem conta, criando PIN, bloqueada ou dentro. */
export function useEstadoApp(): EstadoApp {
  const logada = useSessao((s) => Boolean(s.usuaria));
  const temPin = useSeguranca((s) => Boolean(s.pinHash));
  const bloqueada = useSeguranca((s) => s.bloqueada);
  return !logada ? 'anonima' : !temPin ? 'configurar' : bloqueada ? 'bloqueada' : 'liberada';
}

export function destinoDoEstado(estado: EstadoApp, telaBloqueio: 'pin' | 'calculadora'): Href {
  switch (estado) {
    case 'anonima':
      return '/boas-vindas';
    case 'configurar':
      return '/configurar-seguranca';
    case 'bloqueada':
      return telaBloqueio === 'calculadora' ? '/calculadora' : '/bloqueio';
    default:
      return '/inicio';
  }
}
