import { useState } from 'react';
import { FlatList, Pressable, RefreshControl, ScrollView, StyleSheet, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useCasosEquipe } from '@/api/consultas';
import { mensagemDeErro } from '@/api/cliente';
import { Carregando, Chip, ErroTela, Etiqueta, Icone, Linha, Texto, Vazio } from '@/components/ui';
import { plural, tempoRelativo } from '@/lib/formatar';
import { STATUS_CASO, TIPOS_VIOLENCIA } from '@/lib/rotulos';
import { cores, espaco } from '@/theme';

const FILTROS = [
  { id: 'aguardando', rotulo: 'Aguardando' },
  { id: 'meus', rotulo: 'Comigo' },
  { id: 'todos', rotulo: 'Em andamento' },
  { id: 'encerrados', rotulo: 'Encerrados' },
];

export default function CasosEquipe() {
  const params = useLocalSearchParams<{ filtro?: string }>();
  const [filtro, setFiltro] = useState(params.filtro ?? 'aguardando');
  const q = useCasosEquipe(filtro);

  return (
    <View style={{ flex: 1, backgroundColor: cores.papel }}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }} contentContainerStyle={{ gap: espaco.s, padding: espaco.l, paddingBottom: espaco.s }}>
        {FILTROS.map((f) => (
          <Chip key={f.id} rotulo={f.rotulo} ativo={filtro === f.id} onPress={() => setFiltro(f.id)} />
        ))}
      </ScrollView>
      {q.isLoading ? (
        <Carregando />
      ) : q.isError ? (
        <ErroTela mensagem={mensagemDeErro(q.error)} tentarDeNovo={q.refetch} />
      ) : (
        <FlatList
          data={q.data}
          keyExtractor={(c) => c.id}
          contentContainerStyle={{ paddingHorizontal: espaco.l, paddingBottom: espaco.xxl }}
          refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => void q.refetch()} tintColor={cores.lilas} />}
          ListEmptyComponent={<Vazio icone="file-tray-outline" titulo="Nenhum caso aqui" />}
          renderItem={({ item: c }) => {
            const s = STATUS_CASO[c.status];
            return (
              <Pressable onPress={() => router.push(`/caso/${c.id}`)} style={({ pressed }) => [estilos.item, pressed && { opacity: 0.7 }]} accessibilityRole="button">
                <View style={{ flex: 1, gap: 4 }}>
                  <Texto negrito numberOfLines={2}>
                    {c.titulo}
                  </Texto>
                  {c.tiposViolencia.length ? (
                    <Texto pequeno fraco numberOfLines={1}>
                      {c.tiposViolencia.map((t) => TIPOS_VIOLENCIA[t]).join(', ')}
                    </Texto>
                  ) : null}
                  <Linha>
                    <Etiqueta texto={s.rotulo} cor={s.cor} fundo={s.fundo} />
                    <Texto pequeno fraco>
                      {plural(c.totalProvas ?? 0, 'prova', 'provas')} · compartilhado {c.compartilhadoEm ? tempoRelativo(c.compartilhadoEm) : ''}
                    </Texto>
                  </Linha>
                  {c.responsavel ? (
                    <Texto pequeno fraco>
                      Com: {c.responsavel}
                    </Texto>
                  ) : null}
                </View>
                <Icone nome="chevron-forward" cor={cores.nevoa} tamanho={18} />
              </Pressable>
            );
          }}
        />
      )}
    </View>
  );
}

const estilos = StyleSheet.create({
  item: { flexDirection: 'row', alignItems: 'center', gap: espaco.m, paddingVertical: espaco.l, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: cores.linha },
});
