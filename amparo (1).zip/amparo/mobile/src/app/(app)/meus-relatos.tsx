import { FlatList, RefreshControl } from 'react-native';
import { router } from 'expo-router';
import { useMeusPosts } from '@/api/consultas';
import { mensagemDeErro } from '@/api/cliente';
import { CartaoRelato } from '@/components/CartaoRelato';
import { Botao, Carregando, ErroTela, Vazio } from '@/components/ui';
import { cores, espaco } from '@/theme';

export default function MeusRelatos() {
  const q = useMeusPosts();
  if (q.isLoading) return <Carregando />;
  if (q.isError) return <ErroTela mensagem={mensagemDeErro(q.error)} tentarDeNovo={q.refetch} />;
  return (
    <FlatList
      style={{ backgroundColor: cores.papel }}
      contentContainerStyle={{ padding: espaco.l }}
      data={q.data}
      keyExtractor={(p) => p.id}
      renderItem={({ item }) => <CartaoRelato post={item} mostrarStatus />}
      refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => void q.refetch()} tintColor={cores.lilas} />}
      ListEmptyComponent={
        <Vazio
          icone="create-outline"
          titulo="Você ainda não escreveu relatos"
          texto="Seus relatos, inclusive os que estão em revisão ou foram só para a moderação, aparecem aqui."
          acao={<Botao titulo="Escrever um relato" compacto onPress={() => router.push('/relato/novo')} />}
        />
      }
    />
  );
}
