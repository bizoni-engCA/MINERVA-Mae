import express, { type NextFunction, type Request, type Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { pinoHttp } from 'pino-http';
import { MulterError } from 'multer';
import { config, isTest } from './config';
import { HttpError } from './lib/errors';
import { logger } from './lib/logger';
import { authRouter } from './modules/auth/routes';
import { casosRouter } from './modules/casos/routes';
import { comunidadesRouter } from './modules/comunidades/routes';
import { equipeRouter } from './modules/equipe/routes';
import { integridadeRouter } from './modules/integridade/routes';
import { meRouter } from './modules/me/routes';
import { midiaRouter } from './modules/videos/midia';
import { postsRouter } from './modules/posts/routes';
import { recursosRouter } from './modules/recursos/routes';
import { sinalizacoesRouter } from './modules/posts/sinalizacoes';
import { videosRouter } from './modules/videos/routes';

export function criarApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 1);

  app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
  app.use(
    cors({
      origin: config.CORS_ORIGINS === '*' ? true : config.CORS_ORIGINS.split(',').map((o) => o.trim()),
    }),
  );
  app.use(express.json({ limit: '200kb' }));

  if (!isTest) {
    // Log mínimo: método, rota (sem query) e status. Nada de IP, corpo ou cabeçalhos.
    app.use(
      pinoHttp({
        logger,
        serializers: {
          req: (req) => ({ method: req.method, url: String(req.url).split('?')[0] }),
          res: (res) => ({ statusCode: res.statusCode }),
        },
        customLogLevel: (_req, res, err) => (err || res.statusCode >= 500 ? 'error' : res.statusCode >= 400 ? 'warn' : 'info'),
        autoLogging: { ignore: (req) => req.url === '/api/saude' },
      }),
    );
  }

  app.get('/api/saude', (_req, res) => {
    res.json({ ok: true, servico: 'amparo-api' });
  });

  app.use('/api/auth', authRouter);
  app.use('/api/eu', meRouter);
  app.use('/api/comunidades', comunidadesRouter);
  app.use('/api/posts', postsRouter);
  app.use('/api/sinalizacoes', sinalizacoesRouter);
  app.use('/api/videos', videosRouter);
  app.use('/api/midia', midiaRouter);
  app.use('/api/casos', casosRouter);
  app.use('/api/recursos', recursosRouter);
  app.use('/api/integridade', integridadeRouter);
  app.use('/api/equipe', equipeRouter);

  app.use((_req, res) => {
    res.status(404).json({ erro: 'Rota não encontrada.', codigo: 'ROTA_NAO_ENCONTRADA' });
  });

  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof HttpError) {
      return void res.status(err.status).json({ erro: err.message, codigo: err.codigo });
    }
    if (err instanceof MulterError) {
      const msg = err.code === 'LIMIT_FILE_SIZE' ? 'Arquivo grande demais.' : 'Não foi possível receber o arquivo.';
      return void res.status(413).json({ erro: msg, codigo: err.code });
    }
    if ((err as { type?: string }).type === 'entity.too.large') {
      return void res.status(413).json({ erro: 'Conteúdo grande demais.', codigo: 'MUITO_GRANDE' });
    }
    logger.error({ err }, 'Erro inesperado');
    res.status(500).json({ erro: 'Algo deu errado do nosso lado. Tente de novo.', codigo: 'ERRO_INTERNO' });
  });

  return app;
}
