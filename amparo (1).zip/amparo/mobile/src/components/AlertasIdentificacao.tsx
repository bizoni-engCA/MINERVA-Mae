import { View } from 'react-native';
import type { AlertaIdentificacao } from '@/api/tipos';
import { espaco } from '@/theme';
import { Aviso, Texto } from './ui';

/** Mostra os trechos que podem identificar alguém, antes de enviar. */
export function AlertasIdentificacao({ alertas }: { alertas: AlertaIdentificacao[] }) {
  if (!alertas.length) return null;
  return (
    <Aviso tom="cuidado" titulo="Seu texto pode identificar alguém">
      <View style={{ gap: 4, marginTop: 2 }}>
        {alertas.slice(0, 6).map((a) => (
          <Texto key={`${a.tipo}-${a.trecho}`} pequeno cor="#5C3B00">
            • {a.mensagem}: “{a.trecho}”
          </Texto>
        ))}
        <Texto pequeno cor="#5C3B00" style={{ marginTop: espaco.xs }}>
          Você pode enviar assim mesmo — o relato só aparece depois que a moderação revisar. Para publicar na hora, tire esses trechos e
          coloque-os no campo “Só para a moderação”.
        </Texto>
      </View>
    </Aviso>
  );
}
