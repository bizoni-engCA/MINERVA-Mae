import { Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useResumoEquipe } from '@/api/consultas';
import { mensagemDeErro } from '@/api/cliente';
import { Carregando, ErroTela, Icone, Texto, Titulo, type NomeIcone } from '@/components/ui';
import { ehEquipe, useSessao } from '@/store/sessao';
import { cores, espaco, fontes } from '@/theme';

export default function Equipe() {
  const usuaria = useSessao((s) => s.usuaria);
  const q = useResumoEquipe(ehEquipe(usuaria));
  if (!ehEquipe(usuaria)) return null;
  if (q.isLoading) return <Carregando />;
  if (q.isError || !q.data) return <ErroTela mensagem={mensagemDeErro(q.error)} tentarDeNovo={q.refetch} />;
  const { moderacao, acolhimento } = q.data;

  return (
    <ScrollView
      style={{ backgroundColor: cores.papel }}
      contentContainerStyle={{ padding: espaco.l, paddingBottom: espaco.xxl }}
      refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => void q.refetch()} tintColor={cores.lilas} />}
    >
      <Texto fraco>Área restrita. Tudo o que você faz aqui fica registrado na auditoria.</Texto>

      {moderacao ? (
        <View style={{ marginTop: espaco.xl }}>
          <Titulo nivel={2}>Moderação</Titulo>
          <ItemFila icone="hourglass-outline" titulo="Relatos em revisão" n={moderacao.relatosEmRevisao} onPress={() => router.push('/equipe/moderacao?aba=revisao')} />
          <ItemFila icone="mail-unread-outline" titulo="Relatos só para a moderação" n={moderacao.relatosSoModeracao} onPress={() => router.push('/equipe/moderacao?aba=so-moderacao')} />
          <ItemFila icone="lock-closed-outline" titulo="Publicados com informações reservadas" onPress={() => router.push('/equipe/moderacao?aba=com-detalhes')} />
          <ItemFila icone="chatbubble-ellipses-outline" titulo="Comentários em revisão" n={moderacao.comentariosEmRevisao} onPress={() => router.push('/equipe/moderacao?aba=comentarios')} />
          <ItemFila icone="videocam-outline" titulo="Vídeos aguardando aprovação" n={moderacao.videosEmRevisao} onPress={() => router.push('/equipe/moderacao?aba=videos')} />
          <ItemFila icone="flag-outline" titulo="Sinalizações abertas" n={moderacao.sinalizacoesAbertas} onPress={() => router.push('/equipe/moderacao?aba=sinalizacoes')} />
        </View>
      ) : null}

      {acolhimento ? (
        <View style={{ marginTop: espaco.xl }}>
          <Titulo nivel={2}>Acolhimento</Titulo>
          <ItemFila icone="time-outline" titulo="Casos aguardando acolhimento" n={acolhimento.casosAguardando} onPress={() => router.push('/equipe/casos?filtro=aguardando')} />
          <ItemFila icone="person-outline" titulo="Casos com você" n={acolhimento.meusCasos} onPress={() => router.push('/equipe/casos?filtro=meus')} />
          <ItemFila icone="albums-outline" titulo="Todos em andamento" n={acolhimento.casosEmAcompanhamento} onPress={() => router.push('/equipe/casos?filtro=todos')} />
          <ItemFila icone="checkmark-done-outline" titulo="Encerrados" onPress={() => router.push('/equipe/casos?filtro=encerrados')} />
        </View>
      ) : null}
    </ScrollView>
  );
}

const ItemFila = ({ icone, titulo, n, onPress }: { icone: NomeIcone; titulo: string; n?: number; onPress: () => void }) => (
  <Pressable onPress={onPress} style={({ pressed }) => [estilos.item, pressed && { opacity: 0.7 }]} accessibilityRole="button">
    <Icone nome={icone} cor={cores.lilas} />
    <Text style={estilos.titulo}>{titulo}</Text>
    {n !== undefined ? (
      <View style={[estilos.contador, n > 0 && { backgroundColor: cores.lilas }]}>
        <Text style={[estilos.numero, n > 0 && { color: '#FFF' }]}>{n}</Text>
      </View>
    ) : null}
    <Icone nome="chevron-forward" cor={cores.nevoa} tamanho={18} />
  </Pressable>
);

const estilos = StyleSheet.create({
  item: { flexDirection: 'row', alignItems: 'center', gap: espaco.m, paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: cores.linha },
  titulo: { flex: 1, fontFamily: fontes.textoMedio, fontSize: 16, color: cores.tinta },
  contador: { minWidth: 28, paddingHorizontal: 8, height: 24, borderRadius: 12, backgroundColor: cores.linha, alignItems: 'center', justifyContent: 'center' },
  numero: { fontFamily: fontes.textoNegrito, fontSize: 13, color: cores.tintaSuave },
});
