import { Pressable, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useParticipar } from '@/api/consultas';
import type { Comunidade } from '@/api/tipos';
import { plural } from '@/lib/formatar';
import { cores, espaco, fontes } from '@/theme';
import { Botao, Icone, type NomeIcone } from './ui';

export function LinhaComunidade({ c }: { c: Comunidade }) {
  const participar = useParticipar();
  return (
    <Pressable onPress={() => router.push(`/comunidade/${c.slug}`)} style={({ pressed }) => [estilos.linha, pressed && { opacity: 0.8 }]} accessibilityRole="button">
      <View style={[estilos.icone, { backgroundColor: `${c.cor}1F` }]}>
        <Icone nome={c.icone as NomeIcone} cor={c.cor} tamanho={22} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={estilos.nome}>{c.nome}</Text>
        <Text style={estilos.descricao} numberOfLines={2}>
          {c.descricao}
        </Text>
        <Text style={estilos.meta}>
          {plural(c.membros, 'participante', 'participantes')} · {plural(c.relatos, 'relato', 'relatos')}
        </Text>
      </View>
      <Botao
        compacto
        titulo={c.souMembro ? 'Participando' : 'Participar'}
        variante={c.souMembro ? 'secundario' : 'primario'}
        carregando={participar.isPending}
        onPress={() => participar.mutate({ id: c.id, participar: !c.souMembro })}
      />
    </Pressable>
  );
}

const estilos = StyleSheet.create({
  linha: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: espaco.m,
    paddingVertical: espaco.m + 2,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: cores.linha,
  },
  icone: { width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center' },
  nome: { fontFamily: fontes.tituloMedio, fontSize: 16.5, color: cores.tinta },
  descricao: { fontFamily: fontes.texto, fontSize: 14, lineHeight: 19, color: cores.tintaSuave, marginTop: 2 },
  meta: { fontFamily: fontes.textoMedio, fontSize: 12.5, color: cores.nevoa, marginTop: 4 },
});
