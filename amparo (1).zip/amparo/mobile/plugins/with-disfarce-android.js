/**
 * Plugin local: dá a cada ícone alternativo do Android o seu próprio NOME na
 * tela inicial (ex.: "Calculadora"), completando o disfarce.
 *
 * O expo-alternate-app-icons cria um <activity-alias> por ícone
 * (".MainActivityCalculadora" etc.). Aqui acrescentamos android:label em cada um.
 * No iOS o nome do app não pode mudar depois de instalado — só o ícone.
 *
 * Uso em app.json: ["./plugins/with-disfarce-android", { "Default": "Amparo", "Calculadora": "Calculadora", ... }]
 */
const { withAndroidManifest, withStringsXml, AndroidConfig } = require('expo/config-plugins');

const recurso = (nome) => `nome_disfarce_${nome.toLowerCase()}`;

function aplicarRotulos(manifest, rotulos) {
  const app = AndroidConfig.Manifest.getMainApplicationOrThrow(manifest);
  for (const alias of app['activity-alias'] ?? []) {
    const nome = String(alias.$['android:name'] ?? '').replace(/^\.?MainActivity/, '');
    if (rotulos[nome]) alias.$['android:label'] = `@string/${recurso(nome)}`;
  }
  return manifest;
}

module.exports = function withDisfarceAndroid(config, rotulos = {}) {
  config = withStringsXml(config, (c) => {
    for (const [nome, texto] of Object.entries(rotulos)) {
      c.modResults = AndroidConfig.Strings.setStringItem(
        [{ $: { name: recurso(nome), translatable: 'false' }, _: texto }],
        c.modResults,
      );
    }
    return c;
  });
  // Os aliases são criados pelo expo-alternate-app-icons; este mod roda depois dele
  // porque o plugin é declarado ANTES em app.json (mods rodam em ordem inversa).
  return withAndroidManifest(config, (c) => {
    c.modResults = aplicarRotulos(c.modResults, rotulos);
    return c;
  });
};
