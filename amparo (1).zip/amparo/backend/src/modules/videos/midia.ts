import { Router, type Response } from 'express';
import { eq } from 'drizzle-orm';
import { db, schema } from '../../db';
import { conferirUrlMidia } from '../../lib/crypto';
import { HttpError, naoEncontrado } from '../../lib/errors';
import { storage } from '../../lib/storage';
import { uuid, validar } from '../../lib/validar';

/**
 * Entrega de mídia por link assinado e temporário (players de vídeo não
 * enviam o token de login). O link expira em 2 horas.
 */
export const midiaRouter = Router();

function conferir(recurso: string, query: Record<string, unknown>) {
  if (!conferirUrlMidia(recurso, Number(query.exp), String(query.sig ?? ''))) {
    throw new HttpError(403, 'Link expirado.', 'LINK_EXPIRADO');
  }
}

async function enviarComIntervalo(res: Response, chave: string, mime: string, rangeHeader?: string) {
  const total = await storage.tamanho(chave);
  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Content-Type', mime);
  res.setHeader('Cache-Control', 'private, max-age=3600');

  const m = rangeHeader?.match(/^bytes=(\d*)-(\d*)$/);
  if (m) {
    let inicio = m[1] ? Number(m[1]) : total - Number(m[2]);
    let fim = m[1] && m[2] ? Number(m[2]) : total - 1;
    if (!m[1] && !m[2]) [inicio, fim] = [0, total - 1];
    fim = Math.min(fim, total - 1);
    if (inicio < 0 || inicio > fim) {
      res.setHeader('Content-Range', `bytes */${total}`);
      return void res.status(416).end();
    }
    res.status(206);
    res.setHeader('Content-Range', `bytes ${inicio}-${fim}/${total}`);
    res.setHeader('Content-Length', String(fim - inicio + 1));
    return void storage.abrirLeitura(chave, { start: inicio, end: fim }).pipe(res);
  }
  res.setHeader('Content-Length', String(total));
  storage.abrirLeitura(chave).pipe(res);
}

midiaRouter.get('/videos/:id', async (req, res) => {
  const id = validar(uuid, req.params.id);
  conferir(`video:${id}`, req.query);
  const [v] = await db
    .select({ chave: schema.videos.arquivoChave, mime: schema.videos.mimeType })
    .from(schema.videos)
    .where(eq(schema.videos.id, id));
  if (!v) throw naoEncontrado('Vídeo');
  await enviarComIntervalo(res, v.chave, v.mime, req.headers.range);
});

midiaRouter.get('/capas/:id', async (req, res) => {
  const id = validar(uuid, req.params.id);
  conferir(`capa:${id}`, req.query);
  const [v] = await db.select({ capa: schema.videos.capaChave }).from(schema.videos).where(eq(schema.videos.id, id));
  if (!v?.capa) throw naoEncontrado('Capa');
  await enviarComIntervalo(res, v.capa, 'image/jpeg');
});
