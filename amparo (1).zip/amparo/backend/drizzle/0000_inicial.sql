CREATE TYPE "public"."alvo_tipo" AS ENUM('POST', 'COMENTARIO', 'VIDEO');--> statement-breakpoint
CREATE TYPE "public"."caso_status" AS ENUM('REGISTRADO', 'COMPARTILHADO', 'EM_ACOMPANHAMENTO', 'ENCAMINHADO', 'ENCERRADO');--> statement-breakpoint
CREATE TYPE "public"."conta_status" AS ENUM('ATIVA', 'SUSPENSA', 'BANIDA');--> statement-breakpoint
CREATE TYPE "public"."conteudo_status" AS ENUM('PUBLICADO', 'EM_REVISAO', 'REJEITADO', 'REMOVIDO');--> statement-breakpoint
CREATE TYPE "public"."desafio_finalidade" AS ENUM('CADASTRO', 'REDEFINIR_SENHA');--> statement-breakpoint
CREATE TYPE "public"."motivo_sinalizacao" AS ENUM('IDENTIFICA_PESSOA', 'ASSEDIO_OU_ATAQUE', 'DISCURSO_DE_ODIO', 'CONTEUDO_FALSO', 'SPAM', 'OUTRO');--> statement-breakpoint
CREATE TYPE "public"."papel" AS ENUM('USUARIA', 'MODERADORA', 'ACOLHIMENTO', 'ADMIN');--> statement-breakpoint
CREATE TYPE "public"."prova_tipo" AS ENUM('IMAGEM', 'VIDEO', 'AUDIO', 'DOCUMENTO', 'OUTRO');--> statement-breakpoint
CREATE TYPE "public"."reacao_tipo" AS ENUM('APOIO', 'ME_IDENTIFICO', 'FORCA');--> statement-breakpoint
CREATE TYPE "public"."sinalizacao_status" AS ENUM('ABERTA', 'RESOLVIDA', 'DESCARTADA');--> statement-breakpoint
CREATE TYPE "public"."vinculo_tipo" AS ENUM('ESTUDANTE', 'DOCENTE', 'TECNICA', 'TERCEIRIZADA');--> statement-breakpoint
CREATE TYPE "public"."visibilidade" AS ENUM('PUBLICO', 'SO_MODERACAO');--> statement-breakpoint
CREATE TABLE "auditoria" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"ator_id" uuid,
	"acao" varchar(64) NOT NULL,
	"alvo_tipo" varchar(32),
	"alvo_id" uuid,
	"detalhe" jsonb,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "casos" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"dona_id" uuid NOT NULL,
	"status" "caso_status" DEFAULT 'REGISTRADO' NOT NULL,
	"chave_protegida" text NOT NULL,
	"dados_enc" text NOT NULL,
	"compartilhado_em" timestamp with time zone,
	"responsavel_id" uuid,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL,
	"atualizado_em" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "comentarios" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"post_id" uuid NOT NULL,
	"autora_id" uuid NOT NULL,
	"corpo" text NOT NULL,
	"anonimo" boolean DEFAULT false NOT NULL,
	"status" "conteudo_status" NOT NULL,
	"alertas" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"motivo_moderacao" text,
	"revisado_por_id" uuid,
	"revisado_em" timestamp with time zone,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "comunidades" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"slug" varchar(48) NOT NULL,
	"nome" varchar(64) NOT NULL,
	"descricao" text NOT NULL,
	"regras" text,
	"icone" varchar(32) DEFAULT 'chatbubbles' NOT NULL,
	"cor" varchar(16) DEFAULT '#7C4DBA' NOT NULL,
	"ativa" boolean DEFAULT true NOT NULL,
	"criada_por_id" uuid,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "comunidades_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
CREATE TABLE "desafios_verificacao" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"vinculo_tipo" "vinculo_tipo" NOT NULL,
	"vinculo_hash" text NOT NULL,
	"codigo_hash" text NOT NULL,
	"finalidade" "desafio_finalidade" NOT NULL,
	"tentativas" integer DEFAULT 0 NOT NULL,
	"expira_em" timestamp with time zone NOT NULL,
	"usado_em" timestamp with time zone,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "eventos_caso" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"caso_id" uuid NOT NULL,
	"ator_id" uuid,
	"da_equipe" boolean DEFAULT false NOT NULL,
	"tipo" varchar(48) NOT NULL,
	"detalhe" jsonb,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "membros_comunidade" (
	"usuaria_id" uuid NOT NULL,
	"comunidade_id" uuid NOT NULL,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "membros_comunidade_usuaria_id_comunidade_id_pk" PRIMARY KEY("usuaria_id","comunidade_id")
);
--> statement-breakpoint
CREATE TABLE "mensagens_caso" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"caso_id" uuid NOT NULL,
	"autora_id" uuid,
	"da_equipe" boolean NOT NULL,
	"corpo_enc" text NOT NULL,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "posts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"comunidade_id" uuid NOT NULL,
	"autora_id" uuid NOT NULL,
	"titulo" varchar(140) NOT NULL,
	"corpo" text NOT NULL,
	"anonimo" boolean DEFAULT false NOT NULL,
	"sensivel" boolean DEFAULT false NOT NULL,
	"visibilidade" "visibilidade" DEFAULT 'PUBLICO' NOT NULL,
	"status" "conteudo_status" NOT NULL,
	"alertas" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"detalhes_moderacao_enc" text,
	"motivo_moderacao" text,
	"resposta_moderacao" text,
	"respondido_em" timestamp with time zone,
	"revisado_por_id" uuid,
	"revisado_em" timestamp with time zone,
	"publicado_em" timestamp with time zone,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "provas" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"caso_id" uuid NOT NULL,
	"tipo" "prova_tipo" NOT NULL,
	"mime_type" varchar(128) NOT NULL,
	"tamanho_bytes" integer NOT NULL,
	"sha256" varchar(64) NOT NULL,
	"recebido_em" timestamp with time zone NOT NULL,
	"assinatura" text NOT NULL,
	"chave_protegida" text NOT NULL,
	"iv" varchar(32) NOT NULL,
	"auth_tag" varchar(32) NOT NULL,
	"arquivo_chave" text NOT NULL,
	"meta_enc" text NOT NULL,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "reacoes_post" (
	"post_id" uuid NOT NULL,
	"usuaria_id" uuid NOT NULL,
	"tipo" "reacao_tipo" NOT NULL,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "reacoes_post_post_id_usuaria_id_tipo_pk" PRIMARY KEY("post_id","usuaria_id","tipo")
);
--> statement-breakpoint
CREATE TABLE "reacoes_video" (
	"video_id" uuid NOT NULL,
	"usuaria_id" uuid NOT NULL,
	"tipo" "reacao_tipo" NOT NULL,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "reacoes_video_video_id_usuaria_id_tipo_pk" PRIMARY KEY("video_id","usuaria_id","tipo")
);
--> statement-breakpoint
CREATE TABLE "refresh_tokens" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"usuaria_id" uuid NOT NULL,
	"token_hash" text NOT NULL,
	"expira_em" timestamp with time zone NOT NULL,
	"revogado_em" timestamp with time zone,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "refresh_tokens_token_hash_unique" UNIQUE("token_hash")
);
--> statement-breakpoint
CREATE TABLE "sinalizacoes" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"alvo_tipo" "alvo_tipo" NOT NULL,
	"alvo_id" uuid NOT NULL,
	"autora_id" uuid NOT NULL,
	"motivo" "motivo_sinalizacao" NOT NULL,
	"detalhes" text,
	"status" "sinalizacao_status" DEFAULT 'ABERTA' NOT NULL,
	"resolvida_por_id" uuid,
	"resolvida_em" timestamp with time zone,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "usuarias" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"apelido" varchar(32) NOT NULL,
	"senha_hash" text NOT NULL,
	"papel" "papel" DEFAULT 'USUARIA' NOT NULL,
	"vinculo_tipo" "vinculo_tipo" NOT NULL,
	"vinculo_hash" text NOT NULL,
	"autodeclaracao_em" timestamp with time zone NOT NULL,
	"termos_versao" varchar(16) NOT NULL,
	"status" "conta_status" DEFAULT 'ATIVA' NOT NULL,
	"versao_token" integer DEFAULT 0 NOT NULL,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "videos" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"autora_id" uuid NOT NULL,
	"titulo" varchar(100) NOT NULL,
	"descricao" text,
	"mostrar_apelido" boolean DEFAULT true NOT NULL,
	"sensivel" boolean DEFAULT false NOT NULL,
	"status" "conteudo_status" DEFAULT 'EM_REVISAO' NOT NULL,
	"motivo_moderacao" text,
	"arquivo_chave" text NOT NULL,
	"capa_chave" text,
	"mime_type" varchar(64) NOT NULL,
	"tamanho_bytes" integer NOT NULL,
	"duracao_seg" integer,
	"revisado_por_id" uuid,
	"revisado_em" timestamp with time zone,
	"publicado_em" timestamp with time zone,
	"criado_em" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "auditoria" ADD CONSTRAINT "auditoria_ator_id_usuarias_id_fk" FOREIGN KEY ("ator_id") REFERENCES "public"."usuarias"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "casos" ADD CONSTRAINT "casos_dona_id_usuarias_id_fk" FOREIGN KEY ("dona_id") REFERENCES "public"."usuarias"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "casos" ADD CONSTRAINT "casos_responsavel_id_usuarias_id_fk" FOREIGN KEY ("responsavel_id") REFERENCES "public"."usuarias"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "comentarios" ADD CONSTRAINT "comentarios_post_id_posts_id_fk" FOREIGN KEY ("post_id") REFERENCES "public"."posts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "comentarios" ADD CONSTRAINT "comentarios_autora_id_usuarias_id_fk" FOREIGN KEY ("autora_id") REFERENCES "public"."usuarias"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "comentarios" ADD CONSTRAINT "comentarios_revisado_por_id_usuarias_id_fk" FOREIGN KEY ("revisado_por_id") REFERENCES "public"."usuarias"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "comunidades" ADD CONSTRAINT "comunidades_criada_por_id_usuarias_id_fk" FOREIGN KEY ("criada_por_id") REFERENCES "public"."usuarias"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "eventos_caso" ADD CONSTRAINT "eventos_caso_caso_id_casos_id_fk" FOREIGN KEY ("caso_id") REFERENCES "public"."casos"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "eventos_caso" ADD CONSTRAINT "eventos_caso_ator_id_usuarias_id_fk" FOREIGN KEY ("ator_id") REFERENCES "public"."usuarias"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "membros_comunidade" ADD CONSTRAINT "membros_comunidade_usuaria_id_usuarias_id_fk" FOREIGN KEY ("usuaria_id") REFERENCES "public"."usuarias"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "membros_comunidade" ADD CONSTRAINT "membros_comunidade_comunidade_id_comunidades_id_fk" FOREIGN KEY ("comunidade_id") REFERENCES "public"."comunidades"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "mensagens_caso" ADD CONSTRAINT "mensagens_caso_caso_id_casos_id_fk" FOREIGN KEY ("caso_id") REFERENCES "public"."casos"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "mensagens_caso" ADD CONSTRAINT "mensagens_caso_autora_id_usuarias_id_fk" FOREIGN KEY ("autora_id") REFERENCES "public"."usuarias"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "posts" ADD CONSTRAINT "posts_comunidade_id_comunidades_id_fk" FOREIGN KEY ("comunidade_id") REFERENCES "public"."comunidades"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "posts" ADD CONSTRAINT "posts_autora_id_usuarias_id_fk" FOREIGN KEY ("autora_id") REFERENCES "public"."usuarias"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "posts" ADD CONSTRAINT "posts_revisado_por_id_usuarias_id_fk" FOREIGN KEY ("revisado_por_id") REFERENCES "public"."usuarias"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "provas" ADD CONSTRAINT "provas_caso_id_casos_id_fk" FOREIGN KEY ("caso_id") REFERENCES "public"."casos"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reacoes_post" ADD CONSTRAINT "reacoes_post_post_id_posts_id_fk" FOREIGN KEY ("post_id") REFERENCES "public"."posts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reacoes_post" ADD CONSTRAINT "reacoes_post_usuaria_id_usuarias_id_fk" FOREIGN KEY ("usuaria_id") REFERENCES "public"."usuarias"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reacoes_video" ADD CONSTRAINT "reacoes_video_video_id_videos_id_fk" FOREIGN KEY ("video_id") REFERENCES "public"."videos"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reacoes_video" ADD CONSTRAINT "reacoes_video_usuaria_id_usuarias_id_fk" FOREIGN KEY ("usuaria_id") REFERENCES "public"."usuarias"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "refresh_tokens" ADD CONSTRAINT "refresh_tokens_usuaria_id_usuarias_id_fk" FOREIGN KEY ("usuaria_id") REFERENCES "public"."usuarias"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sinalizacoes" ADD CONSTRAINT "sinalizacoes_autora_id_usuarias_id_fk" FOREIGN KEY ("autora_id") REFERENCES "public"."usuarias"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sinalizacoes" ADD CONSTRAINT "sinalizacoes_resolvida_por_id_usuarias_id_fk" FOREIGN KEY ("resolvida_por_id") REFERENCES "public"."usuarias"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "videos" ADD CONSTRAINT "videos_autora_id_usuarias_id_fk" FOREIGN KEY ("autora_id") REFERENCES "public"."usuarias"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "videos" ADD CONSTRAINT "videos_revisado_por_id_usuarias_id_fk" FOREIGN KEY ("revisado_por_id") REFERENCES "public"."usuarias"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "casos_dona_idx" ON "casos" USING btree ("dona_id");--> statement-breakpoint
CREATE INDEX "casos_compartilhado_idx" ON "casos" USING btree ("compartilhado_em");--> statement-breakpoint
CREATE INDEX "comentarios_post_idx" ON "comentarios" USING btree ("post_id","criado_em");--> statement-breakpoint
CREATE INDEX "eventos_caso_idx" ON "eventos_caso" USING btree ("caso_id","criado_em");--> statement-breakpoint
CREATE INDEX "mensagens_caso_idx" ON "mensagens_caso" USING btree ("caso_id","criado_em");--> statement-breakpoint
CREATE INDEX "posts_comunidade_idx" ON "posts" USING btree ("comunidade_id","status","publicado_em");--> statement-breakpoint
CREATE INDEX "posts_autora_idx" ON "posts" USING btree ("autora_id");--> statement-breakpoint
CREATE INDEX "provas_caso_idx" ON "provas" USING btree ("caso_id");--> statement-breakpoint
CREATE INDEX "refresh_usuaria_idx" ON "refresh_tokens" USING btree ("usuaria_id");--> statement-breakpoint
CREATE INDEX "sinalizacoes_status_idx" ON "sinalizacoes" USING btree ("status","criado_em");--> statement-breakpoint
CREATE UNIQUE INDEX "usuarias_apelido_lower_idx" ON "usuarias" USING btree (lower("apelido"));--> statement-breakpoint
CREATE UNIQUE INDEX "usuarias_vinculo_hash_idx" ON "usuarias" USING btree ("vinculo_hash");--> statement-breakpoint
CREATE INDEX "videos_status_idx" ON "videos" USING btree ("status","publicado_em");