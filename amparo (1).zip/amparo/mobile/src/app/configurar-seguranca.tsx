import { useEffect, useState } from 'react';
import { View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { PinPad } from '@/components/PinPad';
import { Aviso, Botao, Bloco, Espaco, Icone, Interruptor, Linha, Texto, Titulo, Tela } from '@/components/ui';
import { autenticarComBiometria, biometriaDisponivel } from '@/lib/biometria';
import { useSeguranca } from '@/store/seguranca';
import { cores, espaco } from '@/theme';

/** Primeiro acesso no aparelho: cria o PIN e explica os recursos de segurança. */
export default function ConfigurarSeguranca() {
  const insets = useSafeAreaInsets();
  const [etapa, setEtapa] = useState<'pin' | 'confirmar' | 'opcoes'>('pin');
  const [pin, setPin] = useState('');
  const [confirmacao, setConfirmacao] = useState('');
  const [erro, setErro] = useState(false);
  const [temBiometria, setTemBiometria] = useState(false);
  const [usarBiometria, setUsarBiometria] = useState(false);
  const [calculadora, setCalculadora] = useState(false);
  const { definirPin, atualizar } = useSeguranca();

  useEffect(() => {
    biometriaDisponivel().then(setTemBiometria);
  }, []);

  useEffect(() => {
    if (etapa === 'pin' && pin.length === 6) setEtapa('confirmar');
  }, [pin, etapa]);

  useEffect(() => {
    if (etapa !== 'confirmar' || confirmacao.length !== 6) return;
    if (confirmacao === pin) setEtapa('opcoes');
    else {
      setErro(true);
      setTimeout(() => {
        setConfirmacao('');
        setErro(false);
      }, 700);
    }
  }, [confirmacao, pin, etapa]);

  if (etapa !== 'opcoes') {
    return (
      <View style={{ flex: 1, backgroundColor: cores.papel, paddingTop: insets.top + espaco.xxl, alignItems: 'center', paddingHorizontal: espaco.xl }}>
        <Titulo centro>{etapa === 'pin' ? 'Crie um PIN de 6 dígitos' : 'Repita o PIN'}</Titulo>
        <Texto fraco centro style={{ marginTop: espaco.s, marginBottom: espaco.xxl, maxWidth: 320 }}>
          {etapa === 'pin'
            ? 'Ele protege o app neste celular, mesmo que alguém pegue seu aparelho desbloqueado. Não use sua data de nascimento.'
            : erro
              ? 'Os PINs não são iguais. Tente de novo.'
              : 'Só para garantir que você digitou certo.'}
        </Texto>
        <PinPad valor={etapa === 'pin' ? pin : confirmacao} aoMudar={etapa === 'pin' ? setPin : setConfirmacao} erro={erro} />
        {etapa === 'confirmar' ? (
          <Botao
            titulo="Escolher outro PIN"
            variante="fantasma"
            estilo={{ marginTop: espaco.l }}
            onPress={() => {
              setPin('');
              setConfirmacao('');
              setEtapa('pin');
            }}
          />
        ) : null}
      </View>
    );
  }

  return (
    <Tela
      rodape={
        <Botao
          titulo="Começar a usar"
          onPress={async () => {
            await atualizar({ biometria: usarBiometria, abrirComoCalculadora: calculadora });
            await definirPin(pin);
          }}
        />
      }
      estilo={{ paddingTop: insets.top + espaco.l }}
    >
      <Titulo>Sua segurança no app</Titulo>
      <Texto fraco style={{ marginTop: espaco.s, marginBottom: espaco.xl }}>
        Você pode mudar tudo isso depois em Ajustes.
      </Texto>

      <Bloco>
        <Linha espacamento={espaco.m} estilo={{ alignItems: 'flex-start' }}>
          <View style={{ backgroundColor: cores.sinal, borderRadius: 99, padding: 8 }}>
            <Icone nome="eye-off" cor="#FFF" tamanho={18} />
          </View>
          <View style={{ flex: 1 }}>
            <Texto negrito>Saída rápida</Texto>
            <Texto pequeno fraco>
              O botão vermelho “Sair”, no topo de todas as telas, esconde o app na hora atrás de uma calculadora. Para voltar, digite seu PIN na
              calculadora e toque em “=”.
            </Texto>
          </View>
        </Linha>
      </Bloco>
      <Espaco altura={espaco.m} />
      <Bloco>
        {temBiometria ? (
          <Interruptor
            titulo="Desbloquear com biometria"
            descricao="Digital ou rosto, além do PIN."
            valor={usarBiometria}
            aoMudar={async (v) => setUsarBiometria(v ? await autenticarComBiometria('Confirme para ativar') : false)}
          />
        ) : null}
        <Interruptor
          titulo="Abrir sempre como calculadora"
          descricao="Quem abrir o app verá só uma calculadora funcionando. Você entra digitando o PIN e “=”."
          valor={calculadora}
          aoMudar={setCalculadora}
        />
      </Bloco>
      <Espaco altura={espaco.m} />
      <Aviso tom="info" titulo="Disfarce do ícone">
        Em Ajustes → Disfarce, você pode trocar o ícone (e, no Android, o nome) do app por Calculadora, Notas, Clima ou Agenda.
      </Aviso>
    </Tela>
  );
}
