import { Router } from 'express';
import { and, asc, eq, inArray, ne, or, sql } from 'drizzle-orm';
import { db, schema } from '../../db';
import { cifrarCampo } from '../../lib/crypto';
import { HttpError, naoEncontrado, proibido } from '../../lib/errors';
import { detectarIdentificacao, resumoAlertas } from '../../lib/identificacao';
import { lerCursor, paginacao, uuid, validar, z } from '../../lib/validar';
import { ehEquipe, eu, exigirLogin } from '../../middleware/auth';
import { autoriaVisivel } from '../me/perfil';
import { buscarPosts, postPublicado } from './consultas';

export const postsRouter = Router();
postsRouter.use(exigirLogin);

const { posts, comentarios, reacoesPost, membrosComunidade, comunidades, usuarias } = schema;

const MENSAGENS = {
  publicado: 'Seu relato foi publicado. Obrigada por compartilhar. 💜',
  revisao:
    'Seu relato foi enviado para revisão porque parece conter informações que podem identificar alguém. ' +
    'A moderação vai analisar em breve. Se quiser, edite e remova esses trechos — ou use o campo "só para a moderação".',
  soModeracao: 'Seu relato foi enviado só para a moderação. Ninguém mais vai vê-lo.',
};

// Feed: relatos das comunidades que a usuária participa (ou de todas, se ainda não entrou em nenhuma).
postsRouter.get('/feed', async (req, res) => {
  const { cursor, limite } = validar(paginacao, req.query);
  const usuariaId = eu(req).id;
  const minhas = await db
    .select({ id: membrosComunidade.comunidadeId })
    .from(membrosComunidade)
    .where(eq(membrosComunidade.usuariaId, usuariaId));
  const itens = await buscarPosts({
    onde: and(
      postPublicado,
      eq(comunidades.ativa, true),
      minhas.length ? inArray(posts.comunidadeId, minhas.map((m) => m.id)) : undefined,
    ),
    usuariaId,
    limite,
    cursor: lerCursor(cursor),
  });
  res.json({ itens, proximoCursor: itens.length === limite ? itens.at(-1)?.publicadoEm : null });
});

postsRouter.get('/meus', async (req, res) => {
  const itens = await buscarPosts({ onde: eq(posts.autoraId, eu(req).id), usuariaId: eu(req).id, limite: 50 });
  res.json(itens);
});

const novoPostSchema = z.object({
  comunidadeId: uuid,
  titulo: z.string().trim().min(5, 'O título precisa ter pelo menos 5 caracteres').max(140),
  corpo: z.string().trim().min(20, 'Conte um pouco mais (mínimo de 20 caracteres)').max(10000),
  anonimo: z.boolean().default(false),
  sensivel: z.boolean().default(false),
  visibilidade: z.enum(['PUBLICO', 'SO_MODERACAO']).default('PUBLICO'),
  detalhesModeracao: z.string().trim().max(5000).optional(),
});

postsRouter.post('/', async (req, res) => {
  const dados = validar(novoPostSchema, req.body);
  const [comunidade] = await db
    .select({ id: comunidades.id })
    .from(comunidades)
    .where(and(eq(comunidades.id, dados.comunidadeId), eq(comunidades.ativa, true)));
  if (!comunidade) throw naoEncontrado('Comunidade');

  const alertas = detectarIdentificacao(`${dados.titulo}\n${dados.corpo}`);
  const publico = dados.visibilidade === 'PUBLICO';
  const status = !publico || alertas.length ? 'EM_REVISAO' : 'PUBLICADO';

  const [post] = await db
    .insert(posts)
    .values({
      comunidadeId: dados.comunidadeId,
      autoraId: eu(req).id,
      titulo: dados.titulo,
      corpo: dados.corpo,
      anonimo: dados.anonimo,
      sensivel: dados.sensivel,
      visibilidade: dados.visibilidade,
      status,
      alertas: resumoAlertas(alertas),
      detalhesModeracaoEnc: dados.detalhesModeracao ? cifrarCampo(dados.detalhesModeracao) : null,
      publicadoEm: status === 'PUBLICADO' ? new Date() : null,
    })
    .returning({ id: posts.id, status: posts.status });

  // Quem publica passa a participar da comunidade.
  await db.insert(membrosComunidade).values({ usuariaId: eu(req).id, comunidadeId: dados.comunidadeId }).onConflictDoNothing();

  res.status(201).json({
    id: post.id,
    status: post.status,
    alertas,
    mensagem: !publico ? MENSAGENS.soModeracao : status === 'PUBLICADO' ? MENSAGENS.publicado : MENSAGENS.revisao,
  });
});

/** Prévia do filtro — o app usa para avisar antes de enviar. */
postsRouter.post('/verificar-texto', (req, res) => {
  const { texto } = validar(z.object({ texto: z.string().max(12000) }), req.body);
  res.json({ alertas: detectarIdentificacao(texto) });
});

async function carregarPostVisivel(id: string, usuariaId: string, equipe: boolean) {
  const [p] = await buscarPosts({ onde: eq(posts.id, id), usuariaId, limite: 1 });
  if (!p) throw naoEncontrado('Relato');
  const [cru] = await db.select({ status: posts.status, visibilidade: posts.visibilidade }).from(posts).where(eq(posts.id, id));
  const publicado = cru.status === 'PUBLICADO' && cru.visibilidade === 'PUBLICO';
  if (!publicado && !p.souAutora && !equipe) throw naoEncontrado('Relato');
  return { post: p, publicado };
}

postsRouter.get('/:id', async (req, res) => {
  const id = validar(uuid, req.params.id);
  const { post } = await carregarPostVisivel(id, eu(req).id, ehEquipe(eu(req)));
  res.json(post);
});

postsRouter.delete('/:id', async (req, res) => {
  const id = validar(uuid, req.params.id);
  const [p] = await db.select({ autoraId: posts.autoraId }).from(posts).where(eq(posts.id, id));
  if (!p) throw naoEncontrado('Relato');
  if (p.autoraId !== eu(req).id) throw proibido();
  await db.delete(posts).where(eq(posts.id, id));
  res.status(204).end();
});

// ── Reações ───────────────────────────────────────────────────────
postsRouter.post('/:id/reacoes', async (req, res) => {
  const id = validar(uuid, req.params.id);
  const { tipo } = validar(z.object({ tipo: z.enum(['APOIO', 'ME_IDENTIFICO', 'FORCA']) }), req.body);
  const [p] = await db.select({ id: posts.id }).from(posts).where(and(eq(posts.id, id), postPublicado));
  if (!p) throw naoEncontrado('Relato');

  const usuariaId = eu(req).id;
  const removidas = await db
    .delete(reacoesPost)
    .where(and(eq(reacoesPost.postId, id), eq(reacoesPost.usuariaId, usuariaId), eq(reacoesPost.tipo, tipo)))
    .returning();
  if (!removidas.length) await db.insert(reacoesPost).values({ postId: id, usuariaId, tipo }).onConflictDoNothing();

  const [post] = await buscarPosts({ onde: eq(posts.id, id), usuariaId, limite: 1 });
  res.json({ reacoes: post.reacoes, minhasReacoes: post.minhasReacoes });
});

// ── Comentários ───────────────────────────────────────────────────
postsRouter.get('/:id/comentarios', async (req, res) => {
  const id = validar(uuid, req.params.id);
  const usuariaId = eu(req).id;
  await carregarPostVisivel(id, usuariaId, ehEquipe(eu(req)));

  const lista = await db
    .select({
      id: comentarios.id,
      corpo: comentarios.corpo,
      anonimo: comentarios.anonimo,
      status: comentarios.status,
      motivoModeracao: comentarios.motivoModeracao,
      criadoEm: comentarios.criadoEm,
      autoraId: comentarios.autoraId,
      apelido: usuarias.apelido,
      autoraDoPost: sql<boolean>`${comentarios.autoraId} = ${posts.autoraId}`,
    })
    .from(comentarios)
    .innerJoin(posts, eq(posts.id, comentarios.postId))
    .leftJoin(usuarias, eq(usuarias.id, comentarios.autoraId))
    .where(
      and(
        eq(comentarios.postId, id),
        or(eq(comentarios.status, 'PUBLICADO'), and(eq(comentarios.autoraId, usuariaId), ne(comentarios.status, 'REMOVIDO'))),
      ),
    )
    .orderBy(asc(comentarios.criadoEm));

  res.json(
    lista.map((c) => {
      const souAutora = c.autoraId === usuariaId;
      return {
        id: c.id,
        corpo: c.corpo,
        criadoEm: c.criadoEm,
        autoria: autoriaVisivel(c.anonimo, c.apelido),
        // Selo "autora do relato" só aparece se ela não comentou como anônima.
        autoraDoRelato: c.autoraDoPost && !c.anonimo,
        souAutora,
        ...(souAutora ? { status: c.status, motivoModeracao: c.motivoModeracao } : {}),
      };
    }),
  );
});

postsRouter.post('/:id/comentarios', async (req, res) => {
  const id = validar(uuid, req.params.id);
  const dados = validar(
    z.object({ corpo: z.string().trim().min(1).max(3000), anonimo: z.boolean().default(false) }),
    req.body,
  );
  const [p] = await db.select({ id: posts.id }).from(posts).where(and(eq(posts.id, id), postPublicado));
  if (!p) throw naoEncontrado('Relato');

  const alertas = detectarIdentificacao(dados.corpo);
  const [c] = await db
    .insert(comentarios)
    .values({
      postId: id,
      autoraId: eu(req).id,
      corpo: dados.corpo,
      anonimo: dados.anonimo,
      status: alertas.length ? 'EM_REVISAO' : 'PUBLICADO',
      alertas: resumoAlertas(alertas),
    })
    .returning({ id: comentarios.id, status: comentarios.status });

  res.status(201).json({
    ...c,
    alertas,
    mensagem:
      c.status === 'PUBLICADO'
        ? 'Comentário publicado.'
        : 'Seu comentário foi para revisão porque parece identificar alguém.',
  });
});

postsRouter.delete('/comentarios/:id', async (req, res) => {
  const id = validar(uuid, req.params.id);
  const [c] = await db.select({ autoraId: comentarios.autoraId }).from(comentarios).where(eq(comentarios.id, id));
  if (!c) throw naoEncontrado('Comentário');
  if (c.autoraId !== eu(req).id) throw new HttpError(403, 'Você só pode apagar seus próprios comentários.');
  await db.delete(comentarios).where(eq(comentarios.id, id));
  res.status(204).end();
});
