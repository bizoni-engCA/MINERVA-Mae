import { Pressable, StyleSheet, Text, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import { cores, fontes } from '@/theme';
import { Icone, type NomeIcone } from './ui';

/** Teclado numérico com indicador de dígitos. */
export function PinPad({
  valor,
  aoMudar,
  tamanho = 6,
  acaoExtra,
  erro,
}: {
  valor: string;
  aoMudar: (v: string) => void;
  tamanho?: number;
  acaoExtra?: { icone: NomeIcone; rotulo: string; onPress: () => void };
  erro?: boolean;
}) {
  const tocar = (d: string) => {
    Haptics.selectionAsync().catch(() => {});
    if (valor.length < tamanho) aoMudar(valor + d);
  };
  const teclas = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];
  return (
    <View style={{ alignItems: 'center' }}>
      <View style={estilos.pontos} accessibilityLabel={`${valor.length} de ${tamanho} dígitos`}>
        {Array.from({ length: tamanho }).map((_, i) => (
          <View
            key={i}
            style={[estilos.ponto, i < valor.length && estilos.pontoCheio, erro && { borderColor: cores.sinal, backgroundColor: i < valor.length ? cores.sinal : 'transparent' }]}
          />
        ))}
      </View>
      <View style={estilos.grade}>
        {teclas.map((t) => (
          <Tecla key={t} rotulo={t} onPress={() => tocar(t)} />
        ))}
        {acaoExtra ? (
          <Pressable onPress={acaoExtra.onPress} style={estilos.tecla} accessibilityRole="button" accessibilityLabel={acaoExtra.rotulo}>
            <Icone nome={acaoExtra.icone} tamanho={28} cor={cores.lilas} />
          </Pressable>
        ) : (
          <View style={estilos.tecla} />
        )}
        <Tecla rotulo="0" onPress={() => tocar('0')} />
        <Pressable
          onPress={() => aoMudar(valor.slice(0, -1))}
          style={estilos.tecla}
          accessibilityRole="button"
          accessibilityLabel="Apagar"
        >
          <Icone nome="backspace-outline" tamanho={26} cor={cores.tintaSuave} />
        </Pressable>
      </View>
    </View>
  );
}

const Tecla = ({ rotulo, onPress }: { rotulo: string; onPress: () => void }) => (
  <Pressable
    onPress={onPress}
    accessibilityRole="button"
    accessibilityLabel={rotulo}
    style={({ pressed }) => [estilos.tecla, estilos.teclaNumero, pressed && { backgroundColor: cores.lilasClaro }]}
  >
    <Text style={estilos.numero}>{rotulo}</Text>
  </Pressable>
);

const estilos = StyleSheet.create({
  pontos: { flexDirection: 'row', gap: 14, marginBottom: 36 },
  ponto: { width: 15, height: 15, borderRadius: 8, borderWidth: 2, borderColor: cores.lilas },
  pontoCheio: { backgroundColor: cores.lilas },
  grade: { flexDirection: 'row', flexWrap: 'wrap', width: 288, justifyContent: 'space-between', rowGap: 14 },
  tecla: { width: 84, height: 72, alignItems: 'center', justifyContent: 'center', borderRadius: 36 },
  teclaNumero: { backgroundColor: cores.superficie, borderWidth: StyleSheet.hairlineWidth, borderColor: cores.linha },
  numero: { fontFamily: fontes.tituloMedio, fontSize: 28, color: cores.tinta },
});
