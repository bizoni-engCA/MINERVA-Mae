import { useState } from 'react';
import { Pressable, View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { router, useLocalSearchParams } from 'expo-router';
import { useInvalidarCaso } from '@/api/consultas';
import { api, mensagemDeErro } from '@/api/cliente';
import { Bloco, Botao, Campo, Espaco, Icone, Linha, Texto, Titulo, Tela } from '@/components/ui';
import { cores, espaco } from '@/theme';

const ITENS = [
  { icone: 'eye-outline' as const, texto: 'A equipe de acolhimento passa a ver o relato, as provas e o dossiê deste caso — só deste.' },
  { icone: 'person-outline' as const, texto: 'Ela não vê seu DRE, seu nome, seu apelido nem seus outros casos. Nas mensagens, você aparece como “Estudante”.' },
  { icone: 'time-outline' as const, texto: 'Cada vez que alguém da equipe abrir o caso ou uma prova, isso aparece na linha do tempo para você.' },
  { icone: 'close-circle-outline' as const, texto: 'Você pode parar de compartilhar a qualquer momento.' },
  { icone: 'information-circle-outline' as const, texto: 'A equipe orienta e acompanha, mas não faz a denúncia por você: quem decide é você.' },
];

export default function Compartilhar() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const invalidar = useInvalidarCaso(id);
  const [consentimento, setConsentimento] = useState(false);
  const [mensagem, setMensagem] = useState('');
  const [enviando, setEnviando] = useState(false);

  async function compartilhar() {
    setEnviando(true);
    try {
      const r = await api<{ mensagem: string }>(`/api/casos/${id}/compartilhar`, { corpo: { consentimento: true, mensagem: mensagem.trim() || undefined } });
      invalidar();
      Alert.alert('Pronto', r.mensagem, [{ text: 'Ok', onPress: () => router.back() }]);
    } catch (e) {
      Alert.alert('Não foi possível compartilhar', mensagemDeErro(e));
    } finally {
      setEnviando(false);
    }
  }

  return (
    <Tela rodape={<Botao titulo="Compartilhar com o acolhimento" variante="apoio" onPress={compartilhar} carregando={enviando} desativado={!consentimento} />}>
      <Titulo nivel={2}>Antes de compartilhar</Titulo>
      <Espaco altura={espaco.m} />
      <View style={{ gap: espaco.m }}>
        {ITENS.map((i) => (
          <Linha key={i.texto} espacamento={espaco.m} estilo={{ alignItems: 'flex-start' }}>
            <Icone nome={i.icone} cor={cores.mata} />
            <Texto style={{ flex: 1 }}>{i.texto}</Texto>
          </Linha>
        ))}
      </View>
      <Espaco />
      <Campo
        rotulo="Mensagem para a equipe (opcional)"
        value={mensagem}
        onChangeText={setMensagem}
        multiline
        contador={3000}
        placeholder="ex.: Gostaria de entender se devo levar isso à Ouvidoria."
        style={{ minHeight: 100 }}
      />
      <Bloco>
        <Pressable onPress={() => setConsentimento(!consentimento)} accessibilityRole="checkbox" accessibilityState={{ checked: consentimento }}>
          <Linha espacamento={espaco.m} estilo={{ alignItems: 'flex-start' }}>
            <Icone nome={consentimento ? 'checkbox' : 'square-outline'} cor={consentimento ? cores.mata : cores.nevoa} tamanho={24} />
            <Texto style={{ flex: 1 }}>Entendi e autorizo a equipe de acolhimento a acessar este caso.</Texto>
          </Linha>
        </Pressable>
      </Bloco>
    </Tela>
  );
}
