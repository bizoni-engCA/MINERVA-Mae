import { Router } from 'express';
import { createReadStream } from 'node:fs';
import { rm } from 'node:fs/promises';
import { pipeline } from 'node:stream/promises';
import { createHash } from 'node:crypto';
import { ZipArchive } from 'archiver';
import { and, desc, eq } from 'drizzle-orm';
import { db, schema } from '../../db';
import { abrirDek, cifrarJson, cifrarTexto, criarDecifradorArquivo, decifrarJson } from '../../lib/crypto';
import { HttpError, invalido, naoEncontrado } from '../../lib/errors';
import { storage } from '../../lib/storage';
import { uuid, validar, z } from '../../lib/validar';
import { eu, exigirLogin } from '../../middleware/auth';
import { uploadProva } from '../../middleware/upload';
import { registrarEventoCaso } from '../equipe/auditoria';
import { gerarDossiePdf } from './dossie';
import {
  armazenarProva,
  carregarCaso,
  contarProvas,
  criarCaso,
  dadosCasoSchema,
  listarEventos,
  listarMensagens,
  listarProvas,
  registrarVisualizacaoEquipe,
  resumoCaso,
  type DadosCaso,
  type MetaProva,
} from './servico';

export const casosRouter = Router();
casosRouter.use(exigirLogin);

const { casos, provas, mensagensCaso } = schema;

casosRouter.get('/', async (req, res) => {
  const lista = await db.select().from(casos).where(eq(casos.donaId, eu(req).id)).orderBy(desc(casos.atualizadoEm));
  const itens = await Promise.all(
    lista.map(async (c) => ({
      ...resumoCaso(c, decifrarJson<DadosCaso>(c.dadosEnc, abrirDek(c.chaveProtegida))),
      totalProvas: await contarProvas(c.id),
    })),
  );
  res.json(itens);
});

casosRouter.post('/', async (req, res) => {
  const dados = validar(dadosCasoSchema, req.body);
  const caso = await criarCaso(eu(req).id, dados);
  res.status(201).json(resumoCaso(caso, dados));
});

casosRouter.get('/:id', async (req, res) => {
  const { caso, dek, dados, acessoEquipe, souDona } = await carregarCaso(req.params.id, eu(req));
  if (acessoEquipe) await registrarVisualizacaoEquipe(caso.id, eu(req).id);
  res.json({
    ...resumoCaso(caso, dados),
    souDona,
    acessoEquipe,
    dados,
    provas: await listarProvas(caso.id, dek),
    mensagens: await listarMensagens(caso.id, dek, eu(req).id),
    eventos: await listarEventos(caso.id),
  });
});

casosRouter.patch('/:id', async (req, res) => {
  const { caso, dek, dados } = await carregarCaso(req.params.id, eu(req), { soDona: true });
  const novos = { ...dados, ...validar(dadosCasoSchema.partial(), req.body) };
  const [atualizado] = await db
    .update(casos)
    .set({ dadosEnc: cifrarJson(novos, dek), atualizadoEm: new Date() })
    .where(eq(casos.id, caso.id))
    .returning();
  await registrarEventoCaso(caso.id, 'ATUALIZADO', { atorId: eu(req).id });
  res.json({ ...resumoCaso(atualizado, novos), dados: novos });
});

casosRouter.delete('/:id', async (req, res) => {
  const { caso } = await carregarCaso(req.params.id, eu(req), { soDona: true });
  const arquivos = await db.select({ chave: provas.arquivoChave }).from(provas).where(eq(provas.casoId, caso.id));
  await db.delete(casos).where(eq(casos.id, caso.id));
  for (const a of arquivos) await storage.apagar(a.chave);
  res.status(204).end();
});

// ── Provas ────────────────────────────────────────────────────────
casosRouter.post('/:id/provas', uploadProva, async (req, res) => {
  const arquivo = req.file;
  if (!arquivo) throw invalido('Envie o arquivo no campo "arquivo".');
  try {
    const { caso, dek: dekCaso } = await carregarCaso(String(req.params.id), eu(req), { soDona: true });
    const extras = validar(
      z.object({
        descricao: z.string().trim().max(1000).optional(),
        dataCaptura: z.string().trim().max(40).optional(),
        nomeOriginal: z.string().trim().max(255).optional(),
        sha256Cliente: z
          .string()
          .regex(/^[a-f0-9]{64}$/i)
          .optional(),
      }),
      req.body,
    );

    if (extras.sha256Cliente) {
      // Confere antes de gravar: o arquivo chegou íntegro?
      const hash = createHash('sha256');
      for await (const pedaco of createReadStream(arquivo.path)) hash.update(pedaco as Buffer);
      if (hash.digest('hex') !== extras.sha256Cliente.toLowerCase()) {
        throw new HttpError(422, 'O arquivo chegou diferente do original. Tente enviar de novo.', 'HASH_DIVERGENTE');
      }
    }

    const prova = await armazenarProva({
      casoId: caso.id,
      dekCaso,
      caminhoArquivo: arquivo.path,
      mimeType: arquivo.mimetype,
      tamanhoBytes: arquivo.size,
      meta: {
        nomeOriginal: extras.nomeOriginal || arquivo.originalname || 'arquivo',
        descricao: extras.descricao,
        dataCaptura: extras.dataCaptura,
      },
      atorId: eu(req).id,
    });

    res.status(201).json(prova);
  } finally {
    await rm(arquivo.path, { force: true });
  }
});

casosRouter.get('/:id/provas/:provaId/arquivo', async (req, res) => {
  const { caso, acessoEquipe } = await carregarCaso(req.params.id, eu(req));
  const provaId = validar(uuid, req.params.provaId);
  const [p] = await db.select().from(provas).where(and(eq(provas.id, provaId), eq(provas.casoId, caso.id)));
  if (!p) throw naoEncontrado('Prova');

  if (acessoEquipe) {
    await registrarEventoCaso(caso.id, 'PROVA_ACESSADA_PELA_EQUIPE', {
      atorId: eu(req).id,
      daEquipe: true,
      detalhe: { provaId },
    });
  }

  const meta = decifrarJson<MetaProva>(p.metaEnc, abrirDek(caso.chaveProtegida));
  res.setHeader('Content-Type', p.mimeType);
  res.setHeader('Content-Length', String(p.tamanhoBytes));
  res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(meta.nomeOriginal)}`);
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Prova-SHA256', p.sha256);

  const decifrador = criarDecifradorArquivo(abrirDek(p.chaveProtegida), p.iv, p.authTag);
  await pipeline(storage.abrirLeitura(p.arquivoChave), decifrador, res);
});

casosRouter.delete('/:id/provas/:provaId', async (req, res) => {
  const { caso } = await carregarCaso(req.params.id, eu(req), { soDona: true });
  const provaId = validar(uuid, req.params.provaId);
  const [p] = await db
    .delete(provas)
    .where(and(eq(provas.id, provaId), eq(provas.casoId, caso.id)))
    .returning();
  if (!p) throw naoEncontrado('Prova');
  await storage.apagar(p.arquivoChave);
  await registrarEventoCaso(caso.id, 'PROVA_REMOVIDA', { atorId: eu(req).id, detalhe: { provaId, sha256: p.sha256 } });
  res.status(204).end();
});

// ── Dossiê e pacote ───────────────────────────────────────────────
casosRouter.get('/:id/dossie.pdf', async (req, res) => {
  const ctx = await carregarCaso(req.params.id, eu(req));
  const pdf = await gerarDossiePdf(ctx);
  await registrarEventoCaso(ctx.caso.id, 'DOSSIE_GERADO', { atorId: eu(req).id, daEquipe: ctx.acessoEquipe });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="dossie-${ctx.caso.id.slice(0, 8)}.pdf"`);
  res.setHeader('Cache-Control', 'no-store');
  res.end(pdf);
});

/** ZIP com o dossiê, os arquivos originais das provas e um manifesto com os hashes. */
casosRouter.get('/:id/pacote.zip', async (req, res) => {
  const ctx = await carregarCaso(req.params.id, eu(req));
  const lista = await db.select().from(provas).where(eq(provas.casoId, ctx.caso.id));
  const pdf = await gerarDossiePdf(ctx);

  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="pacote-${ctx.caso.id.slice(0, 8)}.zip"`);
  res.setHeader('Cache-Control', 'no-store');

  const zip = new ZipArchive({ zlib: { level: 6 } });
  zip.on('error', (e: Error) => res.destroy(e));
  zip.pipe(res);
  zip.append(pdf, { name: 'dossie.pdf' });

  const linhas = ['SHA-256                                                           ARQUIVO'];
  for (const [i, p] of lista.entries()) {
    const meta = decifrarJson<MetaProva>(p.metaEnc, ctx.dek);
    const nome = `provas/${String(i + 1).padStart(2, '0')}-${meta.nomeOriginal.replace(/[\\/:*?"<>|]/g, '_')}`;
    linhas.push(`${p.sha256}  ${nome}`);
    zip.append(storage.abrirLeitura(p.arquivoChave).pipe(criarDecifradorArquivo(abrirDek(p.chaveProtegida), p.iv, p.authTag)), {
      name: nome,
    });
  }
  zip.append(
    `Manifesto de integridade — gerado pelo Amparo em ${new Date().toISOString()}\n\n${linhas.join('\n')}\n\n` +
      'Para conferir: no Linux/macOS rode "shasum -a 256 arquivo"; no Windows, "certutil -hashfile arquivo SHA256".\n',
    { name: 'manifesto-sha256.txt' },
  );
  await registrarEventoCaso(ctx.caso.id, 'PACOTE_GERADO', { atorId: eu(req).id, daEquipe: ctx.acessoEquipe });
  await zip.finalize();
});

// ── Compartilhamento com a equipe de acolhimento ──────────────────
casosRouter.post('/:id/compartilhar', async (req, res) => {
  const { caso, dek } = await carregarCaso(req.params.id, eu(req), { soDona: true });
  const { mensagem } = validar(
    z.object({
      consentimento: z.literal(true, 'É preciso consentir com o compartilhamento'),
      mensagem: z.string().trim().max(3000).optional(),
    }),
    req.body,
  );
  if (caso.compartilhadoEm) throw invalido('Este caso já está compartilhado.');

  await db
    .update(casos)
    .set({ status: 'COMPARTILHADO', compartilhadoEm: new Date(), atualizadoEm: new Date() })
    .where(eq(casos.id, caso.id));
  await registrarEventoCaso(caso.id, 'COMPARTILHADO', { atorId: eu(req).id });
  if (mensagem) {
    await db.insert(mensagensCaso).values({ casoId: caso.id, autoraId: eu(req).id, daEquipe: false, corpoEnc: cifrarTexto(mensagem, dek) });
  }
  res.json({ status: 'COMPARTILHADO', mensagem: 'Caso compartilhado. A equipe de acolhimento vai entrar em contato por aqui.' });
});

casosRouter.post('/:id/revogar-compartilhamento', async (req, res) => {
  const { caso } = await carregarCaso(req.params.id, eu(req), { soDona: true });
  if (!caso.compartilhadoEm) throw invalido('Este caso não está compartilhado.');
  await db
    .update(casos)
    .set({ status: 'REGISTRADO', compartilhadoEm: null, responsavelId: null, atualizadoEm: new Date() })
    .where(eq(casos.id, caso.id));
  await registrarEventoCaso(caso.id, 'COMPARTILHAMENTO_REVOGADO', { atorId: eu(req).id });
  res.json({ status: 'REGISTRADO' });
});

// ── Mensagens (dona ↔ equipe de acolhimento) ──────────────────────
casosRouter.get('/:id/mensagens', async (req, res) => {
  const { caso, dek } = await carregarCaso(req.params.id, eu(req));
  res.json(await listarMensagens(caso.id, dek, eu(req).id));
});

casosRouter.post('/:id/mensagens', async (req, res) => {
  const { caso, dek, acessoEquipe } = await carregarCaso(req.params.id, eu(req));
  if (!caso.compartilhadoEm) throw invalido('Compartilhe o caso com a equipe para trocar mensagens.');
  const { corpo } = validar(z.object({ corpo: z.string().trim().min(1).max(5000) }), req.body);
  const [m] = await db
    .insert(mensagensCaso)
    .values({ casoId: caso.id, autoraId: eu(req).id, daEquipe: acessoEquipe, corpoEnc: cifrarTexto(corpo, dek) })
    .returning();
  await db.update(casos).set({ atualizadoEm: new Date() }).where(eq(casos.id, caso.id));
  await registrarEventoCaso(caso.id, 'MENSAGEM', { atorId: eu(req).id, daEquipe: acessoEquipe });
  res.status(201).json({ id: m.id, daEquipe: m.daEquipe, corpo, criadoEm: m.criadoEm });
});
