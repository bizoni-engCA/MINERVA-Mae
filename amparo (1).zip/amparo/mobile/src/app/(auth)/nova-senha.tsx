import { useEffect, useState } from 'react';
import { router } from 'expo-router';
import { api, mensagemDeErro } from '@/api/cliente';
import type { Sessao } from '@/api/tipos';
import { Aviso, Botao, Campo, Espaco, Texto, Titulo, Tela } from '@/components/ui';
import { useFluxo } from '@/store/fluxo';
import { useSessao } from '@/store/sessao';
import { espaco } from '@/theme';

export default function NovaSenha() {
  const token = useFluxo((s) => s.tokenVerificacao);
  const definirSessao = useSessao((s) => s.definir);
  const [senha, setSenha] = useState('');
  const [confirmacao, setConfirmacao] = useState('');
  const [erro, setErro] = useState<string | null>(null);
  const [carregando, setCarregando] = useState(false);

  useEffect(() => {
    if (!token) router.replace('/verificar?finalidade=REDEFINIR_SENHA');
  }, [token]);

  async function salvar() {
    setErro(null);
    setCarregando(true);
    try {
      const s = await api<Sessao>('/api/auth/redefinir-senha', { corpo: { tokenVerificacao: token, novaSenha: senha }, semAuth: true });
      useFluxo.getState().definir(null);
      await definirSessao(s);
    } catch (e) {
      setErro(mensagemDeErro(e));
    } finally {
      setCarregando(false);
    }
  }

  return (
    <Tela>
      <Titulo>Crie uma nova senha</Titulo>
      <Texto fraco style={{ marginTop: espaco.s, marginBottom: espaco.xl }}>
        Por segurança, todos os aparelhos conectados à sua conta vão precisar entrar de novo.
      </Texto>
      <Campo rotulo="Nova senha" value={senha} onChangeText={setSenha} secureTextEntry autoCapitalize="none" ajuda="Pelo menos 8 caracteres." />
      <Campo
        rotulo="Repita a nova senha"
        value={confirmacao}
        onChangeText={setConfirmacao}
        secureTextEntry
        autoCapitalize="none"
        erro={confirmacao && senha !== confirmacao ? 'As senhas não são iguais.' : null}
      />
      {erro ? <Aviso tom="perigo">{erro}</Aviso> : null}
      <Espaco />
      <Botao titulo="Salvar e entrar" onPress={salvar} carregando={carregando} desativado={senha.length < 8 || senha !== confirmacao} />
    </Tela>
  );
}
