import { create } from 'zustand';
import * as Crypto from 'expo-crypto';
import { armazenamento } from '@/lib/armazenamento';

const CHAVE = 'amparo.seguranca';

export type Preferencias = {
  pinHash: string | null;
  pinSal: string | null;
  biometria: boolean;
  /** Disfarce escolhido (ícone/nome). "padrao" = Minerva Mãe. */
  disfarce: string;
  /** Ao abrir, mostra a calculadora em vez da tela de PIN. */
  abrirComoCalculadora: boolean;
  /** Segundos em segundo plano antes de bloquear (0 = na hora). */
  bloqueioAutomaticoSeg: number;
  /** Mostrar conteúdo sensível sem borrar. */
  mostrarSensiveis: boolean;
};

const PADRAO: Preferencias = {
  pinHash: null,
  pinSal: null,
  biometria: false,
  disfarce: 'padrao',
  abrirComoCalculadora: false,
  bloqueioAutomaticoSeg: 30,
  mostrarSensiveis: false,
};

type EstadoSeguranca = Preferencias & {
  carregada: boolean;
  bloqueada: boolean;
  telaBloqueio: 'pin' | 'calculadora';
  tentativasErradas: number;
  bloqueadaAte: number;
  carregar: () => Promise<void>;
  atualizar: (p: Partial<Preferencias>) => Promise<void>;
  definirPin: (pin: string) => Promise<void>;
  conferirPin: (pin: string) => Promise<'ok' | 'errado' | 'aguarde' | 'excedido'>;
  /** Confere sem contar tentativas (usado pela calculadora, onde contas normais terminam em "="). */
  pinConfere: (pin: string) => Promise<boolean>;
  desbloquear: () => void;
  bloquear: (tela?: 'pin' | 'calculadora') => void;
  /** Saída rápida: esconde tudo atrás da calculadora. */
  sairRapido: () => void;
  apagarTudo: () => Promise<void>;
};

const hashPin = async (pin: string, sal: string) =>
  Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, `${sal}:${pin}`);

export const useSeguranca = create<EstadoSeguranca>((set, get) => ({
  ...PADRAO,
  carregada: false,
  bloqueada: true,
  telaBloqueio: 'pin',
  tentativasErradas: 0,
  bloqueadaAte: 0,

  async carregar() {
    const salvas = (await armazenamento.ler<Preferencias>(CHAVE)) ?? PADRAO;
    set({
      ...PADRAO,
      ...salvas,
      carregada: true,
      bloqueada: Boolean(salvas.pinHash),
      telaBloqueio: salvas.abrirComoCalculadora ? 'calculadora' : 'pin',
    });
  },

  async atualizar(p) {
    set(p);
    const { pinHash, pinSal, biometria, disfarce, abrirComoCalculadora, bloqueioAutomaticoSeg, mostrarSensiveis } = get();
    await armazenamento.gravar(CHAVE, {
      pinHash,
      pinSal,
      biometria,
      disfarce,
      abrirComoCalculadora,
      bloqueioAutomaticoSeg,
      mostrarSensiveis,
    } satisfies Preferencias);
  },

  async definirPin(pin) {
    const sal = Array.from(Crypto.getRandomBytes(16), (b) => b.toString(16).padStart(2, '0')).join('');
    await get().atualizar({ pinSal: sal, pinHash: await hashPin(pin, sal) });
    set({ bloqueada: false, tentativasErradas: 0 });
  },

  async conferirPin(pin) {
    const { pinHash, pinSal, tentativasErradas, bloqueadaAte } = get();
    if (Date.now() < bloqueadaAte) return 'aguarde';
    if (!pinHash || !pinSal) return 'errado';
    if ((await hashPin(pin, pinSal)) === pinHash) {
      set({ bloqueada: false, tentativasErradas: 0, bloqueadaAte: 0 });
      return 'ok';
    }
    const n = tentativasErradas + 1;
    // 5 erros → espera 30 s; 10 erros → encerra a sessão neste aparelho.
    set({ tentativasErradas: n, bloqueadaAte: n % 5 === 0 ? Date.now() + 30_000 : 0 });
    return n >= 10 ? 'excedido' : n % 5 === 0 ? 'aguarde' : 'errado';
  },

  async pinConfere(pin) {
    const { pinHash, pinSal } = get();
    return Boolean(pinHash && pinSal && (await hashPin(pin, pinSal)) === pinHash);
  },

  desbloquear: () => set({ bloqueada: false, tentativasErradas: 0 }),

  bloquear: (tela) =>
    set((s) => ({ bloqueada: Boolean(s.pinHash), telaBloqueio: tela ?? (s.abrirComoCalculadora ? 'calculadora' : 'pin') })),

  sairRapido: () => set({ bloqueada: true, telaBloqueio: 'calculadora' }),

  async apagarTudo() {
    await armazenamento.apagar(CHAVE);
    set({ ...PADRAO, bloqueada: false, telaBloqueio: 'pin', tentativasErradas: 0, bloqueadaAte: 0 });
  },
}));
