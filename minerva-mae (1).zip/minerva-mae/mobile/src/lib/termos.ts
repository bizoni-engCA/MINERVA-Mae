/** Termos de uso e privacidade exibidos no cadastro e em Ajustes. */
export const TERMOS = `> Versão do MVP (novembro de 2026). Antes de um uso real, este texto precisa ser revisado juridicamente e aprovado pela equipe responsável.

## O que é a Minerva Mãe
Uma rede de apoio para estudantes da UFRJ que são mulheres (cis ou trans) ou pessoas não-binárias. A Minerva Mãe **não substitui** os canais oficiais de denúncia nem serviços de emergência. Em perigo, ligue **190**.

## O que guardamos
- Seu **apelido** e sua senha (protegida com um algoritmo próprio para senhas).
- Uma **versão irreversível do seu DRE** — serve só para impedir contas duplicadas. Não guardamos o número, seu nome nem seu e-mail.
- O que você publica, seus casos e suas provas.

## Como protegemos
- Casos, mensagens e provas são **criptografados** no servidor, cada um com sua própria chave.
- Ninguém da equipe vê seus casos, a não ser que **você** decida compartilhar — e cada acesso da equipe aparece na linha do tempo do caso.
- A moderação vê o conteúdo dos relatos para revisá-los, mas não sabe quem você é quando você publica como anônima.

## Regras de convivência
- Não identifique pessoas nos relatos públicos (nomes, cargos com nome, disciplinas, perfis). Use o campo **só para a moderação**.
- Acolha. Nada de duvidar, julgar ou culpar quem relata.
- Discurso de ódio, ataques e exposição levam a suspensão ou banimento.
- Não faça prints nem compartilhe relatos fora do app.

## Seus direitos (LGPD)
Você pode, a qualquer momento, ver e corrigir seus dados e **excluir sua conta** em Ajustes — isso apaga definitivamente relatos, comentários, vídeos, casos e provas.`;
