import { useState } from 'react';
import { View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { useVideoPlayer, VideoView } from 'expo-video';
import { useQueryClient } from '@tanstack/react-query';
import { api, formComArquivo, mensagemDeErro } from '@/api/cliente';
import { Aviso, Bloco, Botao, Campo, Espaco, Interruptor, Linha, Texto, Tela } from '@/components/ui';
import { cores, espaco, raio } from '@/theme';

type Escolhido = { uri: string; nome: string; mime: string; duracao?: number | null };

export default function NovoVideo() {
  const qc = useQueryClient();
  const [video, setVideo] = useState<Escolhido | null>(null);
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [mostrarApelido, setMostrarApelido] = useState(false);
  const [sensivel, setSensivel] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const player = useVideoPlayer(video ? { uri: video.uri } : null);

  async function escolher(origem: 'galeria' | 'camera') {
    const opcoes: ImagePicker.ImagePickerOptions = { mediaTypes: ['videos'], videoMaxDuration: 300, quality: 1 };
    if (origem === 'camera') {
      const perm = await ImagePicker.requestCameraPermissionsAsync();
      if (!perm.granted) return Alert.alert('Sem acesso à câmera', 'Permita o acesso nas configurações do celular.');
    }
    const r = origem === 'galeria' ? await ImagePicker.launchImageLibraryAsync(opcoes) : await ImagePicker.launchCameraAsync(opcoes);
    if (r.canceled || !r.assets[0]) return;
    const a = r.assets[0];
    if (a.duration && a.duration > 300_000) return Alert.alert('Vídeo longo demais', 'O vídeo pode ter no máximo 5 minutos.');
    setVideo({ uri: a.uri, nome: a.fileName ?? 'video.mp4', mime: a.mimeType ?? 'video/mp4', duracao: a.duration });
  }

  async function enviar() {
    if (!video) return;
    setEnviando(true);
    try {
      const form = await formComArquivo(video, {
        titulo: titulo.trim(),
        descricao: descricao.trim(),
        mostrarApelido: String(mostrarApelido),
        sensivel: String(sensivel),
      });
      const r = await api<{ mensagem: string }>('/api/videos', { form });
      qc.invalidateQueries({ queryKey: ['meus-videos'] });
      Alert.alert('Vídeo enviado', r.mensagem, [{ text: 'Ok', onPress: () => router.back() }]);
    } catch (e) {
      Alert.alert('Não foi possível enviar', mensagemDeErro(e));
    } finally {
      setEnviando(false);
    }
  }

  return (
    <Tela rodape={<Botao titulo="Enviar para aprovação" onPress={enviar} carregando={enviando} desativado={!video || titulo.trim().length < 3} />}>
      <Texto fraco style={{ marginBottom: espaco.l }}>
        Conte como você atravessou uma situação difícil e o que te ajudou. Seu vídeo passa pela moderação antes de aparecer.
      </Texto>

      {video ? (
        <View>
          <VideoView player={player} style={{ width: '100%', height: 320, borderRadius: raio.medio, backgroundColor: '#000' }} contentFit="contain" nativeControls />
          <Botao titulo="Trocar vídeo" variante="fantasma" compacto estilo={{ alignSelf: 'flex-start', marginTop: espaco.s }} onPress={() => setVideo(null)} />
        </View>
      ) : (
        <Linha espacamento={espaco.m}>
          <Botao titulo="Da galeria" icone="images-outline" variante="secundario" estilo={{ flex: 1 }} onPress={() => escolher('galeria')} />
          <Botao titulo="Gravar" icone="videocam-outline" variante="secundario" estilo={{ flex: 1 }} onPress={() => escolher('camera')} />
        </Linha>
      )}
      <Espaco />

      <Aviso tom="cuidado" titulo="Proteja você e outras pessoas">
        Não mostre nem diga nomes, rostos de terceiros, placas, crachás ou lugares que permitam identificar alguém. Se preferir, grave só a voz ou
        com o rosto fora de quadro.
      </Aviso>
      <Espaco />

      <Campo rotulo="Título" value={titulo} onChangeText={setTitulo} contador={100} placeholder="ex.: Um ano depois, voltei a amar meu curso" />
      <Campo rotulo="Descrição (opcional)" value={descricao} onChangeText={setDescricao} multiline contador={1000} style={{ minHeight: 90 }} />

      <Bloco>
        <Interruptor titulo="Mostrar meu apelido" descricao="Se desligado, o vídeo aparece como de “Anônima”." valor={mostrarApelido} aoMudar={setMostrarApelido} />
        <Interruptor titulo="Conteúdo sensível" descricao="O vídeo fica coberto até a pessoa escolher assistir." valor={sensivel} aoMudar={setSensivel} />
      </Bloco>
      <Texto pequeno fraco style={{ marginTop: espaco.m, color: cores.nevoa }}>
        Máximo de 5 minutos e 100 MB.
      </Texto>
    </Tela>
  );
}
