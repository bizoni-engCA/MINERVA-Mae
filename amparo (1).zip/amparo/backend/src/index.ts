import { networkInterfaces } from 'node:os';
import { criarApp } from './app';
import { config } from './config';
import { logger } from './lib/logger';

const app = criarApp();

app.listen(config.PORT, '0.0.0.0', () => {
  const ips = Object.values(networkInterfaces())
    .flat()
    .filter((i) => i && i.family === 'IPv4' && !i.internal)
    .map((i) => i!.address);
  logger.info(`🟣 Amparo API rodando na porta ${config.PORT}`);
  for (const ip of ips) logger.info(`   No celular, use: EXPO_PUBLIC_API_URL=http://${ip}:${config.PORT}`);
});
