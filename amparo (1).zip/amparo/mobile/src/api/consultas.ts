import { QueryClient, useInfiniteQuery, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from './cliente';
import type {
  AlertaIdentificacao,
  Caso,
  Comentario,
  ComentarioModeracao,
  Comunidade,
  Contato,
  GrupoSinalizacao,
  Guia,
  GuiaResumo,
  Pagina,
  Post,
  PostModeracao,
  ReacaoTipo,
  Reacoes,
  ResumoCaso,
  ResumoEquipe,
  Video,
  VideoModeracao,
} from './tipos';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 20_000, refetchOnWindowFocus: false },
    mutations: { retry: 0 },
  },
});

const paginado = <T,>(base: string) => ({
  initialPageParam: undefined as string | undefined,
  queryFn: ({ pageParam }: { pageParam: string | undefined }) =>
    api<Pagina<T>>(`${base}${base.includes('?') ? '&' : '?'}${pageParam ? `cursor=${encodeURIComponent(pageParam)}` : ''}`),
  getNextPageParam: (ultima: Pagina<T>) => ultima.proximoCursor ?? undefined,
});

// ── Comunidades e relatos ─────────────────────────────────────────
export const useComunidades = () => useQuery({ queryKey: ['comunidades'], queryFn: () => api<Comunidade[]>('/api/comunidades') });
export const useComunidade = (slug: string) =>
  useQuery({ queryKey: ['comunidade', slug], queryFn: () => api<Comunidade>(`/api/comunidades/${slug}`) });

export const useFeed = () => useInfiniteQuery({ queryKey: ['feed'], ...paginado<Post>('/api/posts/feed') });
export const usePostsComunidade = (id?: string) =>
  useInfiniteQuery({ queryKey: ['posts', id], enabled: !!id, ...paginado<Post>(`/api/comunidades/${id}/posts`) });
export const usePost = (id: string) => useQuery({ queryKey: ['post', id], queryFn: () => api<Post>(`/api/posts/${id}`) });
export const useComentarios = (id: string) =>
  useQuery({ queryKey: ['comentarios', id], queryFn: () => api<Comentario[]>(`/api/posts/${id}/comentarios`) });
export const useMeusPosts = () => useQuery({ queryKey: ['meus-posts'], queryFn: () => api<Post[]>('/api/posts/meus') });

export function useParticipar() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, participar }: { id: string; participar: boolean }) =>
      api(`/api/comunidades/${id}/participar`, { metodo: participar ? 'POST' : 'DELETE' }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['comunidades'] });
      qc.invalidateQueries({ queryKey: ['comunidade'] });
      qc.invalidateQueries({ queryKey: ['feed'] });
    },
  });
}

export function useReagirPost(postId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (tipo: ReacaoTipo) =>
      api<{ reacoes: Reacoes; minhasReacoes: ReacaoTipo[] }>(`/api/posts/${postId}/reacoes`, { corpo: { tipo } }),
    onSuccess: (r) => {
      qc.setQueryData<Post>(['post', postId], (p) => (p ? { ...p, ...r } : p));
      const atualizarPaginas = (dados: { pages: Pagina<Post>[]; pageParams: unknown[] } | undefined) =>
        dados && {
          ...dados,
          pages: dados.pages.map((pg) => ({ ...pg, itens: pg.itens.map((p) => (p.id === postId ? { ...p, ...r } : p)) })),
        };
      qc.setQueriesData({ queryKey: ['feed'] }, atualizarPaginas);
      qc.setQueriesData({ queryKey: ['posts'] }, atualizarPaginas);
    },
  });
}

export const verificarTexto = (texto: string) =>
  api<{ alertas: AlertaIdentificacao[] }>('/api/posts/verificar-texto', { corpo: { texto } });

export const sinalizar = (alvoTipo: 'POST' | 'COMENTARIO' | 'VIDEO', alvoId: string, motivo: string, detalhes?: string) =>
  api<{ mensagem: string }>('/api/sinalizacoes', { corpo: { alvoTipo, alvoId, motivo, detalhes } });

// ── Vídeos ────────────────────────────────────────────────────────
export const useVideos = () => useInfiniteQuery({ queryKey: ['videos'], ...paginado<Video>('/api/videos?limite=8') });
export const useMeusVideos = () => useQuery({ queryKey: ['meus-videos'], queryFn: () => api<Video[]>('/api/videos/meus') });

// ── Casos ─────────────────────────────────────────────────────────
export const useCasos = () => useQuery({ queryKey: ['casos'], queryFn: () => api<ResumoCaso[]>('/api/casos') });
export const useCaso = (id: string) =>
  useQuery({ queryKey: ['caso', id], enabled: Boolean(id), queryFn: () => api<Caso>(`/api/casos/${id}`) });

export function useInvalidarCaso(id: string) {
  const qc = useQueryClient();
  return () => {
    qc.invalidateQueries({ queryKey: ['caso', id] });
    qc.invalidateQueries({ queryKey: ['casos'] });
    qc.invalidateQueries({ queryKey: ['equipe'] });
  };
}

// ── Orientação ────────────────────────────────────────────────────
export const useRecursos = () =>
  useQuery({
    queryKey: ['recursos'],
    staleTime: 60 * 60_000,
    queryFn: () => api<{ atualizadoEm: string; guias: GuiaResumo[]; contatos: Contato[] }>('/api/recursos'),
  });
export const useGuia = (slug: string) =>
  useQuery({ queryKey: ['guia', slug], staleTime: 60 * 60_000, queryFn: () => api<Guia>(`/api/recursos/guias/${slug}`) });

// ── Equipe ────────────────────────────────────────────────────────
export const useResumoEquipe = (ativo: boolean) =>
  useQuery({ queryKey: ['equipe', 'resumo'], enabled: ativo, queryFn: () => api<ResumoEquipe>('/api/equipe/resumo') });
export const useFilaPosts = (fila: string) =>
  useQuery({ queryKey: ['equipe', 'posts', fila], queryFn: () => api<PostModeracao[]>(`/api/equipe/moderacao/posts?fila=${fila}`) });
export const useFilaComentarios = () =>
  useQuery({ queryKey: ['equipe', 'comentarios'], queryFn: () => api<ComentarioModeracao[]>('/api/equipe/moderacao/comentarios') });
export const useFilaVideos = () =>
  useQuery({ queryKey: ['equipe', 'videos'], queryFn: () => api<VideoModeracao[]>('/api/equipe/moderacao/videos') });
export const useSinalizacoes = () =>
  useQuery({ queryKey: ['equipe', 'sinalizacoes'], queryFn: () => api<GrupoSinalizacao[]>('/api/equipe/moderacao/sinalizacoes') });
export const useCasosEquipe = (filtro: string) =>
  useQuery({ queryKey: ['equipe', 'casos', filtro], queryFn: () => api<ResumoCaso[]>(`/api/equipe/casos?filtro=${filtro}`) });
