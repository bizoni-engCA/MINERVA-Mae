import { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import { useQueryClient } from '@tanstack/react-query';
import { useCaso } from '@/api/consultas';
import { api, mensagemDeErro } from '@/api/cliente';
import type { DadosCaso } from '@/api/tipos';
import { Aviso, Botao, Campo, Carregando, Chip, Espaco, Texto, Tela } from '@/components/ui';
import { TIPOS_VIOLENCIA, VINCULOS_AUTOR } from '@/lib/rotulos';
import { espaco } from '@/theme';

const VAZIO: DadosCaso = { titulo: '', relato: '', tiposViolencia: [] };

/** Criar ou editar um caso. Só o título é obrigatório — o resto pode ser completado depois. */
export default function FormularioCaso() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  const existente = useCaso(id ?? '');
  const qc = useQueryClient();
  const [d, setD] = useState<DadosCaso>(VAZIO);
  const [carregado, setCarregado] = useState(!id);
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    if (id && existente.data && !carregado) {
      setD({ ...VAZIO, ...existente.data.dados });
      setCarregado(true);
    }
  }, [id, existente.data, carregado]);

  const campo = (k: keyof DadosCaso) => ({
    value: (d[k] as string | undefined) ?? '',
    onChangeText: (t: string) => setD((atual) => ({ ...atual, [k]: t })),
  });

  async function salvar() {
    setSalvando(true);
    try {
      const corpo = Object.fromEntries(Object.entries(d).map(([k, v]) => [k, typeof v === 'string' ? v.trim() || undefined : v]));
      corpo.relato = d.relato.trim();
      const r = await api<{ id: string }>(id ? `/api/casos/${id}` : '/api/casos', { metodo: id ? 'PATCH' : 'POST', corpo });
      qc.invalidateQueries({ queryKey: ['casos'] });
      qc.invalidateQueries({ queryKey: ['caso', r.id] });
      if (id) router.back();
      else router.replace(`/caso/${r.id}`);
    } catch (e) {
      Alert.alert('Não foi possível salvar', mensagemDeErro(e));
    } finally {
      setSalvando(false);
    }
  }

  if (id && !carregado) return <Carregando />;

  return (
    <Tela rodape={<Botao titulo={id ? 'Salvar alterações' : 'Guardar no cofre'} onPress={salvar} carregando={salvando} desativado={d.titulo.trim().length < 3} />}>
      <Stack.Screen options={{ title: id ? 'Editar caso' : 'Registrar caso' }} />
      <Aviso tom="info">
        Escreva no seu tempo. Tudo aqui é criptografado e só você vê. Você pode salvar só com um título e completar depois.
      </Aviso>
      <Espaco />

      <Campo rotulo="Título (para você reconhecer o caso)" {...campo('titulo')} contador={120} placeholder="ex.: Mensagens do monitor" />

      <Texto negrito style={{ marginBottom: espaco.s }}>Que tipo de situação?</Texto>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: espaco.s, marginBottom: espaco.l }}>
        {Object.entries(TIPOS_VIOLENCIA).map(([k, rotulo]) => {
          const ativo = d.tiposViolencia.includes(k);
          return (
            <Chip
              key={k}
              rotulo={rotulo}
              ativo={ativo}
              onPress={() => setD((a) => ({ ...a, tiposViolencia: ativo ? a.tiposViolencia.filter((t) => t !== k) : [...a.tiposViolencia, k] }))}
            />
          );
        })}
      </View>

      <Campo rotulo="Quando aconteceu?" {...campo('dataOcorrido')} placeholder="ex.: 12/09/2026, ou “entre agosto e outubro”" />
      <Campo rotulo="Onde aconteceu?" {...campo('local')} placeholder="ex.: laboratório do bloco, ônibus interno, grupo de WhatsApp" />

      <Texto negrito style={{ marginBottom: espaco.s }}>Quem cometeu a violência tem qual vínculo com a UFRJ?</Texto>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: espaco.s, marginBottom: espaco.l }}>
        {Object.entries(VINCULOS_AUTOR).map(([k, rotulo]) => (
          <Chip key={k} rotulo={rotulo} ativo={d.vinculoAutor === k} onPress={() => setD((a) => ({ ...a, vinculoAutor: a.vinculoAutor === k ? undefined : k }))} />
        ))}
      </View>

      <Campo
        rotulo="O que aconteceu"
        {...campo('relato')}
        multiline
        contador={30000}
        style={{ minHeight: 220 }}
        placeholder="Descreva o que aconteceu, o que foi dito ou feito, e o que aconteceu depois. Detalhes como horários e palavras exatas ajudam."
      />
      <Campo rotulo="Pessoas envolvidas" {...campo('pessoasEnvolvidas')} multiline contador={3000} style={{ minHeight: 90 }} ajuda="Aqui você pode escrever nomes e cargos. Este campo é privado." />
      <Campo rotulo="Testemunhas" {...campo('testemunhas')} multiline contador={3000} style={{ minHeight: 80 }} placeholder="Quem viu, ouviu ou soube na época" />
      <Campo rotulo="Como isso te afetou" {...campo('impactos')} multiline contador={5000} style={{ minHeight: 80 }} placeholder="Faltas, notas, saúde, sono, medo de ir a certos lugares…" />
      <Campo rotulo="Providências que você já tomou" {...campo('providenciasTomadas')} multiline contador={5000} style={{ minHeight: 80 }} placeholder="Contou para alguém? Procurou a coordenação, a Ouvidoria, a polícia?" />
      <Campo rotulo="Observações" {...campo('observacoes')} multiline contador={5000} style={{ minHeight: 80 }} />
    </Tela>
  );
}
