import pino from 'pino';
import { isProd, isTest } from '../config';

export const logger = pino({
  level: isTest ? 'silent' : 'info',
  // Nunca registrar conteúdo de relatos, tokens ou senhas.
  redact: ['req.headers.authorization', 'req.headers.cookie', '*.senha', '*.token', '*.tokenRenovacao'],
  transport: isProd || isTest ? undefined : { target: 'pino-pretty', options: { colorize: true, translateTime: 'HH:MM:ss' } },
});
