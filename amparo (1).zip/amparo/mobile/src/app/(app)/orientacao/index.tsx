import { Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useRecursos } from '@/api/consultas';
import { mensagemDeErro } from '@/api/cliente';
import type { Contato, GuiaResumo } from '@/api/tipos';
import { Botao, Carregando, ErroTela, Icone, Linha, Texto, Titulo, type NomeIcone } from '@/components/ui';
import { cores, espaco, fontes, raio } from '@/theme';

const CATEGORIAS_GUIA: Record<GuiaResumo['categoria'], string> = {
  ACOLHIMENTO: 'Acolhimento',
  DENUNCIA: 'Denúncia e provas',
  JURIDICA: 'Orientação jurídica',
  PSICOLOGICA: 'Cuidado psicológico',
};
const CATEGORIAS_CONTATO: Record<Contato['categoria'], string> = {
  EMERGENCIA: 'Emergência e atendimento 24h',
  UFRJ: 'Na UFRJ',
  APOIO: 'Apoio psicológico e social',
  JURIDICO: 'Orientação jurídica gratuita',
  POLICIA: 'Registro de ocorrência',
};

export default function Orientacao() {
  const q = useRecursos();
  if (q.isLoading) return <Carregando />;
  if (q.isError || !q.data) return <ErroTela mensagem={mensagemDeErro(q.error)} tentarDeNovo={q.refetch} />;
  const { guias, contatos, atualizadoEm } = q.data;

  return (
    <ScrollView style={{ backgroundColor: cores.papel }} contentContainerStyle={{ padding: espaco.l, paddingBottom: espaco.xxl * 2 }}>
      <Texto fraco>Guias para entender seus direitos e decidir os próximos passos, no seu tempo. Este conteúdo não substitui atendimento profissional.</Texto>

      {(Object.keys(CATEGORIAS_GUIA) as GuiaResumo['categoria'][]).map((cat) => {
        const lista = guias.filter((g) => g.categoria === cat);
        if (!lista.length) return null;
        return (
          <View key={cat} style={{ marginTop: espaco.xl }}>
            <Titulo nivel={3}>{CATEGORIAS_GUIA[cat]}</Titulo>
            {lista.map((g) => (
              <Pressable key={g.slug} onPress={() => router.push(`/orientacao/${g.slug}`)} style={({ pressed }) => [estilos.guia, pressed && { opacity: 0.7 }]} accessibilityRole="button">
                <View style={estilos.guiaIcone}>
                  <Icone nome={g.icone as NomeIcone} cor={cores.lilas} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={estilos.guiaTitulo}>{g.titulo}</Text>
                  <Texto pequeno fraco>
                    {g.resumo} · {g.tempoLeituraMin} min
                  </Texto>
                </View>
              </Pressable>
            ))}
          </View>
        );
      })}

      <Titulo nivel={2} style={{ marginTop: espaco.xxl }}>
        Contatos
      </Titulo>
      {(Object.keys(CATEGORIAS_CONTATO) as Contato['categoria'][]).map((cat) => {
        const lista = contatos.filter((c) => c.categoria === cat);
        if (!lista.length) return null;
        return (
          <View key={cat} style={{ marginTop: espaco.l }}>
            <Text style={estilos.categoria}>{CATEGORIAS_CONTATO[cat]}</Text>
            {lista.map((c) => (
              <CartaoContato key={c.id} c={c} />
            ))}
          </View>
        );
      })}
      <Texto pequeno fraco style={{ marginTop: espaco.xl }}>
        Informações conferidas em {atualizadoEm.split('-').reverse().join('/')}. Telefones e horários podem mudar — na dúvida, confira no site oficial de cada serviço.
      </Texto>
    </ScrollView>
  );
}

function CartaoContato({ c }: { c: Contato }) {
  const acoes: { rotulo: string; icone: NomeIcone; url: string }[] = [
    ...(c.telefone ? [{ rotulo: `Ligar ${c.telefone}`, icone: 'call-outline' as const, url: `tel:${c.telefone.replace(/\D/g, '')}` }] : []),
    ...(c.whatsapp ? [{ rotulo: 'WhatsApp', icone: 'logo-whatsapp' as const, url: `https://wa.me/55${c.whatsapp.replace(/\D/g, '')}` }] : []),
    ...(c.email ? [{ rotulo: 'E-mail', icone: 'mail-outline' as const, url: `mailto:${c.email}` }] : []),
    ...(c.site ? [{ rotulo: 'Site', icone: 'globe-outline' as const, url: c.site }] : []),
  ];
  return (
    <View style={estilos.contato}>
      <Text style={estilos.contatoNome}>{c.nome}</Text>
      <Texto pequeno style={{ marginTop: 2 }}>
        {c.descricao}
      </Texto>
      {c.endereco ? (
        <Linha espacamento={6} estilo={{ marginTop: 6, alignItems: 'flex-start' }}>
          <Icone nome="location-outline" tamanho={15} cor={cores.nevoa} />
          <Texto pequeno fraco style={{ flex: 1 }}>
            {c.endereco}
          </Texto>
        </Linha>
      ) : null}
      {c.horario ? (
        <Linha espacamento={6} estilo={{ marginTop: 4 }}>
          <Icone nome="time-outline" tamanho={15} cor={cores.nevoa} />
          <Texto pequeno fraco>
            {c.horario}
          </Texto>
        </Linha>
      ) : null}
      {acoes.length ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: espaco.s, marginTop: espaco.m }}>
          {acoes.map((a) => (
            <Botao key={a.rotulo} titulo={a.rotulo} icone={a.icone} variante="secundario" compacto onPress={() => Linking.openURL(a.url)} />
          ))}
        </View>
      ) : null}
    </View>
  );
}

const estilos = StyleSheet.create({
  guia: { flexDirection: 'row', gap: espaco.m, alignItems: 'center', paddingVertical: espaco.m, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: cores.linha },
  guiaIcone: { width: 42, height: 42, borderRadius: 21, backgroundColor: cores.lilasClaro, alignItems: 'center', justifyContent: 'center' },
  guiaTitulo: { fontFamily: fontes.tituloMedio, fontSize: 16.5, color: cores.tinta },
  categoria: { fontFamily: fontes.textoNegrito, fontSize: 14, color: cores.nevoa, marginBottom: espaco.s },
  contato: { backgroundColor: cores.superficie, borderRadius: raio.medio, padding: espaco.l, marginBottom: espaco.m, borderWidth: StyleSheet.hairlineWidth, borderColor: cores.linha },
  contatoNome: { fontFamily: fontes.tituloMedio, fontSize: 16.5, color: cores.tinta },
});
