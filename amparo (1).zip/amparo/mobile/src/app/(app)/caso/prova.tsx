import { useState } from 'react';
import { View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { router, useLocalSearchParams } from 'expo-router';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import { Image } from 'expo-image';
import { useInvalidarCaso } from '@/api/consultas';
import { api, formComArquivo, mensagemDeErro } from '@/api/cliente';
import type { Prova } from '@/api/tipos';
import { Aviso, Botao, Campo, Espaco, Icone, Linha, Texto, Tela } from '@/components/ui';
import { tamanho } from '@/lib/formatar';
import { cores, espaco, raio } from '@/theme';

type Arquivo = { uri: string; nome: string; mime: string; tamanho?: number; imagem?: boolean };

export default function AdicionarProva() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const invalidar = useInvalidarCaso(id);
  const [arquivo, setArquivo] = useState<Arquivo | null>(null);
  const [descricao, setDescricao] = useState('');
  const [dataCaptura, setDataCaptura] = useState('');
  const [enviando, setEnviando] = useState(false);

  async function daGaleria() {
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images', 'videos'], quality: 1, exif: false, allowsEditing: false });
    if (r.canceled || !r.assets[0]) return;
    const a = r.assets[0];
    setArquivo({ uri: a.uri, nome: a.fileName ?? (a.type === 'video' ? 'video.mp4' : 'imagem.jpg'), mime: a.mimeType ?? (a.type === 'video' ? 'video/mp4' : 'image/jpeg'), tamanho: a.fileSize, imagem: a.type === 'image' });
  }

  async function daCamera() {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) return Alert.alert('Sem acesso à câmera', 'Permita o acesso nas configurações do celular.');
    const r = await ImagePicker.launchCameraAsync({ mediaTypes: ['images', 'videos'], quality: 1 });
    if (r.canceled || !r.assets[0]) return;
    const a = r.assets[0];
    setArquivo({ uri: a.uri, nome: a.fileName ?? 'foto.jpg', mime: a.mimeType ?? 'image/jpeg', tamanho: a.fileSize, imagem: a.type === 'image' });
    if (!dataCaptura) setDataCaptura(new Date().toLocaleDateString('pt-BR'));
  }

  async function deArquivos() {
    const r = await DocumentPicker.getDocumentAsync({ type: '*/*', copyToCacheDirectory: true, multiple: false });
    if (r.canceled || !r.assets[0]) return;
    const a = r.assets[0];
    setArquivo({ uri: a.uri, nome: a.name, mime: a.mimeType ?? 'application/octet-stream', tamanho: a.size, imagem: a.mimeType?.startsWith('image/') });
  }

  async function enviar() {
    if (!arquivo) return;
    setEnviando(true);
    try {
      const form = await formComArquivo(arquivo, { descricao: descricao.trim(), dataCaptura: dataCaptura.trim(), nomeOriginal: arquivo.nome });
      const p = await api<Prova>(`/api/casos/${id}/provas`, { form });
      invalidar();
      Alert.alert(
        'Prova guardada',
        `O arquivo foi criptografado e registrado.\n\nImpressão digital (SHA-256):\n${p.sha256.slice(0, 32)}…\n\nEla aparece no dossiê e prova que o arquivo não foi alterado.`,
        [{ text: 'Ok', onPress: () => router.back() }],
      );
    } catch (e) {
      Alert.alert('Não foi possível guardar', mensagemDeErro(e));
    } finally {
      setEnviando(false);
    }
  }

  return (
    <Tela rodape={<Botao titulo="Guardar prova" onPress={enviar} carregando={enviando} desativado={!arquivo} />}>
      <Texto fraco style={{ marginBottom: espaco.l }}>
        Envie o arquivo original, sem cortar ou editar. Prints, fotos, áudios, vídeos, PDFs e e-mails exportados são aceitos (até 50 MB).
      </Texto>

      {arquivo ? (
        <View style={{ backgroundColor: cores.superficie, borderRadius: raio.medio, padding: espaco.l, gap: espaco.m }}>
          {arquivo.imagem ? <Image source={{ uri: arquivo.uri }} style={{ width: '100%', height: 220, borderRadius: raio.pequeno }} contentFit="contain" /> : null}
          <Linha>
            <Icone nome="document-attach-outline" cor={cores.lilas} />
            <View style={{ flex: 1 }}>
              <Texto negrito numberOfLines={1}>
                {arquivo.nome}
              </Texto>
              {arquivo.tamanho ? (
                <Texto pequeno fraco>
                  {tamanho(arquivo.tamanho)}
                </Texto>
              ) : null}
            </View>
            <Botao titulo="Trocar" variante="fantasma" compacto onPress={() => setArquivo(null)} />
          </Linha>
        </View>
      ) : (
        <View style={{ gap: espaco.m }}>
          <Botao titulo="Foto, print ou vídeo da galeria" icone="images-outline" variante="secundario" onPress={daGaleria} />
          <Botao titulo="Usar a câmera" icone="camera-outline" variante="secundario" onPress={daCamera} />
          <Botao titulo="Arquivo (áudio, PDF, e-mail…)" icone="folder-open-outline" variante="secundario" onPress={deArquivos} />
        </View>
      )}
      <Espaco />
      <Campo rotulo="Descrição (opcional)" value={descricao} onChangeText={setDescricao} multiline contador={1000} placeholder="O que este arquivo mostra?" style={{ minHeight: 80 }} />
      <Campo rotulo="Quando foi capturado ou recebido? (opcional)" value={dataCaptura} onChangeText={setDataCaptura} placeholder="ex.: 03/10/2026" />
      <Aviso tom="info">
        Conversas de WhatsApp: além dos prints, use “Exportar conversa” no menu da conversa e anexe o arquivo gerado.
      </Aviso>
    </Tela>
  );
}
