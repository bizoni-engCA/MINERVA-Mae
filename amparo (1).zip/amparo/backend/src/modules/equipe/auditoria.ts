import { db, schema } from '../../db';

export async function registrarAuditoria(
  atorId: string,
  acao: string,
  alvoTipo?: string,
  alvoId?: string,
  detalhe?: Record<string, unknown>,
) {
  await db.insert(schema.auditoria).values({ atorId, acao, alvoTipo, alvoId, detalhe });
}

export async function registrarEventoCaso(
  casoId: string,
  tipo: string,
  opts: { atorId?: string; daEquipe?: boolean; detalhe?: Record<string, unknown> } = {},
) {
  await db.insert(schema.eventosCaso).values({
    casoId,
    tipo,
    atorId: opts.atorId,
    daEquipe: opts.daEquipe ?? false,
    detalhe: opts.detalhe,
  });
}
