import { Redirect } from 'expo-router';
import { destinoDoEstado, useEstadoApp } from '@/lib/estado';
import { useSeguranca } from '@/store/seguranca';

/** Porta de entrada: manda para a tela certa conforme a sessão e o bloqueio. */
export default function Entrada() {
  const estado = useEstadoApp();
  const telaBloqueio = useSeguranca((s) => s.telaBloqueio);
  return <Redirect href={destinoDoEstado(estado, telaBloqueio)} />;
}
