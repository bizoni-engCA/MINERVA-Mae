import { Pressable, StyleSheet, Text } from 'react-native';
import * as Haptics from 'expo-haptics';
import { queryClient } from '@/api/consultas';
import { useSeguranca } from '@/store/seguranca';
import { cores, fontes, raio } from '@/theme';
import { Icone } from './ui';

/**
 * Botão de saída rápida, presente no topo de todas as telas.
 * Um toque esconde o app atrás da calculadora, limpa o que estava em memória
 * e exige o PIN para voltar.
 */
export function SaidaRapida() {
  const sairRapido = useSeguranca((s) => s.sairRapido);
  return (
    <Pressable
      onPress={() => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
        queryClient.clear();
        sairRapido();
      }}
      accessibilityRole="button"
      accessibilityLabel="Saída rápida"
      accessibilityHint="Esconde o app imediatamente atrás de uma calculadora"
      hitSlop={8}
      style={({ pressed }) => [estilos.botao, pressed && { opacity: 0.75 }]}
    >
      <Icone nome="eye-off" tamanho={16} cor="#FFFFFF" />
      <Text style={estilos.texto}>Sair</Text>
    </Pressable>
  );
}

const estilos = StyleSheet.create({
  botao: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: cores.sinal,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: raio.pilula,
    marginRight: 4,
  },
  texto: { color: '#FFFFFF', fontFamily: fontes.textoNegrito, fontSize: 14 },
});
