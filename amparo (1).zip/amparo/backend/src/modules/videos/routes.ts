import { Router } from 'express';
import { createReadStream } from 'node:fs';
import { mkdir, rm } from 'node:fs/promises';
import { dirname } from 'node:path';
import { pipeline } from 'node:stream/promises';
import { randomUUID } from 'node:crypto';
import { and, eq } from 'drizzle-orm';
import { db, schema } from '../../db';
import { HttpError, invalido, naoEncontrado, proibido } from '../../lib/errors';
import { duracaoSegundos, gerarCapa } from '../../lib/ffmpeg';
import { storage } from '../../lib/storage';
import { lerCursor, paginacao, uuid, validar, z } from '../../lib/validar';
import { eu, exigirLogin } from '../../middleware/auth';
import { textoParaBool, uploadVideo } from '../../middleware/upload';
import { buscarVideos } from './consultas';

export const videosRouter = Router();
videosRouter.use(exigirLogin);

const { videos, reacoesVideo } = schema;
const DURACAO_MAXIMA_SEG = 5 * 60;
const EXTENSOES: Record<string, string> = {
  'video/mp4': 'mp4',
  'video/quicktime': 'mov',
  'video/webm': 'webm',
  'video/3gpp': '3gp',
  'video/x-m4v': 'm4v',
};

const publicado = eq(videos.status, 'PUBLICADO');

videosRouter.get('/', async (req, res) => {
  const { cursor, limite } = validar(paginacao, req.query);
  const itens = await buscarVideos({ onde: publicado, usuariaId: eu(req).id, limite, cursor: lerCursor(cursor) });
  res.json({ itens, proximoCursor: itens.length === limite ? itens.at(-1)?.publicadoEm : null });
});

videosRouter.get('/meus', async (req, res) => {
  res.json(await buscarVideos({ onde: eq(videos.autoraId, eu(req).id), usuariaId: eu(req).id, limite: 50 }));
});

videosRouter.post('/', uploadVideo, async (req, res) => {
  const arquivo = req.file;
  if (!arquivo) throw invalido('Envie o arquivo de vídeo no campo "arquivo".');

  try {
    const dados = validar(
      z.object({
        titulo: z.string().trim().min(3, 'Dê um título ao vídeo').max(100),
        descricao: z.string().trim().max(1000).optional(),
        mostrarApelido: z.preprocess(textoParaBool, z.boolean()),
        sensivel: z.preprocess(textoParaBool, z.boolean()),
      }),
      req.body,
    );

    const duracao = await duracaoSegundos(arquivo.path);
    if (duracao && duracao > DURACAO_MAXIMA_SEG) {
      throw invalido('O vídeo pode ter no máximo 5 minutos.', 'VIDEO_LONGO');
    }

    const id = randomUUID();
    const chave = `videos/${id}.${EXTENSOES[arquivo.mimetype] ?? 'mp4'}`;
    await pipeline(createReadStream(arquivo.path), await storage.abrirEscrita(chave));

    const capaChave = `videos/${id}-capa.jpg`;
    await mkdir(dirname(storage.caminhoLocal(capaChave)), { recursive: true });
    const temCapa = await gerarCapa(arquivo.path, storage.caminhoLocal(capaChave));

    await db.insert(videos).values({
      id,
      autoraId: eu(req).id,
      titulo: dados.titulo,
      descricao: dados.descricao,
      mostrarApelido: dados.mostrarApelido,
      sensivel: dados.sensivel,
      status: 'EM_REVISAO',
      arquivoChave: chave,
      capaChave: temCapa ? capaChave : null,
      mimeType: arquivo.mimetype,
      tamanhoBytes: arquivo.size,
      duracaoSeg: duracao,
    });

    res.status(201).json({
      id,
      status: 'EM_REVISAO',
      mensagem: 'Recebemos seu vídeo! Ele aparece no feed assim que a moderação aprovar. Obrigada por inspirar outras mulheres. 💜',
    });
  } finally {
    await rm(arquivo.path, { force: true });
  }
});

videosRouter.delete('/:id', async (req, res) => {
  const id = validar(uuid, req.params.id);
  const [v] = await db.select().from(videos).where(eq(videos.id, id));
  if (!v) throw naoEncontrado('Vídeo');
  if (v.autoraId !== eu(req).id) throw proibido();
  await db.delete(videos).where(eq(videos.id, id));
  await storage.apagar(v.arquivoChave);
  if (v.capaChave) await storage.apagar(v.capaChave);
  res.status(204).end();
});

videosRouter.post('/:id/reacoes', async (req, res) => {
  const id = validar(uuid, req.params.id);
  const { tipo } = validar(z.object({ tipo: z.enum(['APOIO', 'ME_IDENTIFICO', 'FORCA']) }), req.body);
  const [v] = await db.select({ id: videos.id }).from(videos).where(and(eq(videos.id, id), publicado));
  if (!v) throw new HttpError(404, 'Vídeo não encontrado.');

  const usuariaId = eu(req).id;
  const removidas = await db
    .delete(reacoesVideo)
    .where(and(eq(reacoesVideo.videoId, id), eq(reacoesVideo.usuariaId, usuariaId), eq(reacoesVideo.tipo, tipo)))
    .returning();
  if (!removidas.length) await db.insert(reacoesVideo).values({ videoId: id, usuariaId, tipo }).onConflictDoNothing();

  const [atual] = await buscarVideos({ onde: eq(videos.id, id), usuariaId, limite: 1 });
  res.json({ reacoes: atual.reacoes, minhasReacoes: atual.minhasReacoes });
});
