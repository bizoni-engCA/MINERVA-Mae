import { config } from '../../../config';
import type { EstudanteSiga, SigaProvider } from './provider';

/**
 * Simulador do SIGA para o MVP. Os DREs abaixo são fictícios e servem para
 * testar cada situação de matrícula. Com SIGA_MOCK_ACEITAR_QUALQUER_DRE=true,
 * qualquer outro DRE de 9 dígitos é tratado como matrícula ativa.
 */
const BASE: EstudanteSiga[] = [
  { dre: '120000001', situacao: 'ATIVA', nivel: 'GRADUACAO', emailInstitucional: 'estudante.teste1@ufrj.br' },
  { dre: '120000002', situacao: 'ATIVA', nivel: 'GRADUACAO', emailInstitucional: 'estudante.teste2@poli.ufrj.br' },
  { dre: '120000003', situacao: 'ATIVA', nivel: 'POS_GRADUACAO', emailInstitucional: 'estudante.teste3@coppe.ufrj.br' },
  { dre: '120000004', situacao: 'TRANCADA', nivel: 'GRADUACAO', emailInstitucional: 'estudante.teste4@ufrj.br' },
  { dre: '120000005', situacao: 'CANCELADA', nivel: 'GRADUACAO', emailInstitucional: 'estudante.teste5@ufrj.br' },
  { dre: '120000006', situacao: 'CONCLUIDA', nivel: 'GRADUACAO', emailInstitucional: 'estudante.teste6@ufrj.br' },
];

export class MockSigaProvider implements SigaProvider {
  readonly nome = 'simulador-siga';

  async consultarEstudante(dre: string) {
    const achado = BASE.find((e) => e.dre === dre);
    if (achado) return achado;
    if (dre === '999999999') return null; // DRE "inexistente" para testes
    if (config.SIGA_MOCK_ACEITAR_QUALQUER_DRE) {
      return {
        dre,
        situacao: 'ATIVA',
        nivel: 'GRADUACAO',
        emailInstitucional: `estudante.${dre.slice(-4)}@ufrj.br`,
      } satisfies EstudanteSiga;
    }
    return null;
  }
}
