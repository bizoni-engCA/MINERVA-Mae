import { create } from 'zustand';
import type { Sessao, Usuaria } from '@/api/tipos';
import { armazenamento } from '@/lib/armazenamento';

const CHAVE = 'amparo.sessao';

type EstadoSessao = {
  carregada: boolean;
  usuaria: Usuaria | null;
  tokenAcesso: string | null;
  tokenRenovacao: string | null;
  carregar: () => Promise<void>;
  definir: (s: Sessao) => Promise<void>;
  atualizarUsuaria: (u: Usuaria) => Promise<void>;
  limpar: () => Promise<void>;
};

export const useSessao = create<EstadoSessao>((set, get) => ({
  carregada: false,
  usuaria: null,
  tokenAcesso: null,
  tokenRenovacao: null,

  async carregar() {
    const salva = await armazenamento.ler<Sessao>(CHAVE);
    set({ carregada: true, ...(salva ?? {}) });
  },

  async definir(s) {
    set({ usuaria: s.usuaria, tokenAcesso: s.tokenAcesso, tokenRenovacao: s.tokenRenovacao });
    await armazenamento.gravar(CHAVE, s);
  },

  async atualizarUsuaria(u) {
    const { tokenAcesso, tokenRenovacao } = get();
    set({ usuaria: u });
    if (tokenAcesso && tokenRenovacao) await armazenamento.gravar(CHAVE, { usuaria: u, tokenAcesso, tokenRenovacao });
  },

  async limpar() {
    set({ usuaria: null, tokenAcesso: null, tokenRenovacao: null });
    await armazenamento.apagar(CHAVE);
  },
}));

export const ehEquipe = (u: Usuaria | null) => !!u && u.papel !== 'USUARIA';
export const ehModeracao = (u: Usuaria | null) => u?.papel === 'MODERADORA' || u?.papel === 'ADMIN';
export const ehAcolhimento = (u: Usuaria | null) => u?.papel === 'ACOLHIMENTO' || u?.papel === 'ADMIN';
