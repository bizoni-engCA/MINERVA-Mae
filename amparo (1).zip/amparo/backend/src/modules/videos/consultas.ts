import { and, desc, eq, lt, sql, type SQL } from 'drizzle-orm';
import { db, schema } from '../../db';
import { assinarUrlMidia } from '../../lib/crypto';

const { videos, usuarias } = schema;

const contar = (tipo: 'APOIO' | 'ME_IDENTIFICO' | 'FORCA') =>
  sql<number>`(select count(*)::int from reacoes_video r where r.video_id = "videos"."id" and r.tipo = ${tipo})`;

export function urlsVideo(id: string, temCapa: boolean) {
  const v = assinarUrlMidia(`video:${id}`);
  const c = assinarUrlMidia(`capa:${id}`);
  return {
    url: `/api/midia/videos/${id}?exp=${v.exp}&sig=${v.sig}`,
    capaUrl: temCapa ? `/api/midia/capas/${id}?exp=${c.exp}&sig=${c.sig}` : null,
  };
}

export async function buscarVideos(opts: { onde: SQL | undefined; usuariaId: string; limite?: number; cursor?: Date }) {
  const linhas = await db
    .select({
      id: videos.id,
      titulo: videos.titulo,
      descricao: videos.descricao,
      mostrarApelido: videos.mostrarApelido,
      sensivel: videos.sensivel,
      status: videos.status,
      motivoModeracao: videos.motivoModeracao,
      capaChave: videos.capaChave,
      duracaoSeg: videos.duracaoSeg,
      publicadoEm: videos.publicadoEm,
      criadoEm: videos.criadoEm,
      autoraId: videos.autoraId,
      apelido: usuarias.apelido,
      apoio: contar('APOIO'),
      meIdentifico: contar('ME_IDENTIFICO'),
      forca: contar('FORCA'),
      minhasReacoes: sql<string[]>`coalesce((select array_agg(r.tipo::text) from reacoes_video r where r.video_id = "videos"."id" and r.usuaria_id = ${opts.usuariaId}), '{}')`,
    })
    .from(videos)
    .leftJoin(usuarias, eq(usuarias.id, videos.autoraId))
    .where(and(opts.onde, opts.cursor ? lt(sql`coalesce(${videos.publicadoEm}, ${videos.criadoEm})`, opts.cursor) : undefined))
    .orderBy(desc(sql`coalesce(${videos.publicadoEm}, ${videos.criadoEm})`))
    .limit(opts.limite ?? 10);

  return linhas.map((v) => {
    const souAutora = v.autoraId === opts.usuariaId;
    return {
      id: v.id,
      titulo: v.titulo,
      descricao: v.descricao,
      sensivel: v.sensivel,
      duracaoSeg: v.duracaoSeg,
      publicadoEm: v.publicadoEm ?? v.criadoEm,
      autoria: v.mostrarApelido && v.apelido ? { apelido: v.apelido, anonimo: false } : { apelido: 'Anônima', anonimo: true },
      reacoes: { APOIO: v.apoio, ME_IDENTIFICO: v.meIdentifico, FORCA: v.forca },
      minhasReacoes: v.minhasReacoes,
      souAutora,
      ...urlsVideo(v.id, Boolean(v.capaChave)),
      ...(souAutora ? { status: v.status, motivoModeracao: v.motivoModeracao } : {}),
    };
  });
}
