import { beforeAll, describe, expect, it } from 'vitest';
import { api, cadastrar, criarComunidade } from './helpers';

let ana: Awaited<ReturnType<typeof cadastrar>>;
let bia: Awaited<ReturnType<typeof cadastrar>>;
let mod: Awaited<ReturnType<typeof cadastrar>>;
let comunidadeId: string;

beforeAll(async () => {
  ana = await cadastrar('ana.relata');
  bia = await cadastrar('bia.apoia');
  mod = await cadastrar('mod.teste', 'MODERADORA');
  comunidadeId = (await criarComunidade('rodas')).id;
});

describe('subcomunidades e relatos', () => {
  it('publica relato sem nomes e retém relato com nome para revisão', async () => {
    const ok = await api().post('/api/posts').set(ana.auth).send({
      comunidadeId,
      titulo: 'Aconteceu no laboratório',
      corpo: 'Um colega fez comentários constrangedores sobre mim durante a prática e ninguém interveio.',
      anonimo: true,
    });
    expect(ok.status).toBe(201);
    expect(ok.body.status).toBe('PUBLICADO');

    const comNome = await api().post('/api/posts').set(ana.auth).send({
      comunidadeId,
      titulo: 'Sobre o monitor',
      corpo: 'O monitor Rafael Souza me mandou mensagens de madrugada várias vezes, isso precisa parar.',
      detalhesModeracao: 'Monitor da disciplina X, turma da manhã.',
    });
    expect(comNome.body.status).toBe('EM_REVISAO');
    expect(comNome.body.alertas.length).toBeGreaterThan(0);

    // Outra usuária não vê o relato retido
    expect((await api().get(`/api/posts/${comNome.body.id}`).set(bia.auth)).status).toBe(404);

    // Feed mostra só o publicado, com autoria anônima
    const feed = await api().get(`/api/comunidades/${comunidadeId}/posts`).set(bia.auth);
    expect(feed.body.itens).toHaveLength(1);
    expect(feed.body.itens[0].autoria).toEqual({ apelido: 'Anônima', anonimo: true });
    expect(feed.body.itens[0].status).toBeUndefined(); // dados de moderação só para a autora

    // Moderação vê os detalhes reservados (decifrados) e aprova
    const fila = await api().get('/api/equipe/moderacao/posts?fila=revisao').set(mod.auth);
    const item = fila.body.find((p: { id: string }) => p.id === comNome.body.id);
    expect(item.detalhesModeracao).toBe('Monitor da disciplina X, turma da manhã.');
    expect((await api().post(`/api/equipe/moderacao/posts/${comNome.body.id}/decisao`).set(mod.auth).send({ acao: 'REJEITAR' })).status).toBe(400);
    const rej = await api()
      .post(`/api/equipe/moderacao/posts/${comNome.body.id}/decisao`)
      .set(mod.auth)
      .send({ acao: 'REJEITAR', motivo: 'Retire o nome do texto público e use o campo reservado.' });
    expect(rej.body.status).toBe('REJEITADO');

    const meus = await api().get('/api/posts/meus').set(ana.auth);
    const meu = meus.body.find((p: { id: string }) => p.id === comNome.body.id);
    expect(meu.motivoModeracao).toContain('Retire o nome');
  });

  it('relato só para a moderação nunca é publicado e recebe resposta', async () => {
    const r = await api().post('/api/posts').set(ana.auth).send({
      comunidadeId,
      titulo: 'Preciso de ajuda',
      corpo: 'Quero que só a moderação saiba o que está acontecendo no meu alojamento.',
      visibilidade: 'SO_MODERACAO',
    });
    expect(r.body.status).toBe('EM_REVISAO');
    const aprovar = await api().post(`/api/equipe/moderacao/posts/${r.body.id}/decisao`).set(mod.auth).send({ acao: 'APROVAR' });
    expect(aprovar.status).toBe(400);
    await api().post(`/api/equipe/moderacao/posts/${r.body.id}/responder`).set(mod.auth).send({ resposta: 'Recebemos. Veja os contatos da Ouvidoria da Mulher.' });
    const meu = (await api().get(`/api/posts/${r.body.id}`).set(ana.auth)).body;
    expect(meu.respostaModeracao).toContain('Ouvidoria');
    expect((await api().get(`/api/posts/${r.body.id}`).set(bia.auth)).status).toBe(404);
  });

  it('comentários, reações e sinalizações', async () => {
    const p = await api().post('/api/posts').set(ana.auth).send({
      comunidadeId,
      titulo: 'Rede de apoio',
      corpo: 'Hoje consegui contar para minha família o que aconteceu. Foi difícil mas me senti acolhida.',
    });
    const id = p.body.id;

    const c = await api().post(`/api/posts/${id}/comentarios`).set(bia.auth).send({ corpo: 'Que orgulho de você! 💜' });
    expect(c.body.status).toBe('PUBLICADO');
    const lista = await api().get(`/api/posts/${id}/comentarios`).set(ana.auth);
    expect(lista.body[0].autoria.apelido).toBe('bia.apoia');

    const r1 = await api().post(`/api/posts/${id}/reacoes`).set(bia.auth).send({ tipo: 'FORCA' });
    expect(r1.body.reacoes.FORCA).toBe(1);
    expect(r1.body.minhasReacoes).toEqual(['FORCA']);
    const r2 = await api().post(`/api/posts/${id}/reacoes`).set(bia.auth).send({ tipo: 'FORCA' });
    expect(r2.body.reacoes.FORCA).toBe(0); // alterna

    // 3 sinalizações tiram do ar
    const s1 = await cadastrar('sinaliza.1');
    const s2 = await cadastrar('sinaliza.2');
    for (const u of [bia, s1, s2]) {
      await api().post('/api/sinalizacoes').set(u.auth).send({ alvoTipo: 'POST', alvoId: id, motivo: 'SPAM' });
    }
    expect((await api().get(`/api/posts/${id}`).set(bia.auth)).status).toBe(404);
    const fila = await api().get('/api/equipe/moderacao/sinalizacoes').set(mod.auth);
    expect(fila.body.find((g: { alvoId: string }) => g.alvoId === id).total).toBe(3);
    await api().post(`/api/equipe/moderacao/sinalizacoes/${id}/resolver`).set(mod.auth).send({ acao: 'MANTER' });
    expect((await api().get(`/api/posts/${id}`).set(bia.auth)).status).toBe(200);
  });

  it('usuária comum não acessa a área da equipe', async () => {
    expect((await api().get('/api/equipe/resumo').set(ana.auth)).status).toBe(403);
    expect((await api().get('/api/equipe/resumo').set(mod.auth)).status).toBe(200);
  });
});
