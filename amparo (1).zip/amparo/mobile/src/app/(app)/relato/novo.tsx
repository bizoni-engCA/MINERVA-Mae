import { useEffect, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { router, useLocalSearchParams } from 'expo-router';
import { useQueryClient } from '@tanstack/react-query';
import { useComunidades, verificarTexto } from '@/api/consultas';
import { api, mensagemDeErro } from '@/api/cliente';
import type { AlertaIdentificacao } from '@/api/tipos';
import { AlertasIdentificacao } from '@/components/AlertasIdentificacao';
import { Aviso, Bloco, Botao, Campo, Chip, Espaco, Interruptor, Texto, Tela, type NomeIcone } from '@/components/ui';
import { espaco } from '@/theme';

export default function NovoRelato() {
  const params = useLocalSearchParams<{ comunidadeId?: string }>();
  const qc = useQueryClient();
  const comunidades = useComunidades();
  const [comunidadeId, setComunidadeId] = useState(params.comunidadeId ?? '');
  const [titulo, setTitulo] = useState('');
  const [corpo, setCorpo] = useState('');
  const [detalhes, setDetalhes] = useState('');
  const [anonimo, setAnonimo] = useState(true);
  const [sensivel, setSensivel] = useState(false);
  const [soModeracao, setSoModeracao] = useState(false);
  const [alertas, setAlertas] = useState<AlertaIdentificacao[]>([]);
  const [enviando, setEnviando] = useState(false);

  // Confere o texto enquanto a pessoa escreve (o mesmo filtro do servidor).
  useEffect(() => {
    const texto = `${titulo}\n${corpo}`.trim();
    if (texto.length < 10 || soModeracao) return setAlertas([]);
    const t = setTimeout(() => {
      verificarTexto(texto)
        .then((r) => setAlertas(r.alertas))
        .catch(() => {});
    }, 700);
    return () => clearTimeout(t);
  }, [titulo, corpo, soModeracao]);

  const pronto = comunidadeId && titulo.trim().length >= 5 && corpo.trim().length >= 20;

  async function enviar() {
    setEnviando(true);
    try {
      const r = await api<{ id: string; status: string; mensagem: string }>('/api/posts', {
        corpo: {
          comunidadeId,
          titulo: titulo.trim(),
          corpo: corpo.trim(),
          anonimo,
          sensivel,
          visibilidade: soModeracao ? 'SO_MODERACAO' : 'PUBLICO',
          detalhesModeracao: detalhes.trim() || undefined,
        },
      });
      qc.invalidateQueries({ queryKey: ['feed'] });
      qc.invalidateQueries({ queryKey: ['posts'] });
      qc.invalidateQueries({ queryKey: ['meus-posts'] });
      qc.invalidateQueries({ queryKey: ['comunidades'] });
      Alert.alert(r.status === 'PUBLICADO' ? 'Relato publicado' : 'Relato enviado', r.mensagem, [
        { text: 'Ver relato', onPress: () => router.replace(`/relato/${r.id}`) },
      ]);
    } catch (e) {
      Alert.alert('Não foi possível enviar', mensagemDeErro(e));
    } finally {
      setEnviando(false);
    }
  }

  return (
    <Tela rodape={<Botao titulo={soModeracao ? 'Enviar para a moderação' : 'Publicar relato'} onPress={enviar} carregando={enviando} desativado={!pronto} />}>
      <Texto negrito>Em qual subcomunidade?</Texto>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: espaco.s, paddingVertical: espaco.m }}>
        {(comunidades.data ?? []).map((c) => (
          <Chip key={c.id} rotulo={c.nome} icone={c.icone as NomeIcone} cor={c.cor} ativo={c.id === comunidadeId} onPress={() => setComunidadeId(c.id)} />
        ))}
      </ScrollView>

      <Aviso tom="info" titulo="Antes de escrever">
        Não use nomes, apelidos, cargos com nome, disciplinas ou perfis de quem cometeu a violência no texto público. Se quiser que a moderação
        saiba quem foi, use o campo “Só para a moderação” lá embaixo.
      </Aviso>
      <Espaco />

      <Campo rotulo="Título" value={titulo} onChangeText={setTitulo} contador={140} placeholder="Resuma em uma frase" />
      <Campo
        rotulo="Seu relato"
        value={corpo}
        onChangeText={setCorpo}
        multiline
        contador={10000}
        placeholder="Conte no seu ritmo. Você pode falar do que aconteceu, de como se sentiu ou do que precisa agora."
        style={{ minHeight: 200 }}
      />

      <AlertasIdentificacao alertas={alertas} />
      {alertas.length ? <Espaco /> : null}

      <Campo
        rotulo="Só para a moderação (opcional)"
        value={detalhes}
        onChangeText={setDetalhes}
        multiline
        contador={5000}
        placeholder="Nome, cargo, disciplina, local… Ninguém além da moderação vê este campo."
        ajuda="Fica criptografado. Ajuda a moderação a identificar casos repetidos e a orientar melhor."
        style={{ minHeight: 90 }}
      />

      <Bloco>
        <Interruptor titulo="Publicar como anônima" descricao="Seu apelido não aparece para ninguém." valor={anonimo} aoMudar={setAnonimo} />
        <Interruptor
          titulo="Conteúdo sensível"
          descricao="O relato aparece borrado até a pessoa escolher ler. Use para descrições de violência."
          valor={sensivel}
          aoMudar={setSensivel}
        />
        <Interruptor
          titulo="Enviar só para a moderação"
          descricao="Não aparece na subcomunidade. A moderação lê e responde para você."
          valor={soModeracao}
          aoMudar={setSoModeracao}
        />
      </Bloco>
      <View style={{ height: espaco.l }} />
    </Tela>
  );
}
