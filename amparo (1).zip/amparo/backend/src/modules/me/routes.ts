import { Router } from 'express';
import argon2 from 'argon2';
import { and, eq, inArray, isNull, sql } from 'drizzle-orm';
import { db, schema } from '../../db';
import { HttpError } from '../../lib/errors';
import { logger } from '../../lib/logger';
import { storage } from '../../lib/storage';
import { validar, z } from '../../lib/validar';
import { eu, exigirLogin } from '../../middleware/auth';
import { apelidoSchema, senhaSchema } from '../auth/routes';
import { perfilPublico } from './perfil';

export const meRouter = Router();
meRouter.use(exigirLogin);

meRouter.get('/', (req, res) => {
  res.json(perfilPublico(eu(req)));
});

meRouter.patch('/', async (req, res) => {
  const { apelido } = validar(z.object({ apelido: apelidoSchema }), req.body);
  const [outra] = await db
    .select({ id: schema.usuarias.id })
    .from(schema.usuarias)
    .where(sql`lower(${schema.usuarias.apelido}) = lower(${apelido})`);
  if (outra && outra.id !== eu(req).id) throw new HttpError(409, 'Esse apelido já está em uso.', 'APELIDO_EM_USO');
  const [atualizada] = await db
    .update(schema.usuarias)
    .set({ apelido })
    .where(eq(schema.usuarias.id, eu(req).id))
    .returning();
  res.json(perfilPublico(atualizada));
});

meRouter.post('/senha', async (req, res) => {
  const { senhaAtual, novaSenha } = validar(z.object({ senhaAtual: z.string(), novaSenha: senhaSchema }), req.body);
  if (!(await argon2.verify(eu(req).senhaHash, senhaAtual))) {
    throw new HttpError(400, 'Senha atual incorreta.', 'SENHA_INCORRETA');
  }
  await db
    .update(schema.usuarias)
    .set({ senhaHash: await argon2.hash(novaSenha, { type: argon2.argon2id }) })
    .where(eq(schema.usuarias.id, eu(req).id));
  res.status(204).end();
});

/** Encerra todas as sessões (ex.: perdeu o celular). */
meRouter.post('/encerrar-sessoes', async (req, res) => {
  await db
    .update(schema.usuarias)
    .set({ versaoToken: sql`${schema.usuarias.versaoToken} + 1` })
    .where(eq(schema.usuarias.id, eu(req).id));
  await db
    .update(schema.refreshTokens)
    .set({ revogadoEm: new Date() })
    .where(and(eq(schema.refreshTokens.usuariaId, eu(req).id), isNull(schema.refreshTokens.revogadoEm)));
  res.status(204).end();
});

/** Exclusão definitiva da conta e de todos os dados (LGPD, art. 18). */
meRouter.delete('/', async (req, res) => {
  const { senha } = validar(z.object({ senha: z.string() }), req.body);
  const usuaria = eu(req);
  if (!(await argon2.verify(usuaria.senhaHash, senha))) {
    throw new HttpError(400, 'Senha incorreta.', 'SENHA_INCORRETA');
  }

  const casos = await db.select({ id: schema.casos.id }).from(schema.casos).where(eq(schema.casos.donaId, usuaria.id));
  const arquivos = [
    ...(casos.length
      ? await db
          .select({ chave: schema.provas.arquivoChave })
          .from(schema.provas)
          .where(inArray(schema.provas.casoId, casos.map((c) => c.id)))
      : []),
    ...(await db
      .select({ chave: schema.videos.arquivoChave, capa: schema.videos.capaChave })
      .from(schema.videos)
      .where(eq(schema.videos.autoraId, usuaria.id))
      .then((vs) => vs.flatMap((v) => [{ chave: v.chave }, ...(v.capa ? [{ chave: v.capa }] : [])]))),
  ];

  // Apaga a conta (cascata remove relatos, comentários, casos, provas, vídeos e sessões).
  await db.delete(schema.usuarias).where(eq(schema.usuarias.id, usuaria.id));

  for (const { chave } of arquivos) {
    await storage.apagar(chave).catch((err) => logger.error({ err }, 'Falha ao apagar arquivo de conta excluída'));
  }
  res.status(204).end();
});
