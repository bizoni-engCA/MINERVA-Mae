import { useEffect, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { Link, router } from 'expo-router';
import { api, mensagemDeErro } from '@/api/cliente';
import type { Sessao } from '@/api/tipos';
import { Aviso, Botao, Campo, Espaco, Icone, Texto, Titulo, Tela } from '@/components/ui';
import { useFluxo } from '@/store/fluxo';
import { useSessao } from '@/store/sessao';
import { cores, espaco, raio } from '@/theme';

export default function Cadastro() {
  const token = useFluxo((s) => s.tokenVerificacao);
  const definirSessao = useSessao((s) => s.definir);
  const [apelido, setApelido] = useState('');
  const [disponivel, setDisponivel] = useState<{ ok: boolean; motivo?: string } | null>(null);
  const [senha, setSenha] = useState('');
  const [confirmacao, setConfirmacao] = useState('');
  const [autodeclaracao, setAutodeclaracao] = useState(false);
  const [termos, setTermos] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const [carregando, setCarregando] = useState(false);

  useEffect(() => {
    if (!token) router.replace('/verificar?finalidade=CADASTRO');
  }, [token]);

  useEffect(() => {
    setDisponivel(null);
    if (apelido.trim().length < 3) return;
    const t = setTimeout(async () => {
      try {
        const r = await api<{ disponivel: boolean; motivo?: string }>(`/api/auth/apelido-disponivel?apelido=${encodeURIComponent(apelido.trim())}`, { semAuth: true });
        setDisponivel({ ok: r.disponivel, motivo: r.motivo });
      } catch {
        /* sem conexão: o cadastro vai validar */
      }
    }, 450);
    return () => clearTimeout(t);
  }, [apelido]);

  const senhasDiferentes = confirmacao.length > 0 && senha !== confirmacao;
  const pronto = apelido.trim().length >= 3 && senha.length >= 8 && senha === confirmacao && autodeclaracao && termos && disponivel?.ok !== false;

  async function criar() {
    setErro(null);
    setCarregando(true);
    try {
      const s = await api<Sessao>('/api/auth/cadastro', {
        corpo: { tokenVerificacao: token, apelido: apelido.trim(), senha, autodeclaracao, aceiteTermos: termos },
        semAuth: true,
      });
      useFluxo.getState().definir(null);
      await definirSessao(s);
    } catch (e) {
      setErro(mensagemDeErro(e));
    } finally {
      setCarregando(false);
    }
  }

  return (
    <Tela>
      <Titulo>Quase lá</Titulo>
      <Texto fraco style={{ marginTop: espaco.s, marginBottom: espaco.xl }}>
        Escolha um apelido — é só ele que as outras pessoas veem. Evite usar seu nome ou algo que identifique você.
      </Texto>

      <Campo
        rotulo="Apelido"
        value={apelido}
        onChangeText={setApelido}
        autoCapitalize="none"
        autoCorrect={false}
        placeholder="ex.: girassol.azul"
        erro={disponivel && !disponivel.ok ? (disponivel.motivo ?? 'Esse apelido já está em uso') : null}
        ajuda={disponivel?.ok ? 'Disponível!' : 'De 3 a 24 caracteres: letras, números, ponto, hífen ou sublinhado.'}
      />
      <Campo rotulo="Senha" value={senha} onChangeText={setSenha} secureTextEntry autoCapitalize="none" textContentType="newPassword" ajuda="Pelo menos 8 caracteres." />
      <Campo
        rotulo="Repita a senha"
        value={confirmacao}
        onChangeText={setConfirmacao}
        secureTextEntry
        autoCapitalize="none"
        erro={senhasDiferentes ? 'As senhas não são iguais.' : null}
      />

      <Marcar marcado={autodeclaracao} aoMudar={setAutodeclaracao}>
        Declaro que sou mulher (cis ou trans) ou pessoa não-binária.
      </Marcar>
      <Marcar marcado={termos} aoMudar={setTermos}>
        Li e aceito os{' '}
        <Link href="/termos" style={{ color: cores.lilas, textDecorationLine: 'underline' }}>
          termos e a política de privacidade
        </Link>
        , incluindo as regras de convivência.
      </Marcar>

      {erro ? (
        <>
          <Espaco altura={espaco.m} />
          <Aviso tom="perigo">{erro}</Aviso>
        </>
      ) : null}
      <Espaco altura={espaco.xl} />
      <Botao titulo="Criar conta" onPress={criar} carregando={carregando} desativado={!pronto} />
    </Tela>
  );
}

function Marcar({ marcado, aoMudar, children }: { marcado: boolean; aoMudar: (v: boolean) => void; children: React.ReactNode }) {
  return (
    <Pressable onPress={() => aoMudar(!marcado)} style={estilos.marcar} accessibilityRole="checkbox" accessibilityState={{ checked: marcado }}>
      <View style={[estilos.caixa, marcado && { backgroundColor: cores.lilas, borderColor: cores.lilas }]}>
        {marcado ? <Icone nome="checkmark" cor="#FFF" tamanho={16} /> : null}
      </View>
      <Texto style={{ flex: 1 }}>{children}</Texto>
    </Pressable>
  );
}

const estilos = StyleSheet.create({
  marcar: { flexDirection: 'row', gap: espaco.m, alignItems: 'flex-start', paddingVertical: espaco.s },
  caixa: {
    width: 24,
    height: 24,
    borderRadius: raio.pequeno - 2,
    borderWidth: 2,
    borderColor: cores.linha,
    backgroundColor: cores.superficie,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 1,
  },
});
