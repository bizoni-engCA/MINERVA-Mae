import { Router } from 'express';
import { and, eq, sql } from 'drizzle-orm';
import { db, schema } from '../../db';
import { naoEncontrado } from '../../lib/errors';
import { uuid, validar, z } from '../../lib/validar';
import { eu, exigirLogin } from '../../middleware/auth';
import { LIMITE_SINALIZACOES } from './consultas';

/** Usuárias sinalizam conteúdo problemático para a moderação. */
export const sinalizacoesRouter = Router();
sinalizacoesRouter.use(exigirLogin);

const { sinalizacoes, posts, comentarios, videos } = schema;

sinalizacoesRouter.post('/', async (req, res) => {
  const dados = validar(
    z.object({
      alvoTipo: z.enum(['POST', 'COMENTARIO', 'VIDEO']),
      alvoId: uuid,
      motivo: z.enum(['IDENTIFICA_PESSOA', 'ASSEDIO_OU_ATAQUE', 'DISCURSO_DE_ODIO', 'CONTEUDO_FALSO', 'SPAM', 'OUTRO']),
      detalhes: z.string().trim().max(1000).optional(),
    }),
    req.body,
  );

  const tabela = { POST: posts, COMENTARIO: comentarios, VIDEO: videos }[dados.alvoTipo];
  const [alvo] = await db.select({ id: tabela.id }).from(tabela).where(eq(tabela.id, dados.alvoId));
  if (!alvo) throw naoEncontrado('Conteúdo');

  const [repetida] = await db
    .select({ id: sinalizacoes.id })
    .from(sinalizacoes)
    .where(
      and(
        eq(sinalizacoes.alvoId, dados.alvoId),
        eq(sinalizacoes.autoraId, eu(req).id),
        eq(sinalizacoes.status, 'ABERTA'),
      ),
    );
  if (!repetida) await db.insert(sinalizacoes).values({ ...dados, autoraId: eu(req).id });

  const [{ abertas }] = await db
    .select({ abertas: sql<number>`count(*)::int` })
    .from(sinalizacoes)
    .where(and(eq(sinalizacoes.alvoId, dados.alvoId), eq(sinalizacoes.status, 'ABERTA')));

  // Muitas sinalizações → tira do ar até a moderação revisar.
  if (abertas >= LIMITE_SINALIZACOES) {
    await db
      .update(tabela)
      .set({ status: 'EM_REVISAO' })
      .where(and(eq(tabela.id, dados.alvoId), eq(tabela.status, 'PUBLICADO')));
  }

  res.status(201).json({ mensagem: 'Obrigada. A moderação vai analisar.' });
});
