import 'dotenv/config';
import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import { sql } from 'drizzle-orm';
import pg from 'pg';

/** Recria o banco de testes do zero antes da suíte. */
export default async function () {
  const url = process.env.TEST_DATABASE_URL ?? 'postgres://amparo:amparo@localhost:5432/amparo_test';
  await criarBancoSeFaltar(url);
  const pool = new pg.Pool({ connectionString: url });
  const db = drizzle(pool);
  await db.execute(sql`drop schema if exists public cascade; create schema public; drop schema if exists drizzle cascade;`);
  await migrate(db, { migrationsFolder: './drizzle' });
  await pool.end();
}

async function criarBancoSeFaltar(url: string) {
  const alvo = new URL(url);
  const nome = alvo.pathname.slice(1);
  alvo.pathname = '/postgres';
  const admin = new pg.Client({ connectionString: alvo.toString() });
  await admin.connect();
  const { rowCount } = await admin.query('select 1 from pg_database where datname = $1', [nome]);
  if (!rowCount) await admin.query(`create database "${nome.replace(/"/g, '')}"`);
  await admin.end();
}
