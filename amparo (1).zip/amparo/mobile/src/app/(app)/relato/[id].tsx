import { useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQueryClient } from '@tanstack/react-query';
import { sinalizar, useComentarios, usePost, useReagirPost } from '@/api/consultas';
import { api, mensagemDeErro } from '@/api/cliente';
import type { Comentario } from '@/api/tipos';
import { ConteudoSensivel } from '@/components/ConteudoSensivel';
import { Opcoes } from '@/components/Opcoes';
import { Reacoes } from '@/components/Reacoes';
import { SaidaRapida } from '@/components/SaidaRapida';
import { Aviso, BotaoIcone, Carregando, Divisor, ErroTela, Etiqueta, Icone, Linha, Texto, Titulo, type NomeIcone } from '@/components/ui';
import { tempoRelativo } from '@/lib/formatar';
import { MOTIVOS_SINALIZACAO, STATUS_CONTEUDO } from '@/lib/rotulos';
import { cores, espaco, fontes, raio } from '@/theme';

export default function Relato() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const qc = useQueryClient();
  const post = usePost(id);
  const comentarios = useComentarios(id);
  const reagir = useReagirPost(id);
  const [texto, setTexto] = useState('');
  const [anonimo, setAnonimo] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const [menu, setMenu] = useState<null | { tipo: 'POST' | 'COMENTARIO'; id: string; meu: boolean }>(null);
  const [motivos, setMotivos] = useState<null | { tipo: 'POST' | 'COMENTARIO'; id: string }>(null);

  if (post.isLoading) return <Carregando />;
  if (post.isError || !post.data) return <ErroTela mensagem={mensagemDeErro(post.error)} tentarDeNovo={post.refetch} />;
  const p = post.data;
  const publicado = !p.status || (p.status === 'PUBLICADO' && p.visibilidade !== 'SO_MODERACAO');

  async function comentar() {
    setEnviando(true);
    try {
      const r = await api<{ status: string; mensagem: string }>(`/api/posts/${id}/comentarios`, { corpo: { corpo: texto.trim(), anonimo } });
      setTexto('');
      if (r.status !== 'PUBLICADO') Alert.alert('Comentário em revisão', r.mensagem);
      qc.invalidateQueries({ queryKey: ['comentarios', id] });
      qc.invalidateQueries({ queryKey: ['post', id] });
    } catch (e) {
      Alert.alert('Não foi possível comentar', mensagemDeErro(e));
    } finally {
      setEnviando(false);
    }
  }

  async function apagar(tipo: 'POST' | 'COMENTARIO', alvo: string) {
    Alert.alert(tipo === 'POST' ? 'Apagar relato?' : 'Apagar comentário?', 'Isso não pode ser desfeito.', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Apagar',
        style: 'destructive',
        onPress: async () => {
          try {
            await api(tipo === 'POST' ? `/api/posts/${alvo}` : `/api/posts/comentarios/${alvo}`, { metodo: 'DELETE' });
            qc.invalidateQueries({ queryKey: ['feed'] });
            qc.invalidateQueries({ queryKey: ['meus-posts'] });
            if (tipo === 'POST') router.back();
            else qc.invalidateQueries({ queryKey: ['comentarios', id] });
          } catch (e) {
            Alert.alert('Erro', mensagemDeErro(e));
          }
        },
      },
    ]);
  }

  const status = p.status ? STATUS_CONTEUDO[p.status] : null;

  const cabecalho = (
    <View>
      <Linha espacamento={6}>
        <Icone nome={p.comunidade.icone as NomeIcone} tamanho={15} cor={p.comunidade.cor} />
        <Text style={[estilos.meta, { color: p.comunidade.cor }]} onPress={() => router.push(`/comunidade/${p.comunidade.slug}`)}>
          {p.comunidade.nome}
        </Text>
      </Linha>
      {status && p.souAutora && !publicado ? (
        <View style={{ marginTop: espaco.m, gap: espaco.s }}>
          <Etiqueta texto={p.visibilidade === 'SO_MODERACAO' ? 'Só para a moderação' : status.rotulo} cor={status.cor} fundo={status.fundo} />
          {p.visibilidade === 'SO_MODERACAO' ? (
            <Aviso tom="info">Só a moderação pode ler este relato. A resposta aparece aqui.</Aviso>
          ) : p.status === 'EM_REVISAO' ? (
            <Aviso tom="cuidado">A moderação está revisando este relato. Ele aparece para as outras pessoas depois de aprovado.</Aviso>
          ) : p.motivoModeracao ? (
            <Aviso tom="perigo" titulo="Motivo informado pela moderação">
              {p.motivoModeracao}
            </Aviso>
          ) : null}
        </View>
      ) : null}
      {p.respostaModeracao ? (
        <View style={{ marginTop: espaco.m }}>
          <Aviso tom="sucesso" titulo="Resposta da moderação">
            {p.respostaModeracao}
          </Aviso>
        </View>
      ) : null}

      <ConteudoSensivel sensivel={p.sensivel}>
        <Titulo nivel={2} style={{ marginTop: espaco.m }}>
          {p.titulo}
        </Titulo>
        <Texto style={{ marginTop: espaco.m, fontSize: 17, lineHeight: 27 }}>{p.corpo}</Texto>
      </ConteudoSensivel>

      <Linha estilo={{ justifyContent: 'space-between', marginTop: espaco.l }}>
        <Texto pequeno fraco>
          {p.autoria.apelido} · {tempoRelativo(p.publicadoEm)}
        </Texto>
        <BotaoIcone icone="ellipsis-horizontal" rotulo="Mais opções" onPress={() => setMenu({ tipo: 'POST', id: p.id, meu: p.souAutora })} cor={cores.nevoa} />
      </Linha>

      {publicado ? (
        <View style={{ marginTop: espaco.m }}>
          <Reacoes reacoes={p.reacoes} minhas={p.minhasReacoes} aoReagir={(t) => reagir.mutate(t)} />
        </View>
      ) : null}
      <Divisor />
      <Titulo nivel={3}>{comentarios.data?.length ? `Comentários (${comentarios.data.length})` : 'Comentários'}</Titulo>
    </View>
  );

  return (
    <>
      <Stack.Screen options={{ title: '', headerRight: () => <SaidaRapida /> }} />
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: cores.papel }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={90}>
        <FlatList
          data={comentarios.data ?? []}
          keyExtractor={(c) => c.id}
          ListHeaderComponent={cabecalho}
          contentContainerStyle={{ padding: espaco.l, paddingBottom: espaco.xxl }}
          renderItem={({ item }) => <ItemComentario c={item} aoMenu={() => setMenu({ tipo: 'COMENTARIO', id: item.id, meu: item.souAutora })} />}
          ListEmptyComponent={
            <Texto fraco style={{ marginTop: espaco.m }}>
              {publicado ? 'Seja a primeira a deixar uma palavra de apoio.' : 'Comentários ficam disponíveis quando o relato é publicado.'}
            </Texto>
          }
        />
        {publicado ? (
          <View style={[estilos.compositor, { paddingBottom: insets.bottom + espaco.s }]}>
            <TextInput
              value={texto}
              onChangeText={setTexto}
              placeholder="Escreva com acolhimento…"
              placeholderTextColor={cores.nevoa}
              multiline
              maxLength={3000}
              style={estilos.entrada}
              accessibilityLabel="Escrever comentário"
            />
            <Linha estilo={{ justifyContent: 'space-between', marginTop: espaco.s }}>
              <Linha espacamento={6}>
                <Switch value={anonimo} onValueChange={setAnonimo} trackColor={{ true: cores.lilas, false: cores.linha }} thumbColor="#FFF" />
                <Texto pequeno>Comentar como anônima</Texto>
              </Linha>
              <BotaoIcone icone="paper-plane" rotulo="Enviar comentário" cor={texto.trim() && !enviando ? cores.lilas : cores.nevoa} onPress={() => texto.trim() && !enviando && comentar()} />
            </Linha>
          </View>
        ) : null}
      </KeyboardAvoidingView>

      <Opcoes
        visivel={!!menu}
        aoFechar={() => setMenu(null)}
        opcoes={
          menu?.meu
            ? [{ rotulo: menu.tipo === 'POST' ? 'Apagar relato' : 'Apagar comentário', icone: 'trash-outline', perigo: true, onPress: () => apagar(menu.tipo, menu.id) }]
            : menu
              ? [{ rotulo: 'Sinalizar para a moderação', icone: 'flag-outline', onPress: () => setMotivos({ tipo: menu.tipo, id: menu.id }) }]
              : []
        }
      />
      <Opcoes
        visivel={!!motivos}
        titulo="Qual é o problema?"
        aoFechar={() => setMotivos(null)}
        opcoes={Object.entries(MOTIVOS_SINALIZACAO).map(([motivo, rotulo]) => ({
          rotulo,
          onPress: async () => {
            if (!motivos) return;
            try {
              const r = await sinalizar(motivos.tipo, motivos.id, motivo);
              Alert.alert('Sinalização enviada', r.mensagem);
            } catch (e) {
              Alert.alert('Erro', mensagemDeErro(e));
            }
          },
        }))}
      />
    </>
  );
}

function ItemComentario({ c, aoMenu }: { c: Comentario; aoMenu: () => void }) {
  const status = c.status && c.status !== 'PUBLICADO' ? STATUS_CONTEUDO[c.status] : null;
  return (
    <View style={estilos.comentario}>
      <Linha estilo={{ justifyContent: 'space-between' }}>
        <Linha espacamento={6}>
          <Text style={estilos.autora}>{c.autoria.apelido}</Text>
          {c.autoraDoRelato ? <Etiqueta texto="autora" cor={cores.lilas} fundo={cores.lilasClaro} /> : null}
          <Text style={estilos.meta}>{tempoRelativo(c.criadoEm)}</Text>
        </Linha>
        <BotaoIcone icone="ellipsis-horizontal" rotulo="Mais opções" onPress={aoMenu} cor={cores.nevoa} tamanho={18} />
      </Linha>
      {status ? <Etiqueta texto={status.rotulo} cor={status.cor} fundo={status.fundo} /> : null}
      <Texto style={{ marginTop: 4 }}>{c.corpo}</Texto>
      {c.motivoModeracao ? (
        <Texto pequeno cor={cores.sinal}>
          Moderação: {c.motivoModeracao}
        </Texto>
      ) : null}
    </View>
  );
}

const estilos = StyleSheet.create({
  meta: { fontFamily: fontes.textoMedio, fontSize: 13, color: cores.nevoa },
  autora: { fontFamily: fontes.textoNegrito, fontSize: 14, color: cores.tinta },
  comentario: { paddingVertical: espaco.m, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: cores.linha },
  compositor: { backgroundColor: cores.superficie, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: cores.linha, paddingHorizontal: espaco.l, paddingTop: espaco.m },
  entrada: {
    minHeight: 44,
    maxHeight: 120,
    backgroundColor: cores.papel,
    borderRadius: raio.medio,
    paddingHorizontal: espaco.m,
    paddingVertical: 10,
    fontFamily: fontes.texto,
    fontSize: 16,
    color: cores.tinta,
  },
});
