import { Fragment } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { cores, espaco, fontes, tamanhos } from '@/theme';

/** Renderizador mínimo para os guias: ## títulos, listas "- ", > citações, **negrito** e `código`. */
export function Markdown({ texto }: { texto: string }) {
  const blocos = texto.trim().split(/\n{2,}/);
  return (
    <View style={{ gap: espaco.m }}>
      {blocos.map((bloco, i) => {
        if (bloco.startsWith('## ')) {
          return (
            <Text key={i} style={estilos.h2} accessibilityRole="header">
              {bloco.slice(3)}
            </Text>
          );
        }
        if (bloco.startsWith('> ')) {
          return (
            <View key={i} style={estilos.citacao}>
              <Text style={estilos.p}>{inline(bloco.replace(/^> /gm, ''))}</Text>
            </View>
          );
        }
        const linhas = bloco.split('\n');
        if (linhas.every((l) => l.startsWith('- ')) || (linhas[0].startsWith('## ') === false && linhas.some((l) => l.startsWith('- ')))) {
          return (
            <View key={i} style={{ gap: 6 }}>
              {linhas.map((l, j) =>
                l.startsWith('- ') ? (
                  <View key={j} style={estilos.item}>
                    <View style={estilos.marcador} />
                    <Text style={[estilos.p, { flex: 1 }]}>{inline(l.slice(2))}</Text>
                  </View>
                ) : l.startsWith('## ') ? (
                  <Text key={j} style={estilos.h2}>
                    {l.slice(3)}
                  </Text>
                ) : (
                  <Text key={j} style={estilos.p}>
                    {inline(l)}
                  </Text>
                ),
              )}
            </View>
          );
        }
        if (linhas[0].startsWith('## ')) {
          return (
            <View key={i} style={{ gap: espaco.s }}>
              <Text style={estilos.h2} accessibilityRole="header">
                {linhas[0].slice(3)}
              </Text>
              <Text style={estilos.p}>{inline(linhas.slice(1).join('\n'))}</Text>
            </View>
          );
        }
        return (
          <Text key={i} style={estilos.p}>
            {inline(bloco)}
          </Text>
        );
      })}
    </View>
  );
}

function inline(texto: string) {
  const partes = texto.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return partes.map((p, i) =>
    p.startsWith('**') ? (
      <Text key={i} style={{ fontFamily: fontes.textoNegrito }}>
        {p.slice(2, -2)}
      </Text>
    ) : p.startsWith('`') ? (
      <Text key={i} style={estilos.codigo}>
        {p.slice(1, -1)}
      </Text>
    ) : (
      <Fragment key={i}>{p}</Fragment>
    ),
  );
}

const estilos = StyleSheet.create({
  h2: { fontFamily: fontes.tituloMedio, fontSize: tamanhos.destaque + 1, color: cores.tinta, marginTop: espaco.s },
  p: { fontFamily: fontes.texto, fontSize: tamanhos.corpo, lineHeight: 25, color: cores.tinta },
  item: { flexDirection: 'row', gap: 10, alignItems: 'flex-start' },
  marcador: { width: 6, height: 6, borderRadius: 3, backgroundColor: cores.lilas, marginTop: 10 },
  citacao: { borderLeftWidth: 3, borderLeftColor: cores.lilas, paddingLeft: espaco.m, paddingVertical: 2 },
  codigo: { fontFamily: fontes.textoMedio, backgroundColor: cores.lilasClaro, color: cores.tinta },
});
