import { useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { Image } from 'expo-image';
import { Aviso, Espaco, Icone, Texto, Tela } from '@/components/ui';
import { aplicarDisfarce, DISFARCES, trocaDeIconeDisponivel, type IdDisfarce } from '@/lib/disfarce';
import { useSeguranca } from '@/store/seguranca';
import { cores, espaco, fontes, raio } from '@/theme';

export default function Disfarce() {
  const { disfarce, atualizar } = useSeguranca();
  const [aplicando, setAplicando] = useState<string | null>(null);

  async function escolher(id: IdDisfarce) {
    setAplicando(id);
    try {
      const aplicado = await aplicarDisfarce(id);
      await atualizar({ disfarce: id });
      if (!aplicado) {
        Alert.alert(
          'Disfarce salvo',
          'O ícone só muda no app instalado (versão de desenvolvimento ou de loja). No Expo Go, a preferência fica guardada para quando você instalar.',
        );
      }
    } catch (e) {
      Alert.alert('Não foi possível trocar o ícone', e instanceof Error ? e.message : 'Tente de novo.');
    } finally {
      setAplicando(null);
    }
  }

  return (
    <Tela>
      <Texto fraco>
        Troque o ícone {Platform.OS === 'android' ? 'e o nome ' : ''}do app na tela inicial do celular para algo que não chame atenção.
      </Texto>
      <Espaco />
      <View style={estilos.grade}>
        {DISFARCES.map((d) => {
          const ativo = disfarce === d.id;
          return (
            <Pressable
              key={d.id}
              onPress={() => escolher(d.id)}
              disabled={!!aplicando}
              style={[estilos.opcao, ativo && { borderColor: cores.lilas, backgroundColor: cores.lilasClaro }]}
              accessibilityRole="radio"
              accessibilityState={{ checked: ativo }}
              accessibilityLabel={`${d.nome}: ${d.descricao}`}
            >
              <Image source={d.icone} style={estilos.icone} />
              <Text style={estilos.nome}>{d.nome}</Text>
              <Text style={estilos.descricao}>{d.descricao}</Text>
              {ativo ? (
                <View style={estilos.marca}>
                  <Icone nome="checkmark-circle" cor={cores.lilas} tamanho={22} />
                </View>
              ) : null}
            </Pressable>
          );
        })}
      </View>
      <Espaco />
      {Platform.OS === 'ios' ? (
        <Aviso tom="info">No iPhone, o sistema mostra um aviso quando o ícone muda e não permite trocar o nome do app — só o ícone.</Aviso>
      ) : (
        <Aviso tom="info">No Android, o ícone e o nome mudam juntos. Alguns celulares levam alguns segundos para atualizar a tela inicial.</Aviso>
      )}
      {!trocaDeIconeDisponivel ? (
        <>
          <Espaco altura={espaco.m} />
          <Aviso tom="cuidado">Nesta versão (Expo Go ou navegador) o ícone não muda: a troca só funciona no app instalado. Sua escolha fica guardada.</Aviso>
        </>
      ) : null}
    </Tela>
  );
}

const estilos = StyleSheet.create({
  grade: { flexDirection: 'row', flexWrap: 'wrap', gap: espaco.m },
  opcao: {
    width: '47%',
    backgroundColor: cores.superficie,
    borderRadius: raio.medio,
    borderWidth: 2,
    borderColor: cores.linha,
    padding: espaco.l,
    alignItems: 'flex-start',
  },
  icone: { width: 56, height: 56, borderRadius: 14 },
  nome: { fontFamily: fontes.tituloMedio, fontSize: 16, color: cores.tinta, marginTop: espaco.m },
  descricao: { fontFamily: fontes.texto, fontSize: 13, color: cores.nevoa, marginTop: 2 },
  marca: { position: 'absolute', top: 10, right: 10 },
});
