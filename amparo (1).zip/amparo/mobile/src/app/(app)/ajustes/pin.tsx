import { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { router } from 'expo-router';
import { PinPad } from '@/components/PinPad';
import { Texto, Titulo } from '@/components/ui';
import { useSeguranca } from '@/store/seguranca';
import { cores, espaco } from '@/theme';

const TITULOS = { atual: 'Digite o PIN atual', novo: 'Digite o novo PIN', confirmar: 'Repita o novo PIN' };

export default function TrocarPin() {
  const { pinConfere, definirPin } = useSeguranca();
  const [etapa, setEtapa] = useState<'atual' | 'novo' | 'confirmar'>('atual');
  const [valor, setValor] = useState('');
  const [novo, setNovo] = useState('');
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    if (valor.length !== 6) return;
    (async () => {
      if (etapa === 'atual') {
        if (await pinConfere(valor)) setEtapa('novo');
        else setErro('PIN incorreto.');
      } else if (etapa === 'novo') {
        setNovo(valor);
        setEtapa('confirmar');
      } else if (valor === novo) {
        await definirPin(novo);
        Alert.alert('PIN alterado');
        router.back();
        return;
      } else {
        setErro('Os PINs não são iguais. Comece de novo.');
        setEtapa('novo');
      }
      setValor('');
    })();
  }, [valor, etapa, novo, pinConfere, definirPin]);

  return (
    <View style={{ flex: 1, alignItems: 'center', backgroundColor: cores.papel, paddingTop: espaco.xxl }}>
      <Titulo nivel={2} centro>
        {TITULOS[etapa]}
      </Titulo>
      <Texto fraco centro style={{ marginTop: espaco.s, marginBottom: espaco.xxl, minHeight: 24 }}>
        {erro ?? ' '}
      </Texto>
      <PinPad
        valor={valor}
        aoMudar={(v) => {
          setErro(null);
          setValor(v);
        }}
      />
    </View>
  );
}
