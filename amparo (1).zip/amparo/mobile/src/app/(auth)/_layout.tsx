import { Stack } from 'expo-router';
import { opcoesCabecalho } from '@/lib/navegacao';

export const unstable_settings = { initialRouteName: 'boas-vindas' };

export default function AuthLayout() {
  return (
    <Stack screenOptions={opcoesCabecalho}>
      <Stack.Screen name="boas-vindas" options={{ headerShown: false }} />
      <Stack.Screen name="verificar" options={{ title: 'Confirmar vínculo' }} />
      <Stack.Screen name="cadastro" options={{ title: 'Criar conta' }} />
      <Stack.Screen name="entrar" options={{ title: 'Entrar' }} />
      <Stack.Screen name="nova-senha" options={{ title: 'Nova senha' }} />
      <Stack.Screen name="termos" options={{ title: 'Termos e privacidade', presentation: 'modal' }} />
    </Stack>
  );
}
