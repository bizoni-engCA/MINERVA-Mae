/**
 * Uso opcional do ffmpeg/ffprobe (capa e duração dos vídeos).
 * Se não estiverem instalados, o app funciona igual — só sem capa.
 */
import { execFile, spawnSync } from 'node:child_process';
import { promisify } from 'node:util';

const exec = promisify(execFile);
let disponivel: boolean | undefined;

export function temFfmpeg() {
  if (disponivel === undefined) {
    disponivel =
      spawnSync('ffmpeg', ['-version'], { stdio: 'ignore' }).status === 0 &&
      spawnSync('ffprobe', ['-version'], { stdio: 'ignore' }).status === 0;
  }
  return disponivel;
}

export async function duracaoSegundos(arquivo: string): Promise<number | null> {
  if (!temFfmpeg()) return null;
  try {
    const { stdout } = await exec(
      'ffprobe',
      ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', arquivo],
      { timeout: 15000 },
    );
    const n = Number.parseFloat(stdout.trim());
    return Number.isFinite(n) ? Math.round(n) : null;
  } catch {
    return null;
  }
}

export async function gerarCapa(arquivo: string, destino: string): Promise<boolean> {
  if (!temFfmpeg()) return false;
  try {
    await exec(
      'ffmpeg',
      ['-y', '-ss', '0.5', '-i', arquivo, '-frames:v', '1', '-vf', 'scale=540:-2', '-q:v', '4', destino],
      { timeout: 20000 },
    );
    return true;
  } catch {
    return false;
  }
}
