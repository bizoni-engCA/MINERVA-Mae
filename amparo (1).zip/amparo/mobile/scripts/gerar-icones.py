"""
Gera os ícones do app e dos disfarces (assets/ e assets/disfarces/).
Uso: python3 scripts/gerar-icones.py   (requer Pillow)
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

RAIZ = Path(__file__).resolve().parent.parent
SAIDA = RAIZ / "assets" / "disfarces"
SAIDA.mkdir(parents=True, exist_ok=True)
S = 1024


def gradiente(c1, c2, tamanho=S):
    img = Image.new("RGB", (tamanho, tamanho), c1)
    d = ImageDraw.Draw(img)
    for y in range(tamanho):
        t = y / (tamanho - 1)
        cor = tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))
        d.line([(0, y), (tamanho, y)], fill=cor)
    return img


def hexa(h):
    h = h.lstrip("#")
    return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))


def fonte(tam):
    for nome in [
        "/usr/share/fonts/opentype/inter/Inter-Bold.otf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    ]:
        try:
            return ImageFont.truetype(nome, tam)
        except OSError:
            continue
    return ImageFont.load_default()


# ── Desenhos (glifos) em uma camada transparente, centralizados ─────────────
def glifo_amparo(escala=1.0):
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    c = S / 2
    r = 300 * escala
    w = int(70 * escala)
    # Arco de abrigo
    d.arc([c - r, c - r * 0.95, c + r, c + r * 1.05], start=200, end=340, fill="white", width=w)
    # Duas figuras abrigadas (círculo + corpo)
    for dx, rr in [(-95, 62), (95, 62)]:
        cx = c + dx * escala
        cy = c + 40 * escala
        d.ellipse([cx - rr * escala, cy - rr * escala, cx + rr * escala, cy + rr * escala], fill="white")
        d.rounded_rectangle(
            [cx - 92 * escala, cy + 85 * escala, cx + 92 * escala, cy + 250 * escala],
            radius=int(80 * escala),
            fill="white",
        )
    return g


def glifo_calculadora(escala=1.0):
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    c = S / 2
    L = 520 * escala
    x0, y0 = c - L / 2, c - L * 0.62
    d.rounded_rectangle([x0, y0, x0 + L, y0 + L * 0.32], radius=int(36 * escala), fill="#D8E4D2")
    passo = L / 3
    tam = passo * 0.78
    cores = ["#8E8E93", "#8E8E93", "#FF9F0A"]
    for linha in range(3):
        for col in range(3):
            bx = x0 + col * passo + (passo - tam) / 2
            by = y0 + L * 0.42 + linha * passo * 0.82
            d.rounded_rectangle([bx, by, bx + tam, by + tam * 0.72], radius=int(30 * escala), fill=cores[col] if linha == 2 else "#636366")
    return g


def glifo_notas(escala=1.0):
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    c = S / 2
    w, h = 470 * escala, 560 * escala
    d.rounded_rectangle([c - w / 2, c - h / 2, c + w / 2, c + h / 2], radius=int(40 * escala), fill="white")
    d.rectangle([c - w / 2, c - h / 2 + 30 * escala, c + w / 2, c - h / 2 + 110 * escala], fill="#F2B705")
    for i in range(5):
        y = c - h / 2 + (170 + i * 75) * escala
        d.line([c - w / 2 + 50 * escala, y, c + w / 2 - 50 * escala, y], fill="#C9C9CF", width=int(14 * escala))
    return g


def glifo_clima(escala=1.0):
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    c = S / 2
    sx, sy, sr = c + 90 * escala, c - 110 * escala, 170 * escala
    d.ellipse([sx - sr, sy - sr, sx + sr, sy + sr], fill="#FFD43B")
    nuvem = [(-150, 90, 150), (0, 30, 175), (150, 100, 135)]
    for dx, dy, r in nuvem:
        x, y, rr = c + dx * escala - 60 * escala, c + dy * escala + 40 * escala, r * escala
        d.ellipse([x - rr, y - rr, x + rr, y + rr], fill="white")
    d.rounded_rectangle([c - 360 * escala, c + 90 * escala, c + 240 * escala, c + 270 * escala], radius=int(90 * escala), fill="white")
    return g


def glifo_agenda(escala=1.0):
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    c = S / 2
    w, h = 560 * escala, 540 * escala
    d.rounded_rectangle([c - w / 2, c - h / 2, c + w / 2, c + h / 2], radius=int(60 * escala), fill="white")
    d.rounded_rectangle([c - w / 2, c - h / 2, c + w / 2, c - h / 2 + 150 * escala], radius=int(60 * escala), fill="#E5484D")
    d.rectangle([c - w / 2, c - h / 2 + 90 * escala, c + w / 2, c - h / 2 + 150 * escala], fill="#E5484D")
    f = fonte(int(270 * escala))
    texto = "17"
    caixa = d.textbbox((0, 0), texto, font=f)
    tw, th = caixa[2] - caixa[0], caixa[3] - caixa[1]
    d.text((c - tw / 2 - caixa[0], c + 70 * escala - th / 2 - caixa[1]), texto, font=f, fill="#2C2C2E")
    return g


DISFARCES = {
    # nome: (função do glifo, fundo iOS (gradiente), cor de fundo do ícone adaptativo Android)
    "padrao": (glifo_amparo, ("#7A50C4", "#4B2C88"), "#5E3AA6"),
    "calculadora": (glifo_calculadora, ("#2C2C2E", "#1C1C1E"), "#242426"),
    "notas": (glifo_notas, ("#FFE27A", "#F6C945"), "#F8D35A"),
    "clima": (glifo_clima, ("#4FA3F7", "#2D6FD6"), "#3B88E6"),
    "agenda": (glifo_agenda, ("#F2F2F7", "#E5E5EA"), "#EDEDF2"),
}

for nome, (glifo, (c1, c2), fundo_android) in DISFARCES.items():
    # iOS / prévia no app: quadrado sem transparência
    base = gradiente(hexa(c1), hexa(c2)).convert("RGBA")
    base.alpha_composite(glifo(1.0))
    base.convert("RGB").save(SAIDA / f"{nome}.png")
    # Android: só o desenho (primeiro plano), menor para caber na área segura
    glifo(0.72).save(SAIDA / f"{nome}-android.png")
    print("✓", nome, fundo_android)

# Ícone principal do app = disfarce padrão
padrao = Image.open(SAIDA / "padrao.png")
padrao.save(RAIZ / "assets" / "icon.png")
glifo_amparo(0.72).save(RAIZ / "assets" / "android-icon-foreground.png")
Image.new("RGB", (S, S), hexa("#5E3AA6")).save(RAIZ / "assets" / "android-icon-background.png")
mono = glifo_amparo(0.72)
mono.save(RAIZ / "assets" / "android-icon-monochrome.png")
# Splash discreto: só o glifo
glifo_amparo(0.9).save(RAIZ / "assets" / "splash-icon.png")
padrao.resize((48, 48)).save(RAIZ / "assets" / "favicon.png")
print("✓ ícone principal, splash e favicon")
