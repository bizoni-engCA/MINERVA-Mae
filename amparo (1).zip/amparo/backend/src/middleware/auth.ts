import type { NextFunction, Request, Response } from 'express';
import { eq } from 'drizzle-orm';
import { db, schema } from '../db';
import type { Papel, Usuaria } from '../db/schema';
import { HttpError, proibido } from '../lib/errors';
import { lerAcesso } from '../lib/tokens';

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      usuaria?: Usuaria;
    }
  }
}

export const PAPEIS_EQUIPE: Papel[] = ['MODERADORA', 'ACOLHIMENTO', 'ADMIN'];

export async function exigirLogin(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization ?? '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) throw new HttpError(401, 'Entre na sua conta para continuar.', 'NAO_AUTENTICADA');

  let payload;
  try {
    payload = lerAcesso(token);
  } catch {
    throw new HttpError(401, 'Sessão expirada.', 'TOKEN_EXPIRADO');
  }

  const [usuaria] = await db.select().from(schema.usuarias).where(eq(schema.usuarias.id, payload.sub));
  if (!usuaria || usuaria.versaoToken !== payload.v) throw new HttpError(401, 'Sessão encerrada.', 'SESSAO_INVALIDA');
  if (usuaria.status === 'BANIDA') throw new HttpError(403, 'Esta conta foi banida por violar as regras.', 'CONTA_BANIDA');
  if (usuaria.status === 'SUSPENSA') throw new HttpError(403, 'Esta conta está suspensa temporariamente.', 'CONTA_SUSPENSA');

  req.usuaria = usuaria;
  next();
}

export const exigirPapel =
  (...papeis: Papel[]) =>
  (req: Request, _res: Response, next: NextFunction) => {
    if (!req.usuaria) throw new HttpError(401, 'Entre na sua conta para continuar.', 'NAO_AUTENTICADA');
    if (req.usuaria.papel !== 'ADMIN' && !papeis.includes(req.usuaria.papel)) throw proibido();
    next();
  };

export const eu = (req: Request): Usuaria => {
  if (!req.usuaria) throw new HttpError(401, 'Entre na sua conta para continuar.', 'NAO_AUTENTICADA');
  return req.usuaria;
};

export const ehEquipe = (u: Usuaria) => PAPEIS_EQUIPE.includes(u.papel);
