import { Linking, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { Image } from 'expo-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Botao, Icone, Linha, Texto, Titulo, type NomeIcone } from '@/components/ui';
import { cores, espaco, raio } from '@/theme';

const PILARES: { icone: NomeIcone; titulo: string; texto: string }[] = [
  { icone: 'chatbubbles', titulo: 'Relatos sem se expor', texto: 'Subcomunidades para contar o que aconteceu com apelido ou como anônima.' },
  { icone: 'play-circle', titulo: 'Histórias de superação', texto: 'Vídeos curtos de quem já passou por isso e seguiu em frente.' },
  { icone: 'lock-closed', titulo: 'Um cofre para suas provas', texto: 'Guarde relatos e arquivos criptografados, gere um dossiê e receba orientação.' },
];

export default function BoasVindas() {
  const insets = useSafeAreaInsets();
  return (
    <View style={[estilos.tela, { paddingTop: insets.top + espaco.xl, paddingBottom: insets.bottom + espaco.l }]}>
      <View>
        <Image source={require('../../../assets/disfarces/padrao.png')} style={estilos.logo} accessibilityLabel="Minerva Mãe" />
        <Titulo style={estilos.marca}>Minerva Mãe</Titulo>
        <Texto style={{ fontSize: 18, lineHeight: 26, color: cores.tintaSuave }}>
          Rede de apoio e denúncia para estudantes da UFRJ. Feita por e para mulheres e pessoas não-binárias.
        </Texto>
      </View>

      <View style={{ gap: espaco.l }}>
        {PILARES.map((p) => (
          <Linha key={p.titulo} espacamento={espaco.m} estilo={{ alignItems: 'flex-start' }}>
            <View style={estilos.pilarIcone}>
              <Icone nome={p.icone} cor={cores.lilas} tamanho={20} />
            </View>
            <View style={{ flex: 1 }}>
              <Texto negrito>{p.titulo}</Texto>
              <Texto pequeno fraco>
                {p.texto}
              </Texto>
            </View>
          </Linha>
        ))}
      </View>

      <View style={{ gap: espaco.m }}>
        <Botao titulo="Criar conta com meu DRE" onPress={() => router.push('/verificar?finalidade=CADASTRO')} />
        <Botao titulo="Já tenho conta" variante="secundario" onPress={() => router.push('/entrar')} />
        <Texto pequeno fraco centro style={{ marginTop: espaco.s }}>
          Precisa de ajuda agora?{' '}
          <Texto pequeno negrito cor={cores.lilas} onPress={() => Linking.openURL('tel:180')}>
            Ligue 180
          </Texto>{' '}
          (24h) ou{' '}
          <Texto pequeno negrito cor={cores.sinal} onPress={() => Linking.openURL('tel:190')}>
            190
          </Texto>{' '}
          em emergência.
        </Texto>
      </View>
    </View>
  );
}

const estilos = StyleSheet.create({
  tela: { flex: 1, backgroundColor: cores.papel, paddingHorizontal: espaco.xl, justifyContent: 'space-between' },
  logo: { width: 64, height: 64, borderRadius: 16, marginBottom: espaco.l },
  marca: { fontSize: 44, lineHeight: 48, letterSpacing: -1.2, marginBottom: espaco.s },
  pilarIcone: { width: 40, height: 40, borderRadius: raio.medio, backgroundColor: cores.lilasClaro, alignItems: 'center', justifyContent: 'center' },
});
