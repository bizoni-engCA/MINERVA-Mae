/**
 * Dados de exemplo para o MVP: subcomunidades, contas da equipe, uma estudante
 * de demonstração, relatos, comentários, vídeos e um caso com provas.
 * Pode ser rodado várias vezes — o que já existe é mantido.
 */
import { execFileSync } from 'node:child_process';
import { mkdtempSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import argon2 from 'argon2';
import { eq, sql } from 'drizzle-orm';
import { config } from '../config';
import { hashIdentificador } from '../lib/crypto';
import { temFfmpeg } from '../lib/ffmpeg';
import { storage } from '../lib/storage';
import { armazenarProva, carregarCaso, criarCaso } from '../modules/casos/servico';
import { db, pool, schema } from './index';
import type { Papel } from './schema';

const SENHA_DEMO = 'minerva123';

const COMUNIDADES = [
  { slug: 'sala-de-aula', nome: 'Sala de aula e laboratório', icone: 'school', cor: '#7C4DBA',
    descricao: 'Situações com docentes, monitores e colegas em aulas, provas, laboratórios e trabalhos em grupo.' },
  { slug: 'orientacao-e-pos', nome: 'Orientação e pós-graduação', icone: 'library', cor: '#5B6CC9',
    descricao: 'Relações de orientação, bolsas, grupos de pesquisa, iniciação científica, mestrado e doutorado.' },
  { slug: 'campus-e-transporte', nome: 'Campus e transporte', icone: 'bus', cor: '#D9734E',
    descricao: 'Fundão, Praia Vermelha, Macaé, Caxias, ônibus internos e caminhos até a universidade.' },
  { slug: 'alojamento', nome: 'Alojamento e moradia', icone: 'home', cor: '#3E9C8B',
    descricao: 'Convivência no alojamento estudantil, repúblicas e moradias compartilhadas.' },
  { slug: 'festas-e-eventos', nome: 'Festas, trotes e eventos', icone: 'musical-notes', cor: '#C24B8E',
    descricao: 'Calouradas, festas de curso, jogos universitários, congressos e viagens de campo.' },
  { slug: 'violencia-online', nome: 'Violência online', icone: 'phone-portrait', cor: '#4C8AC9',
    descricao: 'Grupos de WhatsApp, exposição de fotos, perfis falsos, ataques e perseguição na internet.' },
  { slug: 'saude-mental', nome: 'Saúde mental e autocuidado', icone: 'leaf', cor: '#5E9C4E',
    descricao: 'Como estamos, o que tem ajudado, indicações de cuidado e acolhimento entre nós.' },
  { slug: 'conquistas', nome: 'Conquistas e rede de apoio', icone: 'sparkles', cor: '#D69A00',
    descricao: 'Vitórias, denúncias que deram certo, recomeços e mensagens de força para quem está chegando.' },
  { slug: 'trans-e-nao-binaries', nome: 'Trans, travestis e não-binárias', icone: 'transgender', cor: '#8E5BC9',
    descricao: 'Espaço de mulheres trans, travestis e pessoas não-binárias da UFRJ.' },
  { slug: 'maes-na-universidade', nome: 'Mães na universidade', icone: 'heart-circle', cor: '#C9574B',
    descricao: 'Maternidade, permanência estudantil, creche, prazos e preconceitos enfrentados por mães.' },
];

const REGRAS_PADRAO =
  '1. Não cite nomes, apelidos, cargos com nome, disciplinas ou qualquer dado que identifique alguém — use o campo "só para a moderação".\n' +
  '2. Acolha. Nada de julgar, duvidar ou culpar quem relata.\n' +
  '3. Sem ódio: racismo, LGBTfobia, capacitismo e afins levam a banimento.\n' +
  '4. O que é contado aqui fica aqui. Não faça prints nem exponha relatos fora do app.';

async function garantirConta(apelido: string, papel: Papel, dre: string) {
  const [existente] = await db.select().from(schema.usuarias).where(eq(schema.usuarias.apelido, apelido));
  if (existente) return existente;
  const [u] = await db
    .insert(schema.usuarias)
    .values({
      apelido,
      papel,
      senhaHash: await argon2.hash(SENHA_DEMO, { type: argon2.argon2id }),
      vinculoTipo: 'ESTUDANTE',
      vinculoHash: hashIdentificador('ESTUDANTE', dre),
      autodeclaracaoEm: new Date(),
      termosVersao: config.TERMOS_VERSAO,
    })
    .returning();
  return u;
}

const horasAtras = (h: number) => new Date(Date.now() - h * 3600 * 1000);

async function main() {
  console.log('🌱 Semeando dados de exemplo…');

  // ── Contas ─────────────────────────────────────────────────────
  const admin = await garantirConta('equipe.admin', 'ADMIN', '100000001');
  const moderadora = await garantirConta('moderadora.demo', 'MODERADORA', '100000002');
  const acolhimento = await garantirConta('acolhimento.demo', 'ACOLHIMENTO', '100000003');
  const estudante = await garantirConta('estudante.demo', 'USUARIA', '100000004');
  const outras = await Promise.all(
    ['girassol', 'lua.minguante', 'ipe.amarelo', 'maré.alta', 'jabuticaba'].map((a, i) =>
      garantirConta(a, 'USUARIA', `10000010${i}`),
    ),
  );

  // ── Comunidades ────────────────────────────────────────────────
  for (const c of COMUNIDADES) {
    await db
      .insert(schema.comunidades)
      .values({ ...c, regras: REGRAS_PADRAO, criadaPorId: moderadora.id })
      .onConflictDoNothing({ target: schema.comunidades.slug });
  }
  const comunidades = await db.select().from(schema.comunidades);
  const porSlug = (slug: string) => comunidades.find((c) => c.slug === slug)!.id;

  // ── Relatos (só se ainda não houver nenhum) ────────────────────
  const [{ total }] = await db.select({ total: sql<number>`count(*)::int` }).from(schema.posts);
  if (total === 0) {
    const relatos = [
      {
        autora: outras[0], comunidade: 'sala-de-aula', horas: 50, anonimo: true, sensivel: false,
        titulo: 'Comentários sobre meu corpo durante a aula prática',
        corpo:
          'No laboratório, um docente vivia fazendo "brincadeiras" sobre minha roupa na frente da turma. Todo mundo ria e eu ficava sem reação. ' +
          'Comecei a faltar nas práticas. Demorei meses para entender que aquilo não era normal e que eu não estava exagerando. ' +
          'Hoje estou juntando os prints do grupo da turma onde ele também mandava essas coisas.',
      },
      {
        autora: outras[1], comunidade: 'orientacao-e-pos', horas: 30, anonimo: false, sensivel: false,
        titulo: 'Quando a orientação vira chantagem',
        corpo:
          'Na pós, ouvi várias vezes que minha bolsa dependia de eu "estar disponível" fora do horário, inclusive em encontros que não eram de trabalho. ' +
          'Troquei de orientação depois de muita conversa com a coordenação. Se você está passando por isso: existe saída, e não é culpa sua.',
      },
      {
        autora: outras[2], comunidade: 'campus-e-transporte', horas: 20, anonimo: true, sensivel: true,
        titulo: 'Fui seguida no caminho até o ponto de ônibus à noite',
        corpo:
          'Saí tarde da biblioteca e um homem me seguiu até o ponto. Liguei para uma amiga e fiquei falando alto até o ônibus chegar. ' +
          'Alguém sabe se tem como pedir acompanhamento da segurança do campus nesse horário? Ando com medo de sair depois das 21h.',
      },
      {
        autora: outras[3], comunidade: 'violencia-online', horas: 12, anonimo: true, sensivel: true,
        titulo: 'Montaram uma lista ranqueando as calouras',
        corpo:
          'Descobri que em um grupo de veteranos circulava uma lista com fotos nossas tiradas do Instagram, com "notas". ' +
          'Algumas meninas fizeram prints antes de apagarem. Estamos pensando em denunciar juntas na Ouvidoria. Alguém já fez denúncia coletiva?',
      },
      {
        autora: outras[4], comunidade: 'conquistas', horas: 6, anonimo: false, sensivel: false,
        titulo: 'A denúncia andou! 💜',
        corpo:
          'Há um ano eu escrevi aqui pela primeira vez, ainda sem coragem de contar para ninguém. Organizei tudo, fui à Ouvidoria com uma amiga e o processo foi aberto. ' +
          'Não foi rápido nem fácil, mas hoje eu volto para o campus de cabeça erguida. Obrigada a cada uma que comentou aqui naquela época.',
      },
      {
        autora: estudante, comunidade: 'saude-mental', horas: 3, anonimo: false, sensivel: false,
        titulo: 'O que tem ajudado vocês a dormir depois de tudo?',
        corpo:
          'Desde que aconteceu, tenho tido muita dificuldade para dormir e me concentrar. Comecei o acolhimento na DISAE semana passada. ' +
          'Queria saber o que tem funcionado para vocês nas noites mais difíceis.',
      },
    ];
    const ids: string[] = [];
    for (const r of relatos) {
      const [p] = await db
        .insert(schema.posts)
        .values({
          comunidadeId: porSlug(r.comunidade),
          autoraId: r.autora.id,
          titulo: r.titulo,
          corpo: r.corpo,
          anonimo: r.anonimo,
          sensivel: r.sensivel,
          status: 'PUBLICADO',
          publicadoEm: horasAtras(r.horas),
          criadoEm: horasAtras(r.horas),
        })
        .returning({ id: schema.posts.id });
      ids.push(p.id);
    }

    // Um relato retido pelo filtro (cita nome) e um só para a moderação.
    await db.insert(schema.posts).values([
      {
        comunidadeId: porSlug('sala-de-aula'),
        autoraId: outras[1].id,
        titulo: 'Cuidado com o professor Fulano de Tal',
        corpo: 'Ele fica mandando mensagens de madrugada para alunas da turma de XYZ123 pedindo para conversar "em particular".',
        anonimo: true,
        status: 'EM_REVISAO',
        alertas: ['Cargo ou tratamento seguido de nome: "Fulano de Tal"', 'Código de disciplina ou turma: "XYZ123"'],
        criadoEm: horasAtras(2),
      },
      {
        comunidadeId: porSlug('alojamento'),
        autoraId: estudante.id,
        titulo: 'Preciso contar o que está acontecendo no meu bloco',
        corpo: 'Não quero que isso fique público, mas preciso que alguém da moderação saiba. Um morador do meu andar tem entrado no meu quarto sem permissão.',
        anonimo: true,
        visibilidade: 'SO_MODERACAO',
        status: 'EM_REVISAO',
        criadoEm: horasAtras(1),
      },
    ]);

    const comentarios: [number, number, string, boolean][] = [
      [0, 1, 'Eu passei por algo muito parecido. Você não está exagerando. Guarda tudo, inclusive a lista de faltas — isso mostra o impacto.', false],
      [0, 3, 'Te apoio! Se quiser, o guia "Como guardar provas" daqui do app ajudou muito a organizar os prints.', true],
      [1, 4, 'Obrigada por compartilhar a saída. A gente precisa saber que dá para trocar de orientação.', false],
      [2, 0, 'A DISAE e a Ouvidoria já me orientaram sobre segurança no campus. Vale também combinar de sair em grupo — a gente pode se organizar aqui.', false],
      [3, 2, 'Denúncia coletiva é possível sim! Cada uma registra a sua no Fala.BR citando as outras, e vocês podem ir juntas na Ouvidoria da Mulher.', false],
      [4, 0, 'Que notícia linda! Obrigada por voltar para contar 💜', false],
      [5, 2, 'Para mim ajudou ter uma rotina para desligar o celular cedo e anotar o que estava na cabeça antes de deitar.', false],
    ];
    for (const [post, autora, corpo, anonimo] of comentarios) {
      await db.insert(schema.comentarios).values({
        postId: ids[post],
        autoraId: outras[autora].id,
        corpo,
        anonimo,
        status: 'PUBLICADO',
      });
    }

    const reacoes: [number, number[], 'APOIO' | 'ME_IDENTIFICO' | 'FORCA'][] = [
      [0, [1, 2, 3, 4], 'APOIO'],
      [0, [1, 3], 'ME_IDENTIFICO'],
      [1, [0, 2, 3], 'FORCA'],
      [2, [0, 1, 4], 'APOIO'],
      [3, [0, 1, 2, 4], 'APOIO'],
      [4, [0, 1, 2, 3], 'FORCA'],
      [5, [0, 2], 'ME_IDENTIFICO'],
    ];
    for (const [post, quem, tipo] of reacoes) {
      for (const q of quem) {
        await db.insert(schema.reacoesPost).values({ postId: ids[post], usuariaId: outras[q].id, tipo }).onConflictDoNothing();
      }
    }
    for (const slug of ['saude-mental', 'conquistas', 'sala-de-aula']) {
      await db.insert(schema.membrosComunidade).values({ usuariaId: estudante.id, comunidadeId: porSlug(slug) }).onConflictDoNothing();
    }
    console.log('   ✓ relatos, comentários e reações');
  }

  // ── Vídeos de exemplo (precisa do ffmpeg) ──────────────────────
  const [{ totalVideos }] = await db.select({ totalVideos: sql<number>`count(*)::int` }).from(schema.videos);
  if (totalVideos === 0 && temFfmpeg()) {
    const fonte = resolve('assets/fonts/Inter-SemiBold.otf');
    const exemplos = [
      { autora: outras[4], titulo: 'Um ano depois: voltei a amar o meu curso', cor: '0x3B1F66', status: 'PUBLICADO' as const, linha1: 'Video de exemplo', linha2: 'Um ano depois' },
      { autora: outras[1], titulo: 'Para quem está com medo de denunciar', cor: '0x1F4E66', status: 'PUBLICADO' as const, linha1: 'Video de exemplo', linha2: 'Voce nao esta sozinha' },
      { autora: outras[2], titulo: 'Como a rede de apoio me ajudou', cor: '0x5E2A4F', status: 'EM_REVISAO' as const, linha1: 'Aguardando moderacao', linha2: 'Rede de apoio' },
    ];
    for (const [i, v] of exemplos.entries()) {
      const pasta = mkdtempSync(join(tmpdir(), 'amparo-seed-'));
      const arquivo = join(pasta, 'video.mp4');
      const capa = join(pasta, 'capa.jpg');
      const texto = (t: string, y: string, tam: number) =>
        `drawtext=fontfile='${fonte}':text='${t}':fontcolor=white:fontsize=${tam}:x=(w-text_w)/2:y=${y}`;
      execFileSync('ffmpeg', [
        '-y', '-f', 'lavfi', '-i', `color=c=${v.cor}:s=720x1280:d=6`,
        '-f', 'lavfi', '-i', 'sine=frequency=330:duration=6',
        '-vf', [texto(v.linha1, '(h/2)-70', 34), texto(v.linha2, '(h/2)', 44)].join(','),
        '-shortest', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '64k', '-movflags', '+faststart', arquivo,
      ], { stdio: 'ignore' });
      execFileSync('ffmpeg', ['-y', '-ss', '1', '-i', arquivo, '-frames:v', '1', '-vf', 'scale=540:-2', capa], { stdio: 'ignore' });

      const [linha] = await db
        .insert(schema.videos)
        .values({
          autoraId: v.autora.id,
          titulo: v.titulo,
          descricao: 'Vídeo gerado automaticamente para demonstração.',
          mostrarApelido: i !== 1,
          status: v.status,
          arquivoChave: 'pendente',
          mimeType: 'video/mp4',
          tamanhoBytes: statSync(arquivo).size,
          duracaoSeg: 6,
          publicadoEm: v.status === 'PUBLICADO' ? horasAtras(10 - i) : null,
        })
        .returning({ id: schema.videos.id });
      const chave = `videos/${linha.id}.mp4`;
      const chaveCapa = `videos/${linha.id}-capa.jpg`;
      const { pipeline } = await import('node:stream/promises');
      const { createReadStream } = await import('node:fs');
      await pipeline(createReadStream(arquivo), await storage.abrirEscrita(chave));
      await pipeline(createReadStream(capa), await storage.abrirEscrita(chaveCapa));
      await db.update(schema.videos).set({ arquivoChave: chave, capaChave: chaveCapa }).where(eq(schema.videos.id, linha.id));
      rmSync(pasta, { recursive: true, force: true });
    }
    console.log('   ✓ vídeos de exemplo');
  } else if (totalVideos === 0) {
    console.log('   ⚠ ffmpeg não encontrado — vídeos de exemplo não foram criados (o app funciona normalmente).');
  }

  // ── Caso de demonstração da estudante.demo ─────────────────────
  const [{ totalCasos }] = await db
    .select({ totalCasos: sql<number>`count(*)::int` })
    .from(schema.casos)
    .where(eq(schema.casos.donaId, estudante.id));
  if (totalCasos === 0) {
    const caso = await criarCaso(estudante.id, {
      titulo: 'Mensagens do monitor da disciplina',
      relato:
        'Desde o início do período, o monitor da disciplina passou a me mandar mensagens fora do horário, primeiro sobre a matéria e depois elogiando minha aparência. ' +
        'Quando parei de responder, ele disse que "poderia me ajudar ou me atrapalhar" na correção das listas. Depois disso, minhas notas nas listas caíram sem explicação.',
      dataOcorrido: 'Entre agosto e outubro de 2026',
      local: 'Grupo de WhatsApp da turma e laboratório de informática',
      tiposViolencia: ['ASSEDIO_SEXUAL', 'VIOLENCIA_PSICOLOGICA'],
      vinculoAutor: 'ESTUDANTE',
      pessoasEnvolvidas: 'Monitor da disciplina (nome registrado apenas aqui, no meu caso).',
      testemunhas: 'Uma colega da turma viu as mensagens no meu celular.',
      impactos: 'Passei a evitar as monitorias e fiquei ansiosa antes das aulas.',
    });
    const { dek } = await carregarCaso(caso.id, estudante);
    const pasta = mkdtempSync(join(tmpdir(), 'amparo-seed-'));
    const anotacoes = join(pasta, 'anotacoes.txt');
    writeFileSync(
      anotacoes,
      '12/08 — primeira mensagem às 23h40 pedindo para conversar "sobre a lista".\n' +
        '29/08 — comentário sobre minha roupa no laboratório.\n' +
        '03/10 — mensagem dizendo que "poderia me ajudar ou me atrapalhar".\n',
    );
    await armazenarProva({
      casoId: caso.id,
      dekCaso: dek,
      caminhoArquivo: anotacoes,
      mimeType: 'text/plain',
      tamanhoBytes: statSync(anotacoes).size,
      meta: { nomeOriginal: 'anotacoes.txt', descricao: 'Diário com as datas de cada episódio', dataCaptura: '03/10/2026' },
      atorId: estudante.id,
    });
    if (temFfmpeg()) {
      const print = join(pasta, 'print-conversa.png');
      const fonte = resolve('assets/fonts/Inter-Regular.otf');
      execFileSync('ffmpeg', [
        '-y', '-f', 'lavfi', '-i', 'color=c=0xECE5DD:s=540x960:d=1',
        '-vf', `drawtext=fontfile='${fonte}':text='[imagem de exemplo]':fontcolor=0x555555:fontsize=34:x=(w-text_w)/2:y=(h-text_h)/2`,
        '-frames:v', '1', print,
      ], { stdio: 'ignore' });
      await armazenarProva({
        casoId: caso.id,
        dekCaso: dek,
        caminhoArquivo: print,
        mimeType: 'image/png',
        tamanhoBytes: statSync(print).size,
        meta: { nomeOriginal: 'print-conversa.png', descricao: 'Print da conversa de 03/10', dataCaptura: '03/10/2026' },
        atorId: estudante.id,
      });
    }
    rmSync(pasta, { recursive: true, force: true });
    console.log('   ✓ caso de demonstração com provas');
  }

  console.log(`\n✅ Pronto! Contas de demonstração (senha: ${SENHA_DEMO}):`);
  console.log('   estudante.demo    → usuária comum');
  console.log('   moderadora.demo   → moderação');
  console.log('   acolhimento.demo  → equipe de acolhimento');
  console.log('   equipe.admin      → administração');
  void admin;
  void acolhimento;
}

await main();
await pool.end();
