import { Linking, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useCasos } from '@/api/consultas';
import { mensagemDeErro } from '@/api/cliente';
import type { ResumoCaso } from '@/api/tipos';
import { Botao, Carregando, Etiqueta, Icone, Linha, Texto, Titulo, type NomeIcone } from '@/components/ui';
import { plural, tempoRelativo } from '@/lib/formatar';
import { STATUS_CASO, TIPOS_VIOLENCIA } from '@/lib/rotulos';
import { cores, espaco, fontes, raio } from '@/theme';

const GUIAS_RAPIDOS: { slug: string; titulo: string; icone: NomeIcone }[] = [
  { slug: 'primeiros-passos', titulo: 'Primeiros passos depois de uma violência', icone: 'heart-outline' },
  { slug: 'guardar-provas', titulo: 'Como guardar provas', icone: 'shield-checkmark-outline' },
  { slug: 'denunciar-na-ufrj', titulo: 'Como denunciar na UFRJ', icone: 'school-outline' },
  { slug: 'usar-dossie', titulo: 'Como usar o seu dossiê', icone: 'folder-open-outline' },
];

export default function Denuncia() {
  const casos = useCasos();

  return (
    <ScrollView
      style={{ backgroundColor: cores.papel }}
      contentContainerStyle={{ paddingBottom: espaco.xxl }}
      refreshControl={<RefreshControl refreshing={casos.isRefetching} onRefresh={() => void casos.refetch()} tintColor={cores.lilas} />}
    >
      {/* O cofre: o elemento de destaque do app */}
      <View style={estilos.cofre}>
        <Linha espacamento={espaco.s}>
          <Icone nome="lock-closed" cor={cores.cofreTexto} tamanho={18} />
          <Text style={estilos.cofreRotulo}>Criptografado · só você vê</Text>
        </Linha>
        <Text style={estilos.cofreTitulo}>Seu cofre</Text>
        <Text style={estilos.cofreTexto}>
          Registre o que aconteceu, guarde provas com data e impressão digital, gere um dossiê e, se quiser, peça orientação à equipe de acolhimento.
        </Text>
        <Botao titulo="Registrar um caso" icone="add" estilo={{ marginTop: espaco.l, alignSelf: 'flex-start' }} onPress={() => router.push('/caso/formulario')} />

        {casos.isLoading ? (
          <Carregando />
        ) : casos.isError ? (
          <Texto cor={cores.cofreTexto} style={{ marginTop: espaco.l }}>
            {mensagemDeErro(casos.error)}
          </Texto>
        ) : casos.data?.length ? (
          <View style={{ marginTop: espaco.xl, gap: espaco.s }}>
            {casos.data.map((c) => (
              <ItemCaso key={c.id} caso={c} />
            ))}
          </View>
        ) : (
          <Text style={[estilos.cofreTexto, { marginTop: espaco.l, opacity: 0.75 }]}>Nenhum caso guardado ainda. Você pode começar só com um título e completar depois.</Text>
        )}
      </View>

      <View style={{ paddingHorizontal: espaco.l, marginTop: espaco.xl }}>
        <Titulo nivel={2}>Orientação</Titulo>
        <Texto fraco style={{ marginTop: 4, marginBottom: espaco.m }}>
          Guias psicológicos e jurídicos e contatos de apoio.
        </Texto>
        {GUIAS_RAPIDOS.map((g) => (
          <Pressable key={g.slug} onPress={() => router.push(`/orientacao/${g.slug}`)} style={({ pressed }) => [estilos.guia, pressed && { opacity: 0.7 }]} accessibilityRole="button">
            <Icone nome={g.icone} cor={cores.lilas} />
            <Text style={estilos.guiaTexto}>{g.titulo}</Text>
            <Icone nome="chevron-forward" cor={cores.nevoa} tamanho={18} />
          </Pressable>
        ))}
        <Botao titulo="Ver todos os guias e contatos" variante="secundario" estilo={{ marginTop: espaco.l }} onPress={() => router.push('/orientacao')} />

        <View style={estilos.emergencia}>
          <Texto negrito>Em perigo agora?</Texto>
          <Linha estilo={{ marginTop: espaco.s }}>
            <Botao titulo="Ligar 190" icone="call" variante="perigo" compacto onPress={() => Linking.openURL('tel:190')} />
            <Botao titulo="Ligue 180" icone="call" variante="secundario" compacto onPress={() => Linking.openURL('tel:180')} />
          </Linha>
        </View>
      </View>
    </ScrollView>
  );
}

function ItemCaso({ caso }: { caso: ResumoCaso }) {
  const s = STATUS_CASO[caso.status];
  return (
    <Pressable onPress={() => router.push(`/caso/${caso.id}`)} style={({ pressed }) => [estilos.caso, pressed && { opacity: 0.85 }]} accessibilityRole="button">
      <View style={{ flex: 1, gap: 6 }}>
        <Text style={estilos.casoTitulo} numberOfLines={2}>
          {caso.titulo}
        </Text>
        {caso.tiposViolencia.length ? (
          <Text style={estilos.casoMeta} numberOfLines={1}>
            {caso.tiposViolencia.map((t) => TIPOS_VIOLENCIA[t]).join(', ')}
          </Text>
        ) : null}
        <Linha>
          <Etiqueta texto={s.rotulo} cor={s.cor} fundo={s.fundo} />
          <Text style={estilos.casoMeta}>
            {plural(caso.totalProvas ?? 0, 'prova', 'provas')} · {tempoRelativo(caso.atualizadoEm)}
          </Text>
        </Linha>
      </View>
      <Icone nome="chevron-forward" cor={cores.cofreTexto} tamanho={18} />
    </Pressable>
  );
}

const estilos = StyleSheet.create({
  cofre: { backgroundColor: cores.cofre, padding: espaco.xl, paddingTop: espaco.l, borderBottomLeftRadius: raio.grande, borderBottomRightRadius: raio.grande },
  cofreRotulo: { fontFamily: fontes.textoMedio, fontSize: 13.5, color: cores.cofreTexto, opacity: 0.85 },
  cofreTitulo: { fontFamily: fontes.titulo, fontSize: 38, lineHeight: 44, color: '#FFFFFF', letterSpacing: -1, marginTop: espaco.m },
  cofreTexto: { fontFamily: fontes.texto, fontSize: 15.5, lineHeight: 23, color: cores.cofreTexto, marginTop: espaco.s },
  caso: { flexDirection: 'row', alignItems: 'center', gap: espaco.m, backgroundColor: 'rgba(255,255,255,0.07)', borderRadius: raio.medio, padding: espaco.l },
  casoTitulo: { fontFamily: fontes.tituloMedio, fontSize: 17, color: '#FFFFFF' },
  casoMeta: { fontFamily: fontes.texto, fontSize: 13, color: cores.cofreTexto, opacity: 0.8 },
  guia: { flexDirection: 'row', alignItems: 'center', gap: espaco.m, paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: cores.linha },
  guiaTexto: { flex: 1, fontFamily: fontes.textoMedio, fontSize: 16, color: cores.tinta },
  emergencia: { marginTop: espaco.xl, padding: espaco.l, borderRadius: raio.medio, borderWidth: 1.5, borderColor: cores.sinalClaro, backgroundColor: cores.superficie },
});
