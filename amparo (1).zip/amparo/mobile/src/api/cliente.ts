import { Platform } from 'react-native';
import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import type { Sessao } from './tipos';
import { urlApi } from '@/lib/config';
import { useSessao } from '@/store/sessao';

export class ApiErro extends Error {
  constructor(
    public status: number,
    message: string,
    public codigo?: string,
  ) {
    super(message);
  }
}

let renovando: Promise<boolean> | null = null;

/** Troca o token de renovação por um novo par (uma única vez, mesmo com várias chamadas simultâneas). */
async function renovarSessao(): Promise<boolean> {
  const { tokenRenovacao } = useSessao.getState();
  if (!tokenRenovacao) return false;
  renovando ??= (async () => {
    try {
      const r = await fetch(`${urlApi()}/api/auth/renovar`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tokenRenovacao }),
      });
      if (!r.ok) {
        await useSessao.getState().limpar();
        return false;
      }
      await useSessao.getState().definir((await r.json()) as Sessao);
      return true;
    } catch {
      return false;
    } finally {
      setTimeout(() => (renovando = null), 0);
    }
  })();
  return renovando;
}

type Opcoes = { metodo?: 'GET' | 'POST' | 'PATCH' | 'DELETE'; corpo?: unknown; form?: FormData; semAuth?: boolean };

export async function api<T = unknown>(caminho: string, opcoes: Opcoes = {}): Promise<T> {
  const executar = () => {
    const token = useSessao.getState().tokenAcesso;
    const headers: Record<string, string> = { Accept: 'application/json' };
    if (opcoes.corpo !== undefined) headers['Content-Type'] = 'application/json';
    if (token && !opcoes.semAuth) headers.Authorization = `Bearer ${token}`;
    return fetch(`${urlApi()}${caminho}`, {
      method: opcoes.metodo ?? (opcoes.corpo !== undefined || opcoes.form ? 'POST' : 'GET'),
      headers,
      body: opcoes.form ?? (opcoes.corpo !== undefined ? JSON.stringify(opcoes.corpo) : undefined),
    });
  };

  let resposta: Response;
  try {
    resposta = await executar();
    if (resposta.status === 401 && !opcoes.semAuth && useSessao.getState().tokenRenovacao) {
      if (await renovarSessao()) resposta = await executar();
    }
  } catch {
    throw new ApiErro(0, 'Sem conexão com o servidor. Confira sua internet e tente de novo.', 'SEM_CONEXAO');
  }

  if (resposta.status === 204) return undefined as T;
  const dados = (await resposta.json().catch(() => ({}))) as { erro?: string; codigo?: string };
  if (!resposta.ok) {
    if (!opcoes.semAuth && (resposta.status === 401 || dados.codigo === 'CONTA_BANIDA' || dados.codigo === 'CONTA_SUSPENSA')) {
      await useSessao.getState().limpar();
    }
    throw new ApiErro(resposta.status, dados.erro ?? 'Algo deu errado. Tente de novo.', dados.codigo);
  }
  return dados as T;
}

export const mensagemDeErro = (e: unknown) =>
  e instanceof ApiErro ? e.message : e instanceof Error ? e.message : 'Algo deu errado. Tente de novo.';

/** Monta um FormData com um arquivo local (celular) ou blob (web). */
export async function formComArquivo(
  arquivo: { uri: string; nome: string; mime: string },
  campos: Record<string, string | undefined> = {},
) {
  const form = new FormData();
  for (const [k, v] of Object.entries(campos)) if (v !== undefined && v !== '') form.append(k, v);
  if (Platform.OS === 'web') {
    const blob = await (await fetch(arquivo.uri)).blob();
    form.append('arquivo', blob, arquivo.nome);
  } else {
    // React Native aceita { uri, name, type } diretamente.
    form.append('arquivo', { uri: arquivo.uri, name: arquivo.nome, type: arquivo.mime } as unknown as Blob);
  }
  return form;
}

/**
 * Baixa um arquivo autenticado (dossiê, pacote, prova) e abre a folha de
 * compartilhamento. A cópia temporária é apagada em seguida.
 */
export async function baixarECompartilhar(caminho: string, nomeArquivo: string, mime: string) {
  // Garante um token válido antes do download.
  await api('/api/eu');
  const token = useSessao.getState().tokenAcesso ?? '';
  const url = `${urlApi()}${caminho}`;

  if (Platform.OS === 'web') {
    const r = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!r.ok) throw new ApiErro(r.status, 'Não foi possível baixar o arquivo.');
    const link = document.createElement('a');
    link.href = URL.createObjectURL(await r.blob());
    link.download = nomeArquivo;
    link.click();
    return;
  }

  const destino = new File(Paths.cache, nomeArquivo);
  if (destino.exists) destino.delete();
  const arquivo = await File.downloadFileAsync(url, destino, {
    headers: { Authorization: `Bearer ${token}` },
    idempotent: true,
  });
  try {
    await Sharing.shareAsync(arquivo.uri, { mimeType: mime, dialogTitle: nomeArquivo });
  } finally {
    // Não deixa cópia sensível no aparelho.
    setTimeout(() => {
      try {
        if (arquivo.exists) arquivo.delete();
      } catch {
        /* ignora */
      }
    }, 60_000);
  }
}

export const urlMidia = (caminho: string) => `${urlApi()}${caminho}`;
