/**
 * Conteúdo de orientação (aba Denúncia → Orientação).
 *
 * Revisado em novembro de 2026 a partir das fontes listadas em cada item.
 * Telefones e endereços mudam: revise este arquivo periodicamente e, idealmente,
 * valide o texto com a Ouvidoria da Mulher da UFRJ, o CRM-SSA e a Defensoria.
 *
 * Formatação: markdown simples (## título, **negrito**, listas com "- ").
 */

export const CONTEUDO_ATUALIZADO_EM = '2026-11';

export type Contato = {
  id: string;
  nome: string;
  descricao: string;
  categoria: 'EMERGENCIA' | 'UFRJ' | 'JURIDICO' | 'APOIO' | 'POLICIA';
  telefone?: string;
  whatsapp?: string;
  email?: string;
  site?: string;
  endereco?: string;
  horario?: string;
  fonte: string;
};

export const CONTATOS: Contato[] = [
  {
    id: 'pm-190',
    nome: 'Polícia Militar — 190',
    descricao: 'Se você está em perigo agora ou a violência está acontecendo neste momento.',
    categoria: 'EMERGENCIA',
    telefone: '190',
    horario: '24 horas',
    fonte: 'https://www.tjrj.jus.br/observatorio-judicial-violencia-mulher/rede-atendimento/estadual',
  },
  {
    id: 'samu-192',
    nome: 'SAMU — 192',
    descricao: 'Emergências de saúde. Em caso de violência sexual, procure atendimento de saúde o quanto antes (veja o guia "Primeiros passos").',
    categoria: 'EMERGENCIA',
    telefone: '192',
    horario: '24 horas',
    fonte: 'https://www.gov.br/saude/pt-br/composicao/saes/samu-192',
  },
  {
    id: 'ligue-180',
    nome: 'Ligue 180 — Central de Atendimento à Mulher',
    descricao:
      'Acolhimento, orientação e registro de denúncias de violência contra a mulher. Gratuito, atendido por mulheres, também em Libras.',
    categoria: 'EMERGENCIA',
    telefone: '180',
    whatsapp: '(61) 9610-0180',
    email: 'central180@mulheres.gov.br',
    horario: '24 horas, todos os dias',
    fonte: 'https://agenciagov.ebc.com.br/noticias/202608/lei-maria-da-penha-como-funciona-a-central-de-atendimento-a-mulher-ligue-180',
  },
  {
    id: 'ouvidoria-ufrj',
    nome: 'Ouvidoria-Geral e Ouvidoria da Mulher da UFRJ',
    descricao:
      'Canal oficial para denúncias na UFRJ, registradas pelo sistema Fala.BR. A Ouvidoria da Mulher atende mulheres cis, trans e travestis — estudantes, servidoras, estagiárias e terceirizadas. Atendimento presencial com agendamento.',
    categoria: 'UFRJ',
    site: 'https://ouvidoria.ufrj.br',
    endereco: 'Av. Pedro Calmon, 550 — Prédio da Reitoria, 2º andar, Cidade Universitária',
    fonte: 'https://ouvidoria.ufrj.br/images/apresentacao_GAM_-_18abr23.pdf',
  },
  {
    id: 'falabr',
    nome: 'Fala.BR — registrar a denúncia',
    descricao: 'Plataforma do governo federal usada pela Ouvidoria da UFRJ para receber denúncias. Você pode anexar o dossiê gerado pelo Amparo.',
    categoria: 'UFRJ',
    site: 'https://falabr.cgu.gov.br',
    fonte: 'https://ouvidoria.ufrj.br/images/FINAL._Ouvidoria_como_instrumento_de_gestao.pdf',
  },
  {
    id: 'crm-ssa',
    nome: 'Centro de Referência para Mulheres Suely Souza de Almeida (CRM-SSA/UFRJ)',
    descricao:
      'Serviço da UFRJ (NEPP-DH) da rede de enfrentamento à violência contra as mulheres. Oferece atendimento psicossocial e jurídico a mulheres em situação de violência, inclusive encaminhadas pela Ouvidoria da Mulher.',
    categoria: 'UFRJ',
    endereco: 'Praça Jorge Machado Moreira — Cidade Universitária (Fundão)',
    fonte: 'https://ouvidoria.ufrj.br/images/A_UFRJ_das_Mulheres_CACO_set_25_versao_revisada1.pdf',
  },
  {
    id: 'disae',
    nome: 'DISAE — Divisão de Saúde do Estudante (PR7/UFRJ)',
    descricao:
      'Acolhimento em saúde e saúde mental para estudantes de graduação e pós, com encaminhamento para a rede interna ou externa. Não faz atendimento de urgência — nesses casos, procure o SUS.',
    categoria: 'APOIO',
    fonte: 'https://poli.ufrj.br/wp-content/uploads/2021/06/Cartilha_Disae.pdf',
  },
  {
    id: 'cvv-188',
    nome: 'CVV — Centro de Valorização da Vida',
    descricao: 'Apoio emocional e prevenção do suicídio, gratuito e sigiloso, por telefone ou chat.',
    categoria: 'APOIO',
    telefone: '188',
    site: 'https://cvv.org.br',
    horario: '24 horas',
    fonte: 'https://cvv.org.br',
  },
  {
    id: 'ceam',
    nome: 'CEAM — Centro Especializado de Atendimento à Mulher (Rio de Janeiro)',
    descricao: 'Atendimento psicológico, social e orientação jurídica para mulheres em situação de violência na capital.',
    categoria: 'APOIO',
    telefone: '(21) 2517-2726',
    whatsapp: '(21) 98555-2151',
    fonte: 'https://www.tjrj.jus.br/observatorio-judicial-violencia-mulher/denuncias/ouvidoria-mulher',
  },
  {
    id: 'nudem',
    nome: 'NUDEM — Defensoria Pública do Estado do RJ',
    descricao:
      'Núcleo Especializado de Defesa dos Direitos da Mulher e das Vítimas de Violência de Gênero. Orientação e assistência jurídica gratuitas. A Defensoria também atende pelo 129 e on-line.',
    categoria: 'JURIDICO',
    telefone: '129',
    email: 'nudem@defensoria.rj.def.br',
    site: 'https://defensoria.rj.def.br',
    endereco: 'Av. Marechal Câmara, 271, 7º andar — Centro, Rio de Janeiro',
    horario: 'Presencial: segunda a sexta, 10h às 16h',
    fonte: 'https://portaltj.tjrj.jus.br/carnaval-legal-e-com-respeito/tribunal-de-justica-na-marques-de-sapucai',
  },
  {
    id: 'delegacia-online',
    nome: 'Delegacia Online da Polícia Civil do RJ (inclui a DEAM Digital)',
    descricao:
      'Registro de ocorrência pela internet, 24 horas. Na DEAM Digital (violência doméstica e familiar) é possível enviar fotos e documentos e pedir medida protetiva. Também é possível ir a qualquer delegacia ou a uma DEAM.',
    categoria: 'POLICIA',
    site: 'https://dedic.pcivil.rj.gov.br',
    horario: '24 horas',
    fonte: 'https://agenciabrasil.ebc.com.br/radioagencia-nacional/geral/audio/2026-05/em-6-meses-delegacia-digital-da-mulher--do-rio-soma-15-mil-ocorrencias',
  },
];

export type Guia = {
  slug: string;
  titulo: string;
  resumo: string;
  categoria: 'ACOLHIMENTO' | 'PSICOLOGICA' | 'JURIDICA' | 'DENUNCIA';
  icone: string;
  tempoLeituraMin: number;
  corpo: string;
  fontes: string[];
};

export const GUIAS: Guia[] = [
  {
    slug: 'primeiros-passos',
    titulo: 'Primeiros passos depois de uma violência',
    resumo: 'O que fazer agora, no seu tempo. Você não precisa decidir tudo hoje.',
    categoria: 'ACOLHIMENTO',
    icone: 'heart',
    tempoLeituraMin: 4,
    corpo: `## Você não tem culpa
O que aconteceu não foi culpa sua — não importa a roupa, o horário, se você bebeu, se conhecia a pessoa ou se demorou para perceber. Sentir confusão, vergonha ou raiva é comum.

## 1. Sua segurança vem primeiro
- Se você corre perigo agora, ligue **190**.
- Se possível, vá para um lugar onde se sinta segura e chame alguém de confiança.
- O **Ligue 180** orienta 24 horas, por telefone ou WhatsApp **(61) 9610-0180**.

## 2. Se houve violência sexual: cuide da saúde o quanto antes
- Procure uma emergência do SUS assim que puder. **Você não precisa de boletim de ocorrência para ser atendida** — o atendimento integral às vítimas de violência sexual é obrigatório no SUS (Lei 12.845/2013).
- A profilaxia contra o HIV precisa começar em até **72 horas**; a contracepção de emergência é mais eficaz quanto antes for tomada.
- Se pensar em registrar ocorrência, evite tomar banho ou lavar as roupas antes do exame, se conseguir — guarde as roupas em saco de papel. Se já fez isso, tudo bem: ainda dá para denunciar.

## 3. Registre o que lembrar, enquanto está fresco
Use a aba **Denúncia** para anotar data, local, o que aconteceu, quem viu e como você se sentiu. Fica criptografado e só você vê — a não ser que decida compartilhar.

## 4. Você decide os próximos passos
Guardar o relato, denunciar na UFRJ, registrar ocorrência, buscar apoio psicológico — ou nada disso por enquanto. Todas as escolhas são válidas. Veja os outros guias quando se sentir pronta.`,
    fontes: [
      'https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2013/lei/l12845.htm',
      'https://agenciagov.ebc.com.br/noticias/202608/lei-maria-da-penha-como-funciona-a-central-de-atendimento-a-mulher-ligue-180',
    ],
  },
  {
    slug: 'guardar-provas',
    titulo: 'Como guardar provas',
    resumo: 'Prints, conversas, áudios e e-mails: como preservar sem perder valor.',
    categoria: 'DENUNCIA',
    icone: 'shield-checkmark',
    tempoLeituraMin: 5,
    corpo: `## Por que isso importa
Assédio e violência muitas vezes acontecem sem testemunhas. Mensagens, e-mails e anotações feitas na época ajudam a mostrar o que aconteceu — inclusive a repetição de comportamentos.

## Mensagens e redes sociais
- Faça **prints mostrando o nome/perfil de quem enviou, a data e a hora**.
- No WhatsApp, use também **Exportar conversa** (no menu da conversa) e guarde o arquivo.
- Copie o link do perfil e das publicações — eles podem ser apagados depois.
- Se o conteúdo puder sumir, uma **ata notarial** em cartório registra oficialmente o que está na tela.

## E-mails
Além do print, salve o e-mail original (no computador: "Baixar mensagem" / "Salvar como .eml"). O arquivo original guarda informações técnicas que o print não tem.

## Áudios e vídeos
Em geral, a gravação feita **por quem participa da conversa** é aceita como prova no Brasil. Confirme com orientação jurídica antes de usar.

## Testemunhas e diário
- Anote quem viu ou ouviu, ou com quem você conversou logo depois.
- Se a violência se repete, mantenha um diário com datas — a aba Denúncia serve para isso.

## Como o Amparo protege suas provas
- Cada arquivo é **criptografado** assim que chega ao servidor.
- O app calcula a **impressão digital (SHA-256)** do arquivo original e emite um **recibo assinado** com data e hora. Assim é possível mostrar depois que o arquivo não foi alterado.
- **Não edite** o arquivo original (cortar, filtrar, comprimir) antes de enviar — envie como está.
- Guarde também uma cópia fora do celular, se for seguro para você.`,
    fontes: [
      'https://ouvidoria.ufrj.br/images/apresentacao_GAM_-_18abr23.pdf',
      'https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2015/lei/l13105.htm',
    ],
  },
  {
    slug: 'denunciar-na-ufrj',
    titulo: 'Como denunciar na UFRJ',
    resumo: 'Ouvidoria da Mulher, Fala.BR e o que acontece depois.',
    categoria: 'DENUNCIA',
    icone: 'school',
    tempoLeituraMin: 4,
    corpo: `## O canal oficial
Na UFRJ, a denúncia formal é registrada na **Ouvidoria**, pelo sistema **Fala.BR** (falabr.cgu.gov.br). Casos de violência de gênero contam com a **Ouvidoria da Mulher**, que atende mulheres cis, trans e travestis — estudantes, servidoras, estagiárias e terceirizadas.

## Passo a passo
- Gere o **dossiê em PDF** do seu caso aqui no app (aba Denúncia → seu caso → Dossiê).
- Acesse o Fala.BR, escolha **Denúncia** e selecione a **UFRJ** como órgão.
- Descreva o que aconteceu (você pode copiar trechos do seu relato) e **anexe o dossiê** e as provas principais.
- Guarde o **número de protocolo** — anote no seu caso, na aba Denúncia.

## Identificada ou anônima?
- Você pode se identificar: a lei garante proteção dos seus dados e você consegue acompanhar o andamento e responder a pedidos de complemento.
- Uma denúncia sem identificação também é possível, mas aí não dá para acompanhar nem complementar informações — o que pode dificultar a apuração.

## O que acontece depois
A Ouvidoria faz uma análise inicial e encaminha à área responsável (por exemplo, a direção da unidade ou a corregedoria). Se precisar de apoio psicológico ou social durante o processo, a Ouvidoria pode encaminhar ao **Centro de Referência para Mulheres da UFRJ (CRM-SSA)**.

## A lei está do seu lado
A **Lei 14.540/2023** obriga órgãos públicos — incluindo universidades federais — a manter programas de prevenção e enfrentamento ao assédio sexual e à violência sexual.

## Quer ajuda para decidir?
Compartilhe seu caso com a **equipe de acolhimento** do Amparo (botão no seu caso). Ela pode orientar sobre como usar o dossiê.`,
    fontes: [
      'https://ouvidoria.ufrj.br/images/FINAL._Ouvidoria_como_instrumento_de_gestao.pdf',
      'https://ouvidoria.ufrj.br/images/Escola_de_Musica-_O_papel_da_Ouvidoria_da_Mulher_na_prevencao_de_violacoes_de_direitos_e_no_enfrentamento_a_violencia_contra_mulher_-_EM.pdf',
      'https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/lei/l14540.htm',
    ],
  },
  {
    slug: 'registrar-ocorrencia',
    titulo: 'Registrar ocorrência na polícia',
    resumo: 'DEAM, Delegacia Online e medidas protetivas.',
    categoria: 'JURIDICA',
    icone: 'document-text',
    tempoLeituraMin: 4,
    corpo: `## Onde registrar
- Em uma **DEAM** (Delegacia Especializada de Atendimento à Mulher) ou em qualquer delegacia.
- Pela **Delegacia Online** da Polícia Civil do RJ (dedic.pcivil.rj.gov.br), 24 horas. Para violência doméstica e familiar, a **DEAM Digital** permite enviar fotos e documentos e pedir medida protetiva.

## O que levar
- Documento de identidade.
- O **dossiê** do Amparo e as provas originais (o "pacote completo" traz os arquivos originais e um manifesto com os hashes).
- Nomes de testemunhas, se houver.

## Medidas protetivas
Se quem cometeu a violência é ou foi seu companheiro, namorado ou alguém com quem você teve relação íntima — mesmo que também seja da UFRJ — a **Lei Maria da Penha** pode se aplicar e você pode pedir **medidas protetivas de urgência**, como proibição de aproximação e de contato.

## Prazos
Alguns crimes só são investigados se a vítima autorizar (a chamada **representação**) — é o caso da perseguição (stalking). Nesses casos, o prazo costuma ser de **6 meses** a partir de quando você sabe quem é o autor. Na dúvida, procure a Defensoria logo.

## Você pode levar alguém
Você pode ir acompanhada de uma pessoa de confiança ou de uma advogada/defensora.`,
    fontes: [
      'https://www.cnj.jus.br/deam-digital-nova-ferramenta-auxilia-mulheres-vitimas-de-violencia-domestica/',
      'https://www.planalto.gov.br/ccivil_03/decreto-lei/del3689.htm',
      'https://www.planalto.gov.br/ccivil_03/_ato2004-2006/2006/lei/l11340.htm',
    ],
  },
  {
    slug: 'seus-direitos',
    titulo: 'Seus direitos: o que diz a lei',
    resumo: 'Assédio sexual, importunação, perseguição e violência psicológica.',
    categoria: 'JURIDICA',
    icone: 'library',
    tempoLeituraMin: 5,
    corpo: `> Conteúdo informativo. Não substitui a orientação de uma advogada ou da Defensoria Pública.

## Assédio sexual (Código Penal, art. 216-A)
Constranger alguém para obter vantagem sexual, aproveitando-se de posição de superioridade ou ascendência. O **STJ já decidiu que pode haver assédio sexual na relação entre professor e aluna**, porque o docente tem poder sobre notas e aprovação (REsp 1.759.135/SP).

## Importunação sexual (art. 215-A)
Praticar ato libidinoso contra alguém sem consentimento — por exemplo, toques, "encoxadas" ou se masturbar perto de alguém em transporte ou corredor.

## Perseguição / stalking (art. 147-A)
Perseguir alguém repetidamente — inclusive pela internet — ameaçando sua integridade ou invadindo sua liberdade e privacidade. A pena aumenta quando a vítima é perseguida por ser mulher.

## Violência psicológica contra a mulher (art. 147-B)
Causar dano emocional por meio de ameaça, humilhação, manipulação, isolamento, chantagem, ridicularização ou outras formas que prejudiquem a saúde psicológica e a autodeterminação.

## Divulgação de imagens íntimas sem consentimento (art. 218-C)
Divulgar foto ou vídeo de nudez ou sexo sem autorização é crime.

## Assédio moral
Humilhações e perseguições repetidas no ambiente de estudo ou trabalho. Pode gerar punição disciplinar de servidores e indenização, e deve ser denunciado à Ouvidoria.

## Na universidade
A **Lei 14.540/2023** obriga a administração pública — incluindo universidades federais — a prevenir e enfrentar o assédio sexual e a violência sexual.`,
    fontes: [
      'https://www.planalto.gov.br/ccivil_03/decreto-lei/del2848compilado.htm',
      'https://scon.stj.jus.br/SCON/GetPDFSelecaoJT?selecao_edicao=152',
      'https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2023/lei/l14540.htm',
    ],
  },
  {
    slug: 'saude-mental',
    titulo: 'Cuidando de você',
    resumo: 'Reações comuns, como se acolher e onde buscar apoio psicológico.',
    categoria: 'PSICOLOGICA',
    icone: 'leaf',
    tempoLeituraMin: 4,
    corpo: `## Reações comuns
Depois de uma violência, é comum sentir medo, culpa, raiva, vergonha, tristeza, dificuldade para dormir ou se concentrar, ou sentir-se "anestesiada". Não existe jeito certo de reagir. Essas reações costumam diminuir com tempo e apoio.

## Para momentos difíceis
- **Respiração lenta:** inspire contando até 4, segure até 4, solte contando até 6. Repita algumas vezes.
- **Voltar ao presente:** nomeie 5 coisas que você vê, 4 que pode tocar, 3 que ouve, 2 cheiros e 1 gosto.
- **Fale com alguém** em quem confia. Você não precisa contar tudo.
- Respeite seu ritmo nas aulas e prazos — você pode pedir apoio à coordenação do curso.

## Onde buscar apoio
- **DISAE / PR7** — acolhimento para estudantes de graduação e pós da UFRJ.
- **CRM-SSA (UFRJ)** — atendimento psicossocial para mulheres em situação de violência.
- **CEAM** — atendimento psicológico e social na capital.
- **CVV — 188** — apoio emocional 24 horas, gratuito.
- **CAPS** e unidades de saúde do SUS da sua região.

## Se a dor ficar grande demais
Se você pensar em se machucar ou em não estar mais aqui, ligue **188** (CVV) ou **192** (SAMU), ou vá a uma emergência. Você merece cuidado — e há pessoas prontas para ouvir.`,
    fontes: ['https://poli.ufrj.br/wp-content/uploads/2021/06/Cartilha_Disae.pdf', 'https://cvv.org.br'],
  },
  {
    slug: 'usar-dossie',
    titulo: 'Como usar o seu dossiê',
    resumo: 'O que vai no PDF, como conferir as provas e onde entregar.',
    categoria: 'DENUNCIA',
    icone: 'folder-open',
    tempoLeituraMin: 3,
    corpo: `## O que é o dossiê
Um PDF que organiza o seu relato, a linha do tempo, as pessoas envolvidas e a lista de provas — cada uma com a **impressão digital (SHA-256)**, a data e hora em que chegou ao Amparo e um **recibo assinado digitalmente**.

## Dossiê ou pacote completo?
- **Dossiê (PDF):** para ler, imprimir e anexar no Fala.BR.
- **Pacote completo (ZIP):** o dossiê + os **arquivos originais** das provas + um manifesto com os hashes. Use quando pedirem os originais (delegacia, Defensoria, advogada).

## Onde entregar
- **Ouvidoria da UFRJ (Fala.BR):** anexe o PDF ao registrar a denúncia.
- **Delegacia / Delegacia Online:** leve o PDF e o pacote.
- **Defensoria (NUDEM) ou advogada:** mostre o dossiê no primeiro atendimento; ajuda a contar a história sem precisar repetir tudo.

## Antes de entregar
- Releia o relato e complete o que faltar — você pode editar quando quiser e gerar o dossiê de novo.
- O dossiê contém informações sensíveis: **não publique** e envie só para canais oficiais ou pessoas de confiança.

## Como alguém confere as provas
Quem receber os arquivos pode calcular o SHA-256 de cada um (no Windows: \`certutil -hashfile arquivo SHA256\`; no Mac/Linux: \`shasum -a 256 arquivo\`) e comparar com o dossiê. Se for igual, o arquivo é idêntico ao que você guardou no Amparo.`,
    fontes: [],
  },
  {
    slug: 'apoiar-amiga',
    titulo: 'Como apoiar uma amiga',
    resumo: 'O que dizer (e o que evitar) quando alguém confia em você.',
    categoria: 'ACOLHIMENTO',
    icone: 'people',
    tempoLeituraMin: 3,
    corpo: `## Ouça e acredite
- "Eu acredito em você." "Não foi culpa sua." "Obrigada por me contar."
- Deixe que ela conte no tempo dela. Não precisa de detalhes.

## Evite
- Perguntas que culpam: "Mas por que você estava lá?", "Por que não reagiu?"
- Pressionar para denunciar — a decisão é dela.
- Contar para outras pessoas ou expor o caso nas redes sem autorização.

## Ajude de forma prática
- Ofereça companhia para ir à Ouvidoria, à delegacia ou a um atendimento de saúde.
- Mostre os guias e contatos deste app.
- Cuide de você também: ouvir relatos de violência pesa.`,
    fontes: [],
  },
];

/** Texto curto impresso na última página do dossiê. */
export const ORIENTACOES_DOSSIE = [
  'Ouvidoria da UFRJ (Ouvidoria da Mulher): registre a denúncia em falabr.cgu.gov.br, escolha a UFRJ como órgão e anexe este PDF. Informações: ouvidoria.ufrj.br.',
  'Polícia: em uma DEAM, em qualquer delegacia ou pela Delegacia Online da Polícia Civil do RJ (dedic.pcivil.rj.gov.br). Leve também o pacote com os arquivos originais.',
  'Orientação jurídica gratuita: Defensoria Pública do RJ — NUDEM (nudem@defensoria.rj.def.br) ou telefone 129.',
  'Apoio psicossocial: Centro de Referência para Mulheres Suely Souza de Almeida (CRM-SSA/UFRJ), DISAE/PR7, CEAM (21) 2517-2726. Emergência: 190. Ligue 180 (24h).',
  'Alguns crimes (como perseguição) dependem de autorização da vítima, com prazo de 6 meses a partir de quando ela sabe quem é o autor. Procure orientação jurídica logo.',
];
