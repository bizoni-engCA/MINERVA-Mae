import { config, isTest } from '../config';
import { logger } from './logger';

export type Email = { para: string; assunto: string; texto: string };

/**
 * No MVP os e-mails são só impressos no terminal.
 * Para envio real, defina SMTP_URL e instale o nodemailer (ver README → "Indo para produção").
 */
export async function enviarEmail(email: Email) {
  if (config.SMTP_URL) {
    try {
      // Importação dinâmica para não exigir a dependência no MVP.
      const nome = 'nodemailer';
      const nodemailer = (await import(nome)) as {
        createTransport: (url: string) => { sendMail: (o: Record<string, string>) => Promise<unknown> };
      };
      await nodemailer.createTransport(config.SMTP_URL).sendMail({
        from: config.EMAIL_REMETENTE,
        to: email.para,
        subject: email.assunto,
        text: email.texto,
      });
      return;
    } catch (e) {
      logger.error({ err: e }, 'Falha ao enviar e-mail via SMTP');
      throw e;
    }
  }
  if (!isTest) {
    logger.info(`\n📧 E-mail (simulado) para ${email.para}\n   Assunto: ${email.assunto}\n   ${email.texto.replace(/\n/g, '\n   ')}\n`);
  }
}
