import { z, type ZodType } from 'zod';
import { HttpError } from './errors';

z.config(z.locales.ptBR());

export { z };

export function validar<T extends ZodType>(schema: T, dados: unknown): z.infer<T> {
  const r = schema.safeParse(dados);
  if (!r.success) {
    const issue = r.error.issues[0];
    const campo = issue?.path.join('.');
    throw new HttpError(400, campo ? `${campo}: ${issue.message}` : (issue?.message ?? 'Dados inválidos'), 'DADOS_INVALIDOS');
  }
  return r.data;
}

export const uuid = z.uuid('Identificador inválido');
export const paginacao = z.object({
  cursor: z.string().optional(),
  limite: z.coerce.number().int().min(1).max(50).default(20),
});

/** Cursor = data ISO do último item; simples e estável para feeds em ordem cronológica. */
export const lerCursor = (cursor?: string) => {
  if (!cursor) return undefined;
  const d = new Date(cursor);
  return Number.isNaN(d.getTime()) ? undefined : d;
};
