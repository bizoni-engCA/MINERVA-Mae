/** Apaga TODOS os dados e arquivos. Só para desenvolvimento. */
import { rm } from 'node:fs/promises';
import { sql } from 'drizzle-orm';
import { isProd } from '../config';
import { storage } from '../lib/storage';
import { db, pool } from './index';

if (isProd) {
  console.error('Recusado: NODE_ENV=production.');
  process.exit(1);
}
await db.execute(sql`drop schema if exists public cascade; create schema public; drop schema if exists drizzle cascade;`);
await rm(storage.raiz, { recursive: true, force: true });
console.log('🧹 Banco e arquivos apagados. Rode "npm run setup" para recriar.');
await pool.end();
