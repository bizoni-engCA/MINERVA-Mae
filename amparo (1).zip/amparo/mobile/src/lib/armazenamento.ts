import { Platform } from 'react-native';
import * as SecureStore from 'expo-secure-store';

/**
 * Guarda dados no cofre do sistema (Keychain no iOS, Keystore no Android).
 * Na versão web (só para testes), usa o localStorage.
 */
export const armazenamento = {
  async ler<T>(chave: string): Promise<T | null> {
    try {
      const bruto = Platform.OS === 'web' ? globalThis.localStorage?.getItem(chave) : await SecureStore.getItemAsync(chave);
      return bruto ? (JSON.parse(bruto) as T) : null;
    } catch {
      return null;
    }
  },
  async gravar(chave: string, valor: unknown) {
    const texto = JSON.stringify(valor);
    if (Platform.OS === 'web') globalThis.localStorage?.setItem(chave, texto);
    else await SecureStore.setItemAsync(chave, texto, { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY });
  },
  async apagar(chave: string) {
    if (Platform.OS === 'web') globalThis.localStorage?.removeItem(chave);
    else await SecureStore.deleteItemAsync(chave);
  },
};
