import { mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import multer from 'multer';
import { config } from '../config';
import { HttpError } from '../lib/errors';
import { randomUUID } from 'node:crypto';

const PASTA_TEMP = join(tmpdir(), 'amparo-uploads');
mkdirSync(PASTA_TEMP, { recursive: true, mode: 0o700 });

const armazenamento = multer.diskStorage({
  destination: PASTA_TEMP,
  filename: (_req, _file, cb) => cb(null, randomUUID()),
});

export const MIMES_VIDEO = ['video/mp4', 'video/quicktime', 'video/webm', 'video/3gpp', 'video/x-m4v'];

export const MIMES_PROVA = [
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/heic',
  'image/heif',
  'image/gif',
  'video/mp4',
  'video/quicktime',
  'video/webm',
  'video/3gpp',
  'audio/mpeg',
  'audio/mp4',
  'audio/m4a',
  'audio/x-m4a',
  'audio/aac',
  'audio/ogg',
  'audio/opus',
  'audio/wav',
  'audio/x-wav',
  'audio/webm',
  'audio/3gpp',
  'application/pdf',
  'text/plain',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/zip',
  'message/rfc822',
  'application/octet-stream',
];

const filtro = (permitidos: string[]): multer.Options['fileFilter'] => (_req, file, cb) => {
  if (permitidos.includes(file.mimetype)) cb(null, true);
  else cb(new HttpError(415, `Tipo de arquivo não aceito (${file.mimetype}).`, 'TIPO_NAO_ACEITO'));
};

export const uploadVideo = multer({
  storage: armazenamento,
  limits: { fileSize: config.MAX_VIDEO_MB * 1024 * 1024, files: 1, fields: 10 },
  fileFilter: filtro(MIMES_VIDEO),
}).single('arquivo');

export const uploadProva = multer({
  storage: armazenamento,
  limits: { fileSize: config.MAX_PROVA_MB * 1024 * 1024, files: 1, fields: 10 },
  fileFilter: filtro(MIMES_PROVA),
}).single('arquivo');

/** Campos multipart chegam como texto. */
export const textoParaBool = (v: unknown) => v === true || v === 'true' || v === '1';
