import { createHash, randomBytes } from 'node:crypto';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { beforeAll, describe, expect, it } from 'vitest';
import { api, cadastrar } from './helpers';

let dona: Awaited<ReturnType<typeof cadastrar>>;
let outra: Awaited<ReturnType<typeof cadastrar>>;
let acolhe: Awaited<ReturnType<typeof cadastrar>>;
let mod: Awaited<ReturnType<typeof cadastrar>>;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const binario = (res: any, cb: (e: Error | null, b: Buffer) => void) => {
  const partes: Buffer[] = [];
  res.on('data', (c: Buffer) => partes.push(c));
  res.on('end', () => cb(null, Buffer.concat(partes)));
};

// PNG 1x1 válido (para testar a imagem embutida no dossiê)
const PNG = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
  'base64',
);

beforeAll(async () => {
  dona = await cadastrar('dona.do.caso');
  outra = await cadastrar('curiosa');
  acolhe = await cadastrar('acolhe.teste', 'ACOLHIMENTO');
  mod = await cadastrar('mod.casos', 'MODERADORA');
});

describe('casos, provas e dossiê', () => {
  it('fluxo completo', async () => {
    const criado = await api().post('/api/casos').set(dona.auth).send({
      titulo: 'Episódios no estágio',
      relato: 'O supervisor fazia comentários sobre meu corpo e me isolava das reuniões. Emoji não quebra o PDF 💜.',
      tiposViolencia: ['ASSEDIO_SEXUAL', 'ASSEDIO_MORAL'],
      vinculoAutor: 'DOCENTE',
      pessoasEnvolvidas: 'Supervisor do estágio (nome completo aqui).',
    });
    expect(criado.status).toBe(201);
    const id = criado.body.id;

    // Ninguém mais acessa — nem a equipe enquanto não for compartilhado
    expect((await api().get(`/api/casos/${id}`).set(outra.auth)).status).toBe(404);
    expect((await api().get(`/api/casos/${id}`).set(acolhe.auth)).status).toBe(404);
    expect((await api().get(`/api/casos/${id}`).set(mod.auth)).status).toBe(404);

    // Prova: hash confere e o arquivo fica criptografado no disco
    const conteudo = randomBytes(64 * 1024);
    const sha = createHash('sha256').update(conteudo).digest('hex');
    const prova = await api()
      .post(`/api/casos/${id}/provas`)
      .set(dona.auth)
      .field('descricao', 'Áudio da reunião')
      .field('sha256Cliente', sha)
      .attach('arquivo', conteudo, { filename: 'reuniao.m4a', contentType: 'audio/mp4' });
    expect(prova.status).toBe(201);
    expect(prova.body.sha256).toBe(sha);

    const pasta = join(process.env.STORAGE_DIR!, 'provas', id);
    const noDisco = readFileSync(join(pasta, readdirSync(pasta)[0]));
    expect(noDisco.equals(conteudo)).toBe(false);
    expect(statSync(join(pasta, readdirSync(pasta)[0])).size).toBe(conteudo.length);

    // Hash divergente é recusado
    const divergente = await api()
      .post(`/api/casos/${id}/provas`)
      .set(dona.auth)
      .field('sha256Cliente', 'a'.repeat(64))
      .attach('arquivo', Buffer.from('oi'), { filename: 'x.txt', contentType: 'text/plain' });
    expect(divergente.status).toBe(422);

    // Tipo não aceito
    const exe = await api()
      .post(`/api/casos/${id}/provas`)
      .set(dona.auth)
      .attach('arquivo', Buffer.from('MZ'), { filename: 'x.exe', contentType: 'application/x-msdownload' });
    expect(exe.status).toBe(415);

    await api()
      .post(`/api/casos/${id}/provas`)
      .set(dona.auth)
      .attach('arquivo', PNG, { filename: 'print.png', contentType: 'image/png' });

    // Download devolve o original idêntico
    const baixado = await api().get(`/api/casos/${id}/provas/${prova.body.id}/arquivo`).set(dona.auth).buffer(true).parse(binario);
    expect(baixado.status).toBe(200);
    expect(createHash('sha256').update(baixado.body as Buffer).digest('hex')).toBe(sha);

    // Recibo assinado é verificável publicamente
    const ok = await api().post('/api/integridade/verificar-recibo').send({
      provaId: prova.body.id,
      casoId: id,
      sha256: sha,
      tamanhoBytes: conteudo.length,
      recebidoEm: new Date(prova.body.recebidoEm).toISOString(),
      assinatura: prova.body.assinatura,
    });
    expect(ok.body.valido).toBe(true);
    const adulterado = await api().post('/api/integridade/verificar-recibo').send({
      provaId: prova.body.id,
      casoId: id,
      sha256: 'b'.repeat(64),
      tamanhoBytes: conteudo.length,
      recebidoEm: new Date(prova.body.recebidoEm).toISOString(),
      assinatura: prova.body.assinatura,
    });
    expect(adulterado.body.valido).toBe(false);

    // Dossiê PDF
    const pdf = await api().get(`/api/casos/${id}/dossie.pdf`).set(dona.auth).buffer(true).parse(binario);
    expect(pdf.status).toBe(200);
    expect((pdf.body as Buffer).subarray(0, 4).toString()).toBe('%PDF');

    // Pacote ZIP
    const zip = await api().get(`/api/casos/${id}/pacote.zip`).set(dona.auth).buffer(true).parse(binario);
    expect(zip.status).toBe(200);
    expect((zip.body as Buffer).subarray(0, 2).toString()).toBe('PK');

    // Compartilhar exige consentimento explícito
    expect((await api().post(`/api/casos/${id}/compartilhar`).set(dona.auth).send({})).status).toBe(400);
    const comp = await api()
      .post(`/api/casos/${id}/compartilhar`)
      .set(dona.auth)
      .send({ consentimento: true, mensagem: 'Gostaria de orientação para levar à Ouvidoria.' });
    expect(comp.body.status).toBe('COMPARTILHADO');

    // Acolhimento vê; moderação continua sem acesso
    const fila = await api().get('/api/equipe/casos?filtro=aguardando').set(acolhe.auth);
    expect(fila.body.some((c: { id: string }) => c.id === id)).toBe(true);
    expect((await api().get('/api/equipe/casos').set(mod.auth)).status).toBe(403);
    expect((await api().get(`/api/casos/${id}`).set(mod.auth)).status).toBe(404);

    const visto = await api().get(`/api/casos/${id}`).set(acolhe.auth);
    expect(visto.body.dados.relato).toContain('supervisor');
    await api().post(`/api/equipe/casos/${id}/assumir`).set(acolhe.auth);
    await api().post(`/api/casos/${id}/mensagens`).set(acolhe.auth).send({ corpo: 'Oi! Estou com seu caso. Vamos conversar sobre os próximos passos.' });
    await api().get(`/api/casos/${id}/provas/${prova.body.id}/arquivo`).set(acolhe.auth);

    // A dona vê tudo o que a equipe fez (transparência)
    const daDona = await api().get(`/api/casos/${id}`).set(dona.auth);
    expect(daDona.body.status).toBe('EM_ACOMPANHAMENTO');
    expect(daDona.body.mensagens.at(-1).daEquipe).toBe(true);
    const tipos = daDona.body.eventos.map((e: { tipo: string }) => e.tipo);
    expect(tipos).toEqual(expect.arrayContaining(['VISUALIZADO_PELA_EQUIPE', 'ASSUMIDO', 'PROVA_ACESSADA_PELA_EQUIPE']));

    // Edição do relato só pela dona
    expect((await api().patch(`/api/casos/${id}`).set(acolhe.auth).send({ relato: 'x' })).status).toBe(404);

    // Revogar corta o acesso da equipe
    await api().post(`/api/casos/${id}/revogar-compartilhamento`).set(dona.auth);
    expect((await api().get(`/api/casos/${id}`).set(acolhe.auth)).status).toBe(404);

    // Lista de casos da dona
    const lista = await api().get('/api/casos').set(dona.auth);
    expect(lista.body[0]).toMatchObject({ id, titulo: 'Episódios no estágio', totalProvas: 2 });
  });

  it('exclusão da conta apaga casos e arquivos', async () => {
    const temp = await cadastrar('vai.sair');
    const caso = await api().post('/api/casos').set(temp.auth).send({ titulo: 'Caso temporário' });
    await api()
      .post(`/api/casos/${caso.body.id}/provas`)
      .set(temp.auth)
      .attach('arquivo', Buffer.from('prova'), { filename: 'p.txt', contentType: 'text/plain' });
    const pasta = join(process.env.STORAGE_DIR!, 'provas', caso.body.id);
    expect(readdirSync(pasta)).toHaveLength(1);

    expect((await api().delete('/api/eu').set(temp.auth).send({ senha: 'errada' })).status).toBe(400);
    expect((await api().delete('/api/eu').set(temp.auth).send({ senha: 'senha-segura-123' })).status).toBe(204);
    expect(readdirSync(pasta)).toHaveLength(0);
    expect((await api().get('/api/eu').set(temp.auth)).status).toBe(401);
  });
});
