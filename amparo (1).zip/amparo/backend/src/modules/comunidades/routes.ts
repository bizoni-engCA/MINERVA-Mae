import { Router } from 'express';
import { and, asc, eq, sql } from 'drizzle-orm';
import { db, schema } from '../../db';
import { naoEncontrado } from '../../lib/errors';
import { lerCursor, paginacao, uuid, validar, z } from '../../lib/validar';
import { eu, exigirLogin, exigirPapel } from '../../middleware/auth';
import { registrarAuditoria } from '../equipe/auditoria';
import { buscarPosts, postPublicado } from '../posts/consultas';

export const comunidadesRouter = Router();
comunidadesRouter.use(exigirLogin);

const { comunidades, membrosComunidade, posts } = schema;

const colunas = (usuariaId: string) => ({
  id: comunidades.id,
  slug: comunidades.slug,
  nome: comunidades.nome,
  descricao: comunidades.descricao,
  regras: comunidades.regras,
  icone: comunidades.icone,
  cor: comunidades.cor,
  membros: sql<number>`(select count(*)::int from membros_comunidade m where m.comunidade_id = "comunidades"."id")`,
  relatos: sql<number>`(select count(*)::int from posts p where p.comunidade_id = "comunidades"."id" and p.status = 'PUBLICADO' and p.visibilidade = 'PUBLICO')`,
  souMembro: sql<boolean>`exists(select 1 from membros_comunidade m where m.comunidade_id = "comunidades"."id" and m.usuaria_id = ${usuariaId})`,
});

comunidadesRouter.get('/', async (req, res) => {
  const lista = await db
    .select(colunas(eu(req).id))
    .from(comunidades)
    .where(eq(comunidades.ativa, true))
    .orderBy(asc(comunidades.nome));
  res.json(lista);
});

comunidadesRouter.get('/:slug', async (req, res) => {
  const [c] = await db
    .select(colunas(eu(req).id))
    .from(comunidades)
    .where(and(eq(comunidades.slug, req.params.slug), eq(comunidades.ativa, true)));
  if (!c) throw naoEncontrado('Comunidade');
  res.json(c);
});

comunidadesRouter.get('/:id/posts', async (req, res) => {
  const id = validar(uuid, req.params.id);
  const { cursor, limite } = validar(paginacao, req.query);
  const itens = await buscarPosts({
    onde: and(eq(posts.comunidadeId, id), postPublicado),
    usuariaId: eu(req).id,
    limite,
    cursor: lerCursor(cursor),
  });
  res.json({ itens, proximoCursor: itens.length === limite ? itens.at(-1)?.publicadoEm : null });
});

comunidadesRouter.post('/:id/participar', async (req, res) => {
  const id = validar(uuid, req.params.id);
  await db.insert(membrosComunidade).values({ usuariaId: eu(req).id, comunidadeId: id }).onConflictDoNothing();
  res.status(204).end();
});

comunidadesRouter.delete('/:id/participar', async (req, res) => {
  const id = validar(uuid, req.params.id);
  await db
    .delete(membrosComunidade)
    .where(and(eq(membrosComunidade.usuariaId, eu(req).id), eq(membrosComunidade.comunidadeId, id)));
  res.status(204).end();
});

// ── Gestão (moderação) ────────────────────────────────────────────
const comunidadeSchema = z.object({
  nome: z.string().trim().min(3).max(64),
  slug: z
    .string()
    .trim()
    .toLowerCase()
    .regex(/^[a-z0-9-]{3,48}$/, 'Use letras minúsculas, números e hífen'),
  descricao: z.string().trim().min(10).max(500),
  regras: z.string().trim().max(2000).optional(),
  icone: z.string().max(32).optional(),
  cor: z
    .string()
    .regex(/^#[0-9a-fA-F]{6}$/)
    .optional(),
});

comunidadesRouter.post('/', exigirPapel('MODERADORA'), async (req, res) => {
  const dados = validar(comunidadeSchema, req.body);
  const [c] = await db.insert(comunidades).values({ ...dados, criadaPorId: eu(req).id }).returning();
  await registrarAuditoria(eu(req).id, 'COMUNIDADE_CRIADA', 'COMUNIDADE', c.id, { nome: c.nome });
  res.status(201).json(c);
});

comunidadesRouter.patch('/:id', exigirPapel('MODERADORA'), async (req, res) => {
  const id = validar(uuid, req.params.id);
  const dados = validar(comunidadeSchema.partial().extend({ ativa: z.boolean().optional() }), req.body);
  const [c] = await db.update(comunidades).set(dados).where(eq(comunidades.id, id)).returning();
  if (!c) throw naoEncontrado('Comunidade');
  await registrarAuditoria(eu(req).id, 'COMUNIDADE_EDITADA', 'COMUNIDADE', c.id, dados);
  res.json(c);
});
