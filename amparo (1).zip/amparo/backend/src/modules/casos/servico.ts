import { createReadStream } from 'node:fs';
import { PassThrough } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { createHash, randomUUID } from 'node:crypto';
import { and, asc, desc, eq, gt, sql } from 'drizzle-orm';
import { db, schema } from '../../db';
import type { Usuaria } from '../../db/schema';
import {
  abrirDek,
  assinarRecibo,
  cifrarJson,
  criarCifradorArquivo,
  decifrarJson,
  decifrarTexto,
  gerarDek,
  protegerDek,
} from '../../lib/crypto';
import { storage } from '../../lib/storage';
import { naoEncontrado } from '../../lib/errors';
import { validar, z } from '../../lib/validar';
import { registrarEventoCaso } from '../equipe/auditoria';

export const TIPOS_VIOLENCIA = {
  ASSEDIO_SEXUAL: 'Assédio sexual',
  IMPORTUNACAO_SEXUAL: 'Importunação sexual',
  VIOLENCIA_SEXUAL: 'Violência sexual / estupro',
  ASSEDIO_MORAL: 'Assédio moral',
  VIOLENCIA_PSICOLOGICA: 'Violência psicológica',
  VIOLENCIA_FISICA: 'Violência física',
  PERSEGUICAO: 'Perseguição (stalking)',
  VIOLENCIA_DIGITAL: 'Violência digital / exposição online',
  DISCRIMINACAO: 'Discriminação (gênero, raça, LGBTfobia…)',
  OUTRA: 'Outra',
} as const;

export const VINCULOS_AUTOR = {
  DOCENTE: 'Docente',
  ESTUDANTE: 'Estudante',
  TECNICO: 'Técnico(a)-administrativo(a)',
  TERCEIRIZADO: 'Terceirizado(a)',
  EXTERNO: 'Pessoa de fora da UFRJ',
  NAO_SEI: 'Não sei / prefiro não dizer',
} as const;

export const dadosCasoSchema = z.object({
  titulo: z.string().trim().min(3, 'Dê um título para você reconhecer o caso').max(120),
  relato: z.string().trim().max(30000).default(''),
  dataOcorrido: z.string().trim().max(40).optional(),
  periodo: z.string().trim().max(200).optional(),
  local: z.string().trim().max(300).optional(),
  tiposViolencia: z.array(z.enum(Object.keys(TIPOS_VIOLENCIA) as [keyof typeof TIPOS_VIOLENCIA])).max(10).default([]),
  vinculoAutor: z.enum(Object.keys(VINCULOS_AUTOR) as [keyof typeof VINCULOS_AUTOR]).optional(),
  pessoasEnvolvidas: z.string().trim().max(3000).optional(),
  testemunhas: z.string().trim().max(3000).optional(),
  impactos: z.string().trim().max(5000).optional(),
  providenciasTomadas: z.string().trim().max(5000).optional(),
  observacoes: z.string().trim().max(5000).optional(),
});

export type DadosCaso = z.infer<typeof dadosCasoSchema>;
export type MetaProva = { nomeOriginal: string; descricao?: string; dataCaptura?: string };

export const ehAcolhimento = (u: Usuaria) => u.papel === 'ACOLHIMENTO' || u.papel === 'ADMIN';

export async function criarCaso(donaId: string, dados: DadosCaso) {
  const dek = gerarDek();
  const [caso] = await db
    .insert(schema.casos)
    .values({ donaId, chaveProtegida: protegerDek(dek), dadosEnc: cifrarJson(dados, dek) })
    .returning();
  await registrarEventoCaso(caso.id, 'CRIADO', { atorId: donaId });
  return caso;
}

/**
 * Carrega um caso respeitando o acesso:
 *  - a dona sempre;
 *  - acolhimento/admin só se o caso estiver compartilhado;
 *  - moderadoras NÃO têm acesso a casos.
 */
export async function carregarCaso(id: string, usuaria: Usuaria, opts: { soDona?: boolean } = {}) {
  validar(z.uuid(), id);
  const [caso] = await db.select().from(schema.casos).where(eq(schema.casos.id, id));
  if (!caso) throw naoEncontrado('Caso');
  const souDona = caso.donaId === usuaria.id;
  const acessoEquipe = !souDona && !opts.soDona && ehAcolhimento(usuaria) && caso.compartilhadoEm !== null;
  if (!souDona && !acessoEquipe) throw naoEncontrado('Caso');
  const dek = abrirDek(caso.chaveProtegida);
  return { caso, dek, souDona, acessoEquipe, dados: decifrarJson<DadosCaso>(caso.dadosEnc, dek) };
}

export async function listarProvas(casoId: string, dek: Buffer) {
  const lista = await db.select().from(schema.provas).where(eq(schema.provas.casoId, casoId)).orderBy(asc(schema.provas.recebidoEm));
  return lista.map((p) => ({
    id: p.id,
    tipo: p.tipo,
    mimeType: p.mimeType,
    tamanhoBytes: p.tamanhoBytes,
    sha256: p.sha256,
    recebidoEm: p.recebidoEm,
    assinatura: p.assinatura,
    ...decifrarJson<MetaProva>(p.metaEnc, dek),
  }));
}

export async function listarMensagens(casoId: string, dek: Buffer, leitoraId?: string) {
  const lista = await db
    .select({
      id: schema.mensagensCaso.id,
      autoraId: schema.mensagensCaso.autoraId,
      daEquipe: schema.mensagensCaso.daEquipe,
      corpoEnc: schema.mensagensCaso.corpoEnc,
      criadoEm: schema.mensagensCaso.criadoEm,
      apelido: schema.usuarias.apelido,
    })
    .from(schema.mensagensCaso)
    .leftJoin(schema.usuarias, eq(schema.usuarias.id, schema.mensagensCaso.autoraId))
    .where(eq(schema.mensagensCaso.casoId, casoId))
    .orderBy(asc(schema.mensagensCaso.criadoEm));
  return lista.map((m) => ({
    id: m.id,
    daEquipe: m.daEquipe,
    minha: Boolean(leitoraId && m.autoraId === leitoraId),
    autoria: m.daEquipe
      ? `Equipe de acolhimento${m.apelido ? ` · ${m.apelido}` : ''}`
      : leitoraId && m.autoraId === leitoraId
        ? 'Você'
        : 'Estudante',
    corpo: decifrarTexto(m.corpoEnc, dek),
    criadoEm: m.criadoEm,
  }));
}

export async function listarEventos(casoId: string) {
  const lista = await db
    .select({
      id: schema.eventosCaso.id,
      tipo: schema.eventosCaso.tipo,
      daEquipe: schema.eventosCaso.daEquipe,
      detalhe: schema.eventosCaso.detalhe,
      criadoEm: schema.eventosCaso.criadoEm,
      apelido: schema.usuarias.apelido,
    })
    .from(schema.eventosCaso)
    .leftJoin(schema.usuarias, eq(schema.usuarias.id, schema.eventosCaso.atorId))
    .where(eq(schema.eventosCaso.casoId, casoId))
    .orderBy(desc(schema.eventosCaso.criadoEm));
  // O apelido só aparece para ações da equipe — a estudante nunca é identificada para a equipe.
  return lista.map((e) => ({ ...e, apelido: e.daEquipe ? e.apelido : null }));
}

/** Registra que alguém da equipe abriu o caso (no máximo 1 registro a cada 30 min por pessoa). */
export async function registrarVisualizacaoEquipe(casoId: string, atorId: string) {
  const [recente] = await db
    .select({ id: schema.eventosCaso.id })
    .from(schema.eventosCaso)
    .where(
      and(
        eq(schema.eventosCaso.casoId, casoId),
        eq(schema.eventosCaso.atorId, atorId),
        eq(schema.eventosCaso.tipo, 'VISUALIZADO_PELA_EQUIPE'),
        gt(schema.eventosCaso.criadoEm, new Date(Date.now() - 30 * 60 * 1000)),
      ),
    );
  if (!recente) await registrarEventoCaso(casoId, 'VISUALIZADO_PELA_EQUIPE', { atorId, daEquipe: true });
}

export const resumoCaso = (caso: typeof schema.casos.$inferSelect, dados: DadosCaso) => ({
  id: caso.id,
  titulo: dados.titulo,
  tiposViolencia: dados.tiposViolencia,
  status: caso.status,
  compartilhadoEm: caso.compartilhadoEm,
  criadoEm: caso.criadoEm,
  atualizadoEm: caso.atualizadoEm,
});

export const contarProvas = (casoId: string) =>
  db
    .select({ n: sql<number>`count(*)::int` })
    .from(schema.provas)
    .where(eq(schema.provas.casoId, casoId))
    .then((r) => r[0]?.n ?? 0);

export const tipoProva = (mime: string) =>
  mime.startsWith('image/')
    ? 'IMAGEM'
    : mime.startsWith('video/')
      ? 'VIDEO'
      : mime.startsWith('audio/')
        ? 'AUDIO'
        : /pdf|text|word|document|sheet|excel|rfc822/.test(mime)
          ? 'DOCUMENTO'
          : 'OUTRO';

/**
 * Guarda uma prova: calcula o SHA-256 do original e criptografa (AES-256-GCM,
 * chave própria) numa única passada, depois emite o recibo assinado.
 */
export async function armazenarProva(p: {
  casoId: string;
  dekCaso: Buffer;
  caminhoArquivo: string;
  mimeType: string;
  tamanhoBytes: number;
  meta: MetaProva;
  atorId: string;
}) {
  const provaId = randomUUID();
  const chave = `provas/${p.casoId}/${provaId}.bin`;
  const dek = gerarDek();
  const { iv, cifrador } = criarCifradorArquivo(dek);
  const hash = createHash('sha256');
  const contador = new PassThrough();
  contador.on('data', (pedaco: Buffer) => hash.update(pedaco));
  await pipeline(createReadStream(p.caminhoArquivo), contador, cifrador, await storage.abrirEscrita(chave));
  const sha256 = hash.digest('hex');

  const recebidoEm = new Date();
  const assinatura = assinarRecibo({
    provaId,
    casoId: p.casoId,
    sha256,
    tamanhoBytes: p.tamanhoBytes,
    recebidoEm: recebidoEm.toISOString(),
  });
  const tipo = tipoProva(p.mimeType);

  await db.insert(schema.provas).values({
    id: provaId,
    casoId: p.casoId,
    tipo,
    mimeType: p.mimeType,
    tamanhoBytes: p.tamanhoBytes,
    sha256,
    recebidoEm,
    assinatura,
    chaveProtegida: protegerDek(dek),
    iv: iv.toString('base64url'),
    authTag: cifrador.getAuthTag().toString('base64url'),
    arquivoChave: chave,
    metaEnc: cifrarJson(p.meta, p.dekCaso),
  });
  await db.update(schema.casos).set({ atualizadoEm: new Date() }).where(eq(schema.casos.id, p.casoId));
  await registrarEventoCaso(p.casoId, 'PROVA_ADICIONADA', { atorId: p.atorId, detalhe: { provaId, sha256, tipo } });

  return { id: provaId, tipo, mimeType: p.mimeType, sha256, recebidoEm, tamanhoBytes: p.tamanhoBytes, assinatura, ...p.meta };
}
