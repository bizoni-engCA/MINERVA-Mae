import { describe, expect, it } from 'vitest';
import { api, cadastrar, novoDre } from './helpers';

describe('cadastro com DRE (simulador do SIGA)', () => {
  it('cadastra, entra, renova e sai', async () => {
    const dre = novoDre();
    const ini = await api().post('/api/auth/verificacao/iniciar').send({ dre });
    expect(ini.status).toBe(201);
    expect(ini.body.emailMascarado).toMatch(/@ufrj\.br$/);
    expect(ini.body.codigoDev).toMatch(/^\d{6}$/);

    const errado = await api()
      .post('/api/auth/verificacao/confirmar')
      .send({ desafioId: ini.body.desafioId, codigo: ini.body.codigoDev === '000000' ? '111111' : '000000' });
    expect(errado.status).toBe(400);

    const conf = await api().post('/api/auth/verificacao/confirmar').send({ desafioId: ini.body.desafioId, codigo: ini.body.codigoDev });
    expect(conf.status).toBe(200);

    // Código não pode ser reutilizado
    const reuso = await api().post('/api/auth/verificacao/confirmar').send({ desafioId: ini.body.desafioId, codigo: ini.body.codigoDev });
    expect(reuso.status).toBe(400);

    const semAutodeclaracao = await api().post('/api/auth/cadastro').send({
      tokenVerificacao: conf.body.tokenVerificacao,
      apelido: 'flor.de.lis',
      senha: 'senha-segura-123',
      autodeclaracao: false,
      aceiteTermos: true,
    });
    expect(semAutodeclaracao.status).toBe(400);

    const cad = await api().post('/api/auth/cadastro').send({
      tokenVerificacao: conf.body.tokenVerificacao,
      apelido: 'flor.de.lis',
      senha: 'senha-segura-123',
      autodeclaracao: true,
      aceiteTermos: true,
    });
    expect(cad.status).toBe(201);
    expect(cad.body.usuaria).toMatchObject({ apelido: 'flor.de.lis', papel: 'USUARIA', vinculoTipo: 'ESTUDANTE' });
    expect(JSON.stringify(cad.body)).not.toContain(dre); // DRE nunca volta em claro

    const login = await api().post('/api/auth/entrar').send({ apelido: 'FLOR.DE.LIS', senha: 'senha-segura-123' });
    expect(login.status).toBe(200);

    const ruim = await api().post('/api/auth/entrar').send({ apelido: 'flor.de.lis', senha: 'errada-123' });
    expect(ruim.status).toBe(401);

    const ren = await api().post('/api/auth/renovar').send({ tokenRenovacao: login.body.tokenRenovacao });
    expect(ren.status).toBe(200);
    // Refresh antigo foi rotacionado; reutilizar derruba as sessões
    const reusoRefresh = await api().post('/api/auth/renovar').send({ tokenRenovacao: login.body.tokenRenovacao });
    expect(reusoRefresh.status).toBe(401);
    const depois = await api().post('/api/auth/renovar').send({ tokenRenovacao: ren.body.tokenRenovacao });
    expect(depois.status).toBe(401);
  });

  it('não revela no início se o DRE já tem conta, só depois do código', async () => {
    const conta = await cadastrar('ja.tenho.conta');
    const ini = await api().post('/api/auth/verificacao/iniciar').send({ dre: conta.dre });
    expect(ini.status).toBe(201);
    const conf = await api().post('/api/auth/verificacao/confirmar').send({ desafioId: ini.body.desafioId, codigo: ini.body.codigoDev });
    expect(conf.status).toBe(409);
    expect(conf.body.codigo).toBe('CONTA_EXISTENTE');
  });

  it('recusa matrícula cancelada e DRE inexistente', async () => {
    expect((await api().post('/api/auth/verificacao/iniciar').send({ dre: '120000005' })).status).toBe(403);
    expect((await api().post('/api/auth/verificacao/iniciar').send({ dre: '999999999' })).status).toBe(404);
    expect((await api().post('/api/auth/verificacao/iniciar').send({ dre: '123' })).status).toBe(400);
  });

  it('redefine a senha com o DRE e encerra sessões antigas', async () => {
    const conta = await cadastrar('esqueci.senha');
    const ini = await api().post('/api/auth/verificacao/iniciar').send({ dre: conta.dre, finalidade: 'REDEFINIR_SENHA' });
    const conf = await api().post('/api/auth/verificacao/confirmar').send({ desafioId: ini.body.desafioId, codigo: ini.body.codigoDev });
    expect(conf.status).toBe(200);
    const nova = await api().post('/api/auth/redefinir-senha').send({ tokenVerificacao: conf.body.tokenVerificacao, novaSenha: 'outra-senha-456' });
    expect(nova.status).toBe(200);
    expect((await api().get('/api/eu').set(conta.auth)).status).toBe(401);
    expect((await api().post('/api/auth/entrar').send({ apelido: 'esqueci.senha', senha: 'outra-senha-456' })).status).toBe(200);
  });

  it('apelido duplicado e reservado são recusados', async () => {
    await cadastrar('unica');
    const disp = await api().get('/api/auth/apelido-disponivel').query({ apelido: 'UNICA' });
    expect(disp.body.disponivel).toBe(false);
    const reservado = await api().get('/api/auth/apelido-disponivel').query({ apelido: 'admin' });
    expect(reservado.body.disponivel).toBe(false);
  });
});
