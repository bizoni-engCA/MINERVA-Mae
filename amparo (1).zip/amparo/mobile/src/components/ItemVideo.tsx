import { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { useVideoPlayer, VideoView } from 'expo-video';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { useQueryClient } from '@tanstack/react-query';
import { api, mensagemDeErro, urlMidia } from '@/api/cliente';
import { sinalizar } from '@/api/consultas';
import type { Pagina, ReacaoTipo, Reacoes as TReacoes, Video } from '@/api/tipos';
import { tempoRelativo } from '@/lib/formatar';
import { MOTIVOS_SINALIZACAO } from '@/lib/rotulos';
import { useSeguranca } from '@/store/seguranca';
import { espaco, fontes } from '@/theme';
import { Opcoes } from './Opcoes';
import { Reacoes } from './Reacoes';
import { BotaoIcone, Icone, Texto } from './ui';

/** Um vídeo do feed vertical. Toca só quando está visível (e, se for sensível, depois de revelado). */
export function ItemVideo({ video, altura, ativo }: { video: Video; altura: number; ativo: boolean }) {
  const qc = useQueryClient();
  const mostrarSensiveis = useSeguranca((s) => s.mostrarSensiveis);
  const [revelado, setRevelado] = useState(!video.sensivel || mostrarSensiveis);
  const [pausado, setPausado] = useState(false);
  const [menu, setMenu] = useState(false);
  const [motivos, setMotivos] = useState(false);

  const player = useVideoPlayer({ uri: urlMidia(video.url) }, (p) => {
    p.loop = true;
  });

  useEffect(() => {
    if (ativo && revelado && !pausado) player.play();
    else player.pause();
  }, [ativo, revelado, pausado, player]);

  async function reagir(tipo: ReacaoTipo) {
    try {
      const r = await api<{ reacoes: TReacoes; minhasReacoes: ReacaoTipo[] }>(`/api/videos/${video.id}/reacoes`, { corpo: { tipo } });
      qc.setQueryData<{ pages: Pagina<Video>[]; pageParams: unknown[] }>(['videos'], (d) =>
        d ? { ...d, pages: d.pages.map((pg) => ({ ...pg, itens: pg.itens.map((v) => (v.id === video.id ? { ...v, ...r } : v)) })) } : d,
      );
    } catch (e) {
      Alert.alert('Erro', mensagemDeErro(e));
    }
  }

  return (
    <View style={{ height: altura, backgroundColor: '#000' }}>
      <Pressable style={StyleSheet.absoluteFill} onPress={() => revelado && setPausado(!pausado)} accessibilityLabel={pausado ? 'Continuar vídeo' : 'Pausar vídeo'}>
        <VideoView player={player} style={[StyleSheet.absoluteFill, { width: '100%', height: '100%' }]} contentFit="cover" nativeControls={false} />
      </Pressable>

      {!revelado ? (
        <Pressable style={[StyleSheet.absoluteFill, estilos.veu]} onPress={() => setRevelado(true)} accessibilityRole="button" accessibilityLabel="Conteúdo sensível. Toque para assistir.">
          {video.capaUrl ? <Image source={{ uri: urlMidia(video.capaUrl) }} style={StyleSheet.absoluteFill} blurRadius={40} /> : null}
          <View style={estilos.veuCaixa}>
            <Icone nome="eye-off" cor="#FFF" tamanho={28} />
            <Text style={estilos.veuTitulo}>Conteúdo sensível</Text>
            <Text style={estilos.veuTexto}>Este relato fala de violência. Toque para assistir.</Text>
          </View>
        </Pressable>
      ) : null}

      {pausado && revelado ? (
        <View style={estilos.pausa} pointerEvents="none">
          <Icone nome="play" cor="rgba(255,255,255,0.9)" tamanho={64} />
        </View>
      ) : null}

      <LinearGradient colors={['transparent', 'rgba(0,0,0,0.75)']} style={estilos.gradiente} pointerEvents="box-none">
        <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: espaco.m }}>
          <View style={{ flex: 1 }}>
            <Text style={estilos.autoria}>
              {video.autoria.apelido} · {tempoRelativo(video.publicadoEm)}
            </Text>
            <Text style={estilos.titulo}>{video.titulo}</Text>
            {video.descricao ? (
              <Texto pequeno cor="#E8E2F0" numberOfLines={3}>
                {video.descricao}
              </Texto>
            ) : null}
          </View>
          <View style={{ alignItems: 'center', gap: espaco.s }}>
            <Reacoes reacoes={video.reacoes} minhas={video.minhasReacoes} aoReagir={reagir} escuro vertical />
            <BotaoIcone icone="ellipsis-horizontal" rotulo="Mais opções" cor="#FFF" onPress={() => setMenu(true)} />
          </View>
        </View>
      </LinearGradient>

      <Opcoes
        visivel={menu}
        aoFechar={() => setMenu(false)}
        opcoes={video.souAutora ? [] : [{ rotulo: 'Sinalizar para a moderação', icone: 'flag-outline', onPress: () => setMotivos(true) }]}
      />
      <Opcoes
        visivel={motivos}
        titulo="Qual é o problema?"
        aoFechar={() => setMotivos(false)}
        opcoes={Object.entries(MOTIVOS_SINALIZACAO).map(([motivo, rotulo]) => ({
          rotulo,
          onPress: async () => {
            try {
              Alert.alert('Sinalização enviada', (await sinalizar('VIDEO', video.id, motivo)).mensagem);
            } catch (e) {
              Alert.alert('Erro', mensagemDeErro(e));
            }
          },
        }))}
      />
    </View>
  );
}

const estilos = StyleSheet.create({
  gradiente: { position: 'absolute', left: 0, right: 0, bottom: 0, paddingHorizontal: espaco.l, paddingTop: 80, paddingBottom: espaco.xl },
  autoria: { fontFamily: fontes.textoMedio, fontSize: 13.5, color: '#D9CFEA' },
  titulo: { fontFamily: fontes.titulo, fontSize: 21, lineHeight: 26, color: '#FFF', marginVertical: 4 },
  veu: { backgroundColor: '#1D1230', alignItems: 'center', justifyContent: 'center' },
  veuCaixa: { alignItems: 'center', padding: espaco.xl, gap: 6 },
  veuTitulo: { fontFamily: fontes.titulo, fontSize: 20, color: '#FFF', marginTop: 6 },
  veuTexto: { fontFamily: fontes.texto, fontSize: 15, color: '#E8E2F0', textAlign: 'center' },
  pausa: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' },
});
