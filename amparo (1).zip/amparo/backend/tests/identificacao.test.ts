import { describe, expect, it } from 'vitest';
import { detectarIdentificacao } from '../src/lib/identificacao';

const tipos = (t: string) => detectarIdentificacao(t).map((a) => a.tipo);

describe('filtro de identificação', () => {
  it('não alerta relatos sem dados identificáveis', () => {
    expect(
      detectarIdentificacao(
        'Um docente fazia comentários sobre minha roupa no laboratório. Saí da aula chorando e fui ao bandejão com uma amiga.',
      ),
    ).toEqual([]);
  });

  it('não alerta nomes de lugares e órgãos da UFRJ', () => {
    expect(detectarIdentificacao('Fui à Ouvidoria e depois à Praia Vermelha. Também procurei a DISAE e o CRM.')).toEqual([]);
  });

  it('detecta cargo seguido de nome', () => {
    expect(tipos('O prof. Carlos me chamou para a sala dele.')).toContain('CARGO_E_NOME');
    expect(tipos('a orientadora Mariana disse que eu não ia passar')).toContain('CARGO_E_NOME');
  });

  it('detecta nome completo no meio da frase', () => {
    const a = detectarIdentificacao('Quem fez isso foi Joana Pereira da Silva, do meu período.');
    expect(a.some((x) => x.tipo === 'NOME_COMPLETO' && x.trecho.includes('Joana Pereira'))).toBe(true);
  });

  it('detecta nome precedido de artigo', () => {
    expect(tipos('Ontem o Pedro me seguiu até o ponto.')).toContain('NOME_PROPRIO');
  });

  it('detecta código de disciplina, e-mail, telefone, perfil e matrícula', () => {
    const t = tipos('Na turma de ABC123 ele mandou e-mail de x.y@ufrj.br, ligou do (21) 99876-5432, perfil @fulano.oficial, DRE 123456789');
    expect(t).toEqual(expect.arrayContaining(['CODIGO_DISCIPLINA', 'EMAIL', 'TELEFONE', 'PERFIL', 'MATRICULA']));
  });

  it('não confunde anos com telefone', () => {
    expect(tipos('Isso aconteceu entre 2023 e 2024.')).not.toContain('TELEFONE');
  });
});
