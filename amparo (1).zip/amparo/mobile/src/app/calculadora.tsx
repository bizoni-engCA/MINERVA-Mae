import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { autenticarComBiometria } from '@/lib/biometria';
import { useSeguranca } from '@/store/seguranca';

/**
 * Disfarce: uma calculadora que funciona de verdade.
 * Para entrar no app: digite o PIN (6 dígitos) e toque em "=".
 * Com biometria ativada, segurar o "=" também desbloqueia.
 */
type Op = '+' | '−' | '×' | '÷';

const formatar = (n: number) => {
  if (!Number.isFinite(n)) return 'Erro';
  const arred = Number.parseFloat(n.toPrecision(12));
  return arred.toLocaleString('pt-BR', { maximumFractionDigits: 8 });
};
const ler = (s: string) => Number.parseFloat(s.replace(/\./g, '').replace(',', '.'));
const calcular = (a: number, b: number, op: Op) => (op === '+' ? a + b : op === '−' ? a - b : op === '×' ? a * b : a / b);

export default function Calculadora() {
  const insets = useSafeAreaInsets();
  const { pinConfere, desbloquear, biometria } = useSeguranca();
  const [visor, setVisor] = useState('0');
  const [acumulador, setAcumulador] = useState<number | null>(null);
  const [operador, setOperador] = useState<Op | null>(null);
  const [novoNumero, setNovoNumero] = useState(true);
  const [digitado, setDigitado] = useState('');

  const digito = (d: string) => {
    setDigitado((s) => (s + d).slice(-12));
    if (novoNumero) {
      setVisor(d === ',' ? '0,' : d);
      setNovoNumero(false);
      return;
    }
    if (d === ',' && visor.includes(',')) return;
    if (visor.replace(/\D/g, '').length >= 12) return;
    setVisor(visor === '0' && d !== ',' ? d : visor + d);
  };

  const escolherOperador = (op: Op) => {
    const atual = ler(visor);
    if (operador && acumulador !== null && !novoNumero) {
      const r = calcular(acumulador, atual, operador);
      setAcumulador(r);
      setVisor(formatar(r));
    } else setAcumulador(atual);
    setOperador(op);
    setNovoNumero(true);
    setDigitado('');
  };

  const igual = async () => {
    if (!operador && /^\d{6}$/.test(digitado) && (await pinConfere(digitado))) {
      limpar();
      desbloquear();
      return;
    }
    if (operador && acumulador !== null) {
      const r = calcular(acumulador, ler(visor), operador);
      setVisor(formatar(r));
      setAcumulador(null);
      setOperador(null);
    }
    setNovoNumero(true);
    setDigitado('');
  };

  const limpar = () => {
    setVisor('0');
    setAcumulador(null);
    setOperador(null);
    setNovoNumero(true);
    setDigitado('');
  };

  const linhas: { r: string; tipo: 'funcao' | 'numero' | 'operador'; acao: () => void; largo?: boolean }[][] = [
    [
      { r: 'AC', tipo: 'funcao', acao: limpar },
      { r: '±', tipo: 'funcao', acao: () => setVisor(formatar(-ler(visor))) },
      { r: '%', tipo: 'funcao', acao: () => setVisor(formatar(ler(visor) / 100)) },
      { r: '÷', tipo: 'operador', acao: () => escolherOperador('÷') },
    ],
    [...['7', '8', '9'].map((n) => ({ r: n, tipo: 'numero' as const, acao: () => digito(n) })), { r: '×', tipo: 'operador', acao: () => escolherOperador('×') }],
    [...['4', '5', '6'].map((n) => ({ r: n, tipo: 'numero' as const, acao: () => digito(n) })), { r: '−', tipo: 'operador', acao: () => escolherOperador('−') }],
    [...['1', '2', '3'].map((n) => ({ r: n, tipo: 'numero' as const, acao: () => digito(n) })), { r: '+', tipo: 'operador', acao: () => escolherOperador('+') }],
    [
      { r: '0', tipo: 'numero', acao: () => digito('0'), largo: true },
      { r: ',', tipo: 'numero', acao: () => digito(',') },
      { r: '=', tipo: 'operador', acao: igual },
    ],
  ];

  return (
    <View style={[estilos.tela, { paddingTop: insets.top, paddingBottom: insets.bottom + 16 }]}>
      <StatusBar style="light" />
      <View style={estilos.visorArea}>
        <Text style={estilos.visor} numberOfLines={1} adjustsFontSizeToFit accessibilityLiveRegion="polite">
          {visor}
        </Text>
      </View>
      {linhas.map((linha, i) => (
        <View key={i} style={estilos.linha}>
          {linha.map((t) => (
            <Pressable
              key={t.r}
              onPress={t.acao}
              onLongPress={t.r === '=' && biometria ? async () => (await autenticarComBiometria(' ')) && desbloquear() : undefined}
              delayLongPress={900}
              accessibilityRole="button"
              accessibilityLabel={t.r}
              style={({ pressed }) => [
                estilos.tecla,
                t.largo && estilos.largo,
                t.tipo === 'funcao' && { backgroundColor: '#A5A5A5' },
                t.tipo === 'operador' && { backgroundColor: operador === t.r && novoNumero ? '#FFFFFF' : '#FF9F0A' },
                pressed && { opacity: 0.7 },
              ]}
            >
              <Text
                style={[
                  estilos.teclaTexto,
                  t.tipo === 'funcao' && { color: '#000' },
                  t.tipo === 'operador' && operador === t.r && novoNumero && { color: '#FF9F0A' },
                  t.largo && { alignSelf: 'flex-start', marginLeft: 30 },
                ]}
              >
                {t.r}
              </Text>
            </Pressable>
          ))}
        </View>
      ))}
    </View>
  );
}

const estilos = StyleSheet.create({
  tela: { flex: 1, backgroundColor: '#000', justifyContent: 'flex-end', paddingHorizontal: 16 },
  visorArea: { flex: 1, justifyContent: 'flex-end', paddingHorizontal: 10, paddingBottom: 12 },
  visor: { color: '#FFF', fontSize: 84, fontWeight: '300', textAlign: 'right' },
  linha: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 14 },
  tecla: { width: 78, height: 78, borderRadius: 39, backgroundColor: '#333333', alignItems: 'center', justifyContent: 'center' },
  largo: { width: 78 * 2 + 14 },
  teclaTexto: { color: '#FFF', fontSize: 34, fontWeight: '400' },
});
