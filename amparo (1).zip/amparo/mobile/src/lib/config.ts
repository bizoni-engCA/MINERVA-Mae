import Constants from 'expo-constants';

/**
 * Endereço da API.
 *  1. EXPO_PUBLIC_API_URL, se definido (ex.: http://192.168.0.10:3333);
 *  2. senão, o mesmo computador que serve o app no Expo (porta 3333);
 *  3. senão, localhost.
 */
export function urlApi() {
  const env = process.env.EXPO_PUBLIC_API_URL;
  if (env) return env.replace(/\/$/, '');
  const host = Constants.expoConfig?.hostUri?.split(':')[0];
  if (host) return `http://${host}:3333`;
  return 'http://localhost:3333';
}
