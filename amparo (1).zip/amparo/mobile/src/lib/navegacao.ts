import type { NativeStackNavigationOptions } from 'expo-router';
import { cores, fontes } from '@/theme';

export const opcoesCabecalho: NativeStackNavigationOptions = {
  headerStyle: { backgroundColor: cores.papel },
  headerShadowVisible: false,
  headerTintColor: cores.lilas,
  headerTitleStyle: { fontFamily: fontes.tituloMedio, fontSize: 18, color: cores.tinta },
  headerBackButtonDisplayMode: 'minimal',
  contentStyle: { backgroundColor: cores.papel },
};
