import { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Modal, Platform, Pressable, StyleSheet, View } from 'react-native';
import { cores, espaco, raio } from '@/theme';
import { Botao, Campo, Linha, Texto, Titulo } from './ui';

/** Caixa de diálogo com um campo de texto (Alert.prompt não existe no Android). */
export function PedirTexto({
  visivel,
  titulo,
  descricao,
  rotulo,
  confirmar,
  perigo,
  senha,
  obrigatorio = true,
  aoConfirmar,
  aoFechar,
}: {
  visivel: boolean;
  titulo: string;
  descricao?: string;
  rotulo: string;
  confirmar: string;
  perigo?: boolean;
  senha?: boolean;
  obrigatorio?: boolean;
  aoConfirmar: (texto: string) => void | Promise<void>;
  aoFechar: () => void;
}) {
  const [texto, setTexto] = useState('');
  const [enviando, setEnviando] = useState(false);
  useEffect(() => {
    if (visivel) setTexto('');
  }, [visivel]);

  return (
    <Modal visible={visivel} transparent animationType="fade" onRequestClose={aoFechar}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={estilos.fundo}>
        <Pressable style={StyleSheet.absoluteFill} onPress={aoFechar} accessibilityLabel="Fechar" />
        <View style={estilos.caixa}>
          <Titulo nivel={3}>{titulo}</Titulo>
          {descricao ? (
            <Texto pequeno fraco style={{ marginTop: 4, marginBottom: espaco.m }}>
              {descricao}
            </Texto>
          ) : (
            <View style={{ height: espaco.m }} />
          )}
          <Campo rotulo={rotulo} value={texto} onChangeText={setTexto} multiline={!senha} secureTextEntry={senha} autoFocus style={!senha ? { minHeight: 90 } : undefined} />
          <Linha estilo={{ justifyContent: 'flex-end' }}>
            <Botao titulo="Cancelar" variante="fantasma" compacto onPress={aoFechar} />
            <Botao
              titulo={confirmar}
              variante={perigo ? 'perigo' : 'primario'}
              compacto
              carregando={enviando}
              desativado={obrigatorio && !texto.trim()}
              onPress={async () => {
                setEnviando(true);
                try {
                  await aoConfirmar(texto.trim());
                } finally {
                  setEnviando(false);
                }
              }}
            />
          </Linha>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const estilos = StyleSheet.create({
  fundo: { flex: 1, backgroundColor: 'rgba(30,15,50,0.4)', justifyContent: 'center', padding: espaco.xl },
  caixa: { backgroundColor: cores.superficie, borderRadius: raio.grande, padding: espaco.xl },
});
