import { FlatList, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useComunidades, useFeed } from '@/api/consultas';
import { mensagemDeErro } from '@/api/cliente';
import { CartaoRelato } from '@/components/CartaoRelato';
import { Carregando, Chip, ErroTela, Icone, Linha, Texto, Vazio, Botao, type NomeIcone } from '@/components/ui';
import { cores, espaco, fontes, raio } from '@/theme';

export default function Comunidades() {
  const feed = useFeed();
  const comunidades = useComunidades();
  const minhas = (comunidades.data ?? []).filter((c) => c.souMembro);
  const itens = feed.data?.pages.flatMap((p) => p.itens) ?? [];

  const cabecalho = (
    <View style={{ marginBottom: espaco.m }}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: espaco.s, paddingVertical: espaco.s }}>
        <Chip rotulo="Para você" ativo />
        {minhas.map((c) => (
          <Chip key={c.id} rotulo={c.nome} icone={c.icone as NomeIcone} cor={c.cor} onPress={() => router.push(`/comunidade/${c.slug}`)} />
        ))}
        <Chip rotulo="Explorar" icone="compass-outline" onPress={() => router.push('/comunidades')} />
      </ScrollView>
      <Linha estilo={{ justifyContent: 'space-between', marginTop: espaco.s }}>
        <Texto pequeno fraco style={{ flex: 1 }}>
          {minhas.length ? 'Relatos das subcomunidades que você participa.' : 'Relatos de todas as subcomunidades.'}
        </Texto>
        <Pressable onPress={() => router.push('/meus-relatos')} hitSlop={8}>
          <Text style={estilos.link}>Meus relatos</Text>
        </Pressable>
      </Linha>
    </View>
  );

  if (feed.isLoading) return <Carregando />;
  if (feed.isError) return <ErroTela mensagem={mensagemDeErro(feed.error)} tentarDeNovo={feed.refetch} />;

  return (
    <View style={{ flex: 1, backgroundColor: cores.papel }}>
      <FlatList
        data={itens}
        keyExtractor={(p) => p.id}
        renderItem={({ item }) => <CartaoRelato post={item} />}
        ListHeaderComponent={cabecalho}
        contentContainerStyle={{ padding: espaco.l, paddingBottom: 110 }}
        onEndReached={() => feed.hasNextPage && !feed.isFetchingNextPage && feed.fetchNextPage()}
        onEndReachedThreshold={0.4}
        refreshControl={
          <RefreshControl
            refreshing={feed.isRefetching}
            onRefresh={() => {
              feed.refetch();
              comunidades.refetch();
            }}
            tintColor={cores.lilas}
          />
        }
        ListEmptyComponent={
          <Vazio
            icone="chatbubbles-outline"
            titulo="Nenhum relato por aqui ainda"
            texto="Que tal ser a primeira? Você pode escrever como anônima."
            acao={<Botao titulo="Escrever um relato" compacto onPress={() => router.push('/relato/novo')} />}
          />
        }
        ListFooterComponent={feed.isFetchingNextPage ? <Carregando /> : undefined}
      />
      <Pressable
        onPress={() => router.push('/relato/novo')}
        style={({ pressed }) => [estilos.fab, pressed && { opacity: 0.9 }]}
        accessibilityRole="button"
        accessibilityLabel="Escrever um relato"
      >
        <Icone nome="create-outline" cor="#FFF" tamanho={20} />
        <Text style={estilos.fabTexto}>Relatar</Text>
      </Pressable>
    </View>
  );
}

const estilos = StyleSheet.create({
  link: { fontFamily: fontes.textoNegrito, color: cores.lilas, fontSize: 14 },
  fab: {
    position: 'absolute',
    right: espaco.l,
    bottom: espaco.l,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: cores.lilas,
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderRadius: raio.pilula,
    shadowColor: cores.tinta,
    shadowOpacity: 0.25,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 5,
  },
  fabTexto: { color: '#FFF', fontFamily: fontes.textoNegrito, fontSize: 16 },
});
