import type { Usuaria } from '../../db/schema';

export const perfilPublico = (u: Usuaria) => ({
  id: u.id,
  apelido: u.apelido,
  papel: u.papel,
  vinculoTipo: u.vinculoTipo,
  criadoEm: u.criadoEm,
});

/** Como a autora aparece para as outras usuárias. */
export const autoriaVisivel = (anonimo: boolean, apelido: string | null | undefined) =>
  anonimo || !apelido ? { apelido: 'Anônima', anonimo: true } : { apelido, anonimo: false };
