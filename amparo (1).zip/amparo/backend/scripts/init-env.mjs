#!/usr/bin/env node
// Cria o arquivo .env a partir do .env.example, gerando chaves aleatórias novas.
// Uso: node scripts/init-env.mjs [--force]
import { generateKeyPairSync, randomBytes } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const raiz = join(dirname(fileURLToPath(import.meta.url)), '..');
const destino = join(raiz, '.env');
const exemplo = join(raiz, '.env.example');

if (existsSync(destino) && !process.argv.includes('--force')) {
  console.log('.env já existe — nada a fazer (use --force para recriar e PERDER as chaves atuais).');
  process.exit(0);
}

const { privateKey } = generateKeyPairSync('ed25519');
const pem = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();

const segredos = {
  JWT_SECRET: randomBytes(48).toString('base64url'),
  MASTER_KEY: randomBytes(32).toString('base64'),
  HASH_PEPPER: randomBytes(32).toString('base64url'),
  MEDIA_URL_SECRET: randomBytes(32).toString('base64url'),
  RECEIPT_PRIVATE_KEY: Buffer.from(pem).toString('base64'),
};

let conteudo = readFileSync(exemplo, 'utf8');
for (const [chave, valor] of Object.entries(segredos)) {
  conteudo = conteudo.replace(new RegExp(`^${chave}=.*$`, 'm'), `${chave}=${valor}`);
}
writeFileSync(destino, conteudo, { mode: 0o600 });
console.log('✅ .env criado com chaves novas.');
console.log('⚠️  Guarde uma cópia segura do MASTER_KEY: sem ela, as provas criptografadas não podem ser lidas.');
