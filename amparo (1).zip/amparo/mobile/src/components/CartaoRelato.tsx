import { Pressable, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import type { Post } from '@/api/tipos';
import { tempoRelativo } from '@/lib/formatar';
import { STATUS_CONTEUDO } from '@/lib/rotulos';
import { cores, espaco, fontes, raio, tamanhos } from '@/theme';
import { ConteudoSensivel } from './ConteudoSensivel';
import { Etiqueta, Icone, Linha, type NomeIcone } from './ui';

/**
 * Relato no feed: uma "carta" com a cor da subcomunidade na margem esquerda.
 */
export function CartaoRelato({ post, mostrarStatus }: { post: Post; mostrarStatus?: boolean }) {
  const total = post.reacoes.APOIO + post.reacoes.ME_IDENTIFICO + post.reacoes.FORCA;
  const status = mostrarStatus && post.status ? STATUS_CONTEUDO[post.status] : null;
  return (
    <Pressable
      onPress={() => router.push(`/relato/${post.id}`)}
      accessibilityRole="button"
      accessibilityLabel={`Relato: ${post.titulo}`}
      style={({ pressed }) => [estilos.carta, { borderLeftColor: post.comunidade.cor }, pressed && { opacity: 0.85 }]}
    >
      <Linha estilo={{ justifyContent: 'space-between' }}>
        <Linha espacamento={6} estilo={{ flex: 1 }}>
          <Icone nome={post.comunidade.icone as NomeIcone} tamanho={14} cor={post.comunidade.cor} />
          <Text style={[estilos.meta, { color: post.comunidade.cor }]} numberOfLines={1}>
            {post.comunidade.nome}
          </Text>
        </Linha>
        <Text style={estilos.meta}>{tempoRelativo(post.publicadoEm)}</Text>
      </Linha>

      {status ? (
        <View style={{ marginTop: espaco.s }}>
          <Etiqueta texto={post.visibilidade === 'SO_MODERACAO' ? 'Só para a moderação' : status.rotulo} cor={status.cor} fundo={status.fundo} />
        </View>
      ) : null}

      <ConteudoSensivel sensivel={post.sensivel}>
        <Text style={estilos.titulo}>{post.titulo}</Text>
        <Text style={estilos.corpo} numberOfLines={5}>
          {post.corpo}
        </Text>
      </ConteudoSensivel>

      <Linha estilo={{ justifyContent: 'space-between', marginTop: espaco.m }}>
        <Text style={estilos.autoria}>{post.autoria.anonimo ? 'Anônima' : post.autoria.apelido}</Text>
        <Linha espacamento={espaco.m}>
          <Linha espacamento={4}>
            <Icone nome="heart" tamanho={14} cor={total ? cores.lilas : cores.nevoa} />
            <Text style={estilos.meta}>{total}</Text>
          </Linha>
          <Linha espacamento={4}>
            <Icone nome="chatbubble-outline" tamanho={14} cor={cores.nevoa} />
            <Text style={estilos.meta}>{post.totalComentarios}</Text>
          </Linha>
        </Linha>
      </Linha>
    </Pressable>
  );
}

const estilos = StyleSheet.create({
  carta: {
    backgroundColor: cores.superficie,
    borderLeftWidth: 4,
    borderTopRightRadius: raio.medio,
    borderBottomRightRadius: raio.medio,
    paddingVertical: espaco.m + 2,
    paddingHorizontal: espaco.l,
    marginBottom: espaco.m,
  },
  meta: { fontFamily: fontes.textoMedio, fontSize: tamanhos.legenda, color: cores.nevoa },
  titulo: { fontFamily: fontes.tituloMedio, fontSize: tamanhos.destaque, lineHeight: 24, color: cores.tinta, marginTop: espaco.s },
  corpo: { fontFamily: fontes.texto, fontSize: 15, lineHeight: 22, color: cores.tintaSuave, marginTop: 4 },
  autoria: { fontFamily: fontes.textoNegrito, fontSize: tamanhos.legenda, color: cores.tintaSuave },
});
