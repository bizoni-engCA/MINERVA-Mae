import { Linking, Text, View } from 'react-native';
import { Stack, useLocalSearchParams } from 'expo-router';
import { useGuia } from '@/api/consultas';
import { mensagemDeErro } from '@/api/cliente';
import { Markdown } from '@/components/Markdown';
import { Carregando, Divisor, ErroTela, Texto, Titulo, Tela } from '@/components/ui';
import { cores, espaco, fontes } from '@/theme';

export default function Guia() {
  const { slug } = useLocalSearchParams<{ slug: string }>();
  const q = useGuia(slug);
  if (q.isLoading) return <Carregando />;
  if (q.isError || !q.data) return <ErroTela mensagem={mensagemDeErro(q.error)} tentarDeNovo={q.refetch} />;
  const g = q.data;
  return (
    <Tela>
      <Stack.Screen options={{ title: '' }} />
      <Titulo>{g.titulo}</Titulo>
      <Texto fraco style={{ marginTop: espaco.s, marginBottom: espaco.l }}>
        {g.resumo}
      </Texto>
      <Markdown texto={g.corpo} />
      {g.fontes.length ? (
        <View>
          <Divisor />
          <Texto pequeno negrito>
            Fontes
          </Texto>
          {g.fontes.map((f) => (
            <Text key={f} onPress={() => Linking.openURL(f)} style={{ fontFamily: fontes.texto, fontSize: 13, color: cores.lilas, marginTop: 6 }} numberOfLines={2}>
              {f.replace(/^https?:\/\//, '')}
            </Text>
          ))}
        </View>
      ) : null}
    </Tela>
  );
}
