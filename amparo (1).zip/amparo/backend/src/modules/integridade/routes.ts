import { Router } from 'express';
import { chavePublicaReciboPem, conferirRecibo, impressaoDigitalChavePublica } from '../../lib/crypto';
import { validar, z } from '../../lib/validar';

/**
 * Rotas PÚBLICAS para que qualquer pessoa (ouvidoria, delegacia, advogada)
 * confira os recibos de integridade impressos no dossiê.
 */
export const integridadeRouter = Router();

integridadeRouter.get('/chave-publica', (_req, res) => {
  res.json({ algoritmo: 'Ed25519', impressaoDigital: impressaoDigitalChavePublica, pem: chavePublicaReciboPem });
});

integridadeRouter.post('/verificar-recibo', (req, res) => {
  const r = validar(
    z.object({
      provaId: z.uuid(),
      casoId: z.uuid(),
      sha256: z.string().regex(/^[a-f0-9]{64}$/),
      tamanhoBytes: z.number().int().nonnegative(),
      recebidoEm: z.string(),
      assinatura: z.string(),
    }),
    req.body,
  );
  const { assinatura, ...dados } = r;
  res.json({ valido: conferirRecibo(dados, assinatura) });
});
