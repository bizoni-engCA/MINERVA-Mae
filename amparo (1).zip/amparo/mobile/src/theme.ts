/**
 * Identidade visual do Amparo.
 *
 * Paleta: o lilás remete ao "Agosto Lilás" (mês de conscientização contra a
 * violência à mulher no Brasil); a tinta ameixa dá contraste calmo; o verde-mata
 * marca apoio e confirmações; o vermelho fica reservado para a saída rápida e
 * ações destrutivas.
 *
 * Tipografia: Bricolage Grotesque nos títulos (calorosa, com personalidade) e
 * Atkinson Hyperlegible Next no texto — desenhada para máxima legibilidade,
 * importante para quem lê em momentos de estresse.
 */
export const cores = {
  tinta: '#2B1B3F',
  tintaSuave: '#4A3A5E',
  papel: '#F5F2F9',
  superficie: '#FFFFFF',
  lilas: '#6F45B8',
  lilasClaro: '#EDE6F8',
  mata: '#2E7462',
  mataClaro: '#E3F1EC',
  sinal: '#B83A3A',
  sinalClaro: '#F8E5E3',
  ambar: '#9A6400',
  ambarClaro: '#FBF0DA',
  nevoa: '#6E6481',
  linha: '#E2DCEB',
  cofre: '#24163A',
  cofreTexto: '#E9E2F5',
} as const;

export const fontes = {
  titulo: 'BricolageGrotesque_700Bold',
  tituloMedio: 'BricolageGrotesque_600SemiBold',
  texto: 'AtkinsonHyperlegibleNext_400Regular',
  textoMedio: 'AtkinsonHyperlegibleNext_600SemiBold',
  textoNegrito: 'AtkinsonHyperlegibleNext_700Bold',
} as const;

export const tamanhos = {
  legenda: 13,
  pequeno: 14,
  corpo: 16,
  destaque: 18,
  subtitulo: 21,
  titulo: 27,
  tela: 32,
} as const;

export const espaco = { xs: 4, s: 8, m: 12, l: 16, xl: 24, xxl: 32 } as const;
export const raio = { pequeno: 8, medio: 14, grande: 22, pilula: 999 } as const;
