import { Router } from 'express';
import { and, asc, desc, eq, inArray, isNotNull, isNull, or, sql } from 'drizzle-orm';
import { db, schema } from '../../db';
import { abrirDek, decifrarCampo, decifrarJson } from '../../lib/crypto';
import { HttpError, invalido, naoEncontrado } from '../../lib/errors';
import { uuid, validar, z } from '../../lib/validar';
import { eu, exigirLogin, exigirPapel } from '../../middleware/auth';
import { contarProvas, resumoCaso, type DadosCaso } from '../casos/servico';
import { urlsVideo } from '../videos/consultas';
import { registrarAuditoria, registrarEventoCaso } from './auditoria';

export const equipeRouter = Router();
equipeRouter.use(exigirLogin, exigirPapel('MODERADORA', 'ACOLHIMENTO'));

const { posts, comentarios, videos, sinalizacoes, usuarias, comunidades, casos } = schema;
const soModeracao = exigirPapel('MODERADORA');
const soAcolhimento = exigirPapel('ACOLHIMENTO');

/** Moderadoras não veem o apelido de quem publicou como anônima — só um código. */
const autoriaParaModeracao = (anonimo: boolean, apelido: string | null, autoraId: string) => ({
  autoraId,
  rotulo: anonimo || !apelido ? `Anônima #${autoraId.slice(0, 6)}` : apelido,
});

equipeRouter.get('/resumo', async (req, res) => {
  const contar = async (q: Promise<{ n: number }[]>) => (await q)[0]?.n ?? 0;
  const n = sql<number>`count(*)::int`;
  const papel = eu(req).papel;
  const moderacao = papel === 'MODERADORA' || papel === 'ADMIN';
  const acolhimento = papel === 'ACOLHIMENTO' || papel === 'ADMIN';
  res.json({
    papel,
    moderacao: moderacao
      ? {
          relatosEmRevisao: await contar(
            db.select({ n }).from(posts).where(and(eq(posts.status, 'EM_REVISAO'), eq(posts.visibilidade, 'PUBLICO'))),
          ),
          relatosSoModeracao: await contar(
            db.select({ n }).from(posts).where(and(eq(posts.visibilidade, 'SO_MODERACAO'), isNull(posts.respondidoEm))),
          ),
          comentariosEmRevisao: await contar(db.select({ n }).from(comentarios).where(eq(comentarios.status, 'EM_REVISAO'))),
          videosEmRevisao: await contar(db.select({ n }).from(videos).where(eq(videos.status, 'EM_REVISAO'))),
          sinalizacoesAbertas: await contar(db.select({ n }).from(sinalizacoes).where(eq(sinalizacoes.status, 'ABERTA'))),
        }
      : null,
    acolhimento: acolhimento
      ? {
          casosAguardando: await contar(db.select({ n }).from(casos).where(eq(casos.status, 'COMPARTILHADO'))),
          casosEmAcompanhamento: await contar(db.select({ n }).from(casos).where(eq(casos.status, 'EM_ACOMPANHAMENTO'))),
          meusCasos: await contar(
            db.select({ n }).from(casos).where(and(eq(casos.responsavelId, eu(req).id), isNotNull(casos.compartilhadoEm))),
          ),
        }
      : null,
  });
});

// ════════════════════════════ MODERAÇÃO ════════════════════════════

/**
 * Filas de relatos:
 *  - revisao:      públicos retidos pelo filtro ou por sinalizações
 *  - so-moderacao: enviados só para a moderação, ainda sem resposta
 *  - com-detalhes: publicados com informações reservadas ainda não lidas
 */
equipeRouter.get('/moderacao/posts', soModeracao, async (req, res) => {
  const { fila } = validar(
    z.object({ fila: z.enum(['revisao', 'so-moderacao', 'com-detalhes']).default('revisao') }),
    req.query,
  );
  const filtro = {
    revisao: and(eq(posts.status, 'EM_REVISAO'), eq(posts.visibilidade, 'PUBLICO')),
    'so-moderacao': and(eq(posts.visibilidade, 'SO_MODERACAO'), isNull(posts.respondidoEm)),
    'com-detalhes': and(eq(posts.status, 'PUBLICADO'), isNotNull(posts.detalhesModeracaoEnc), isNull(posts.revisadoEm)),
  }[fila];

  const lista = await db
    .select({
      post: posts,
      apelido: usuarias.apelido,
      comunidade: { id: comunidades.id, nome: comunidades.nome, cor: comunidades.cor },
      sinalizacoes: sql<number>`(select count(*)::int from sinalizacoes s where s.alvo_id = "posts"."id" and s.status = 'ABERTA')`,
    })
    .from(posts)
    .innerJoin(comunidades, eq(comunidades.id, posts.comunidadeId))
    .leftJoin(usuarias, eq(usuarias.id, posts.autoraId))
    .where(filtro)
    .orderBy(asc(posts.criadoEm))
    .limit(100);

  res.json(
    lista.map(({ post: p, apelido, comunidade, sinalizacoes: totalSinalizacoes }) => ({
      id: p.id,
      titulo: p.titulo,
      corpo: p.corpo,
      sensivel: p.sensivel,
      anonimo: p.anonimo,
      status: p.status,
      visibilidade: p.visibilidade,
      alertas: p.alertas,
      detalhesModeracao: p.detalhesModeracaoEnc ? decifrarCampo(p.detalhesModeracaoEnc) : null,
      respostaModeracao: p.respostaModeracao,
      criadoEm: p.criadoEm,
      comunidade,
      autoria: autoriaParaModeracao(p.anonimo, apelido, p.autoraId),
      sinalizacoes: totalSinalizacoes,
    })),
  );
});

const decisaoSchema = z.object({
  acao: z.enum(['APROVAR', 'REJEITAR', 'REMOVER', 'CIENTE']),
  motivo: z.string().trim().max(1000).optional(),
});

async function fecharSinalizacoes(alvoId: string, atorId: string, status: 'RESOLVIDA' | 'DESCARTADA') {
  await db
    .update(sinalizacoes)
    .set({ status, resolvidaPorId: atorId, resolvidaEm: new Date() })
    .where(and(eq(sinalizacoes.alvoId, alvoId), eq(sinalizacoes.status, 'ABERTA')));
}

const novoStatus = (acao: z.infer<typeof decisaoSchema>['acao']) =>
  acao === 'APROVAR' ? 'PUBLICADO' : acao === 'REJEITAR' ? 'REJEITADO' : acao === 'REMOVER' ? 'REMOVIDO' : null;

equipeRouter.post('/moderacao/posts/:id/decisao', soModeracao, async (req, res) => {
  const id = validar(uuid, req.params.id);
  const { acao, motivo } = validar(decisaoSchema, req.body);
  const [p] = await db.select().from(posts).where(eq(posts.id, id));
  if (!p) throw naoEncontrado('Relato');
  if ((acao === 'REJEITAR' || acao === 'REMOVER') && !motivo) {
    throw invalido('Explique o motivo — a autora vai ver essa mensagem.');
  }
  if (acao === 'APROVAR' && p.visibilidade === 'SO_MODERACAO') {
    throw invalido('Relatos enviados só para a moderação não podem ser publicados.');
  }

  const status = novoStatus(acao);
  await db
    .update(posts)
    .set({
      ...(status ? { status } : {}),
      ...(status === 'PUBLICADO' && !p.publicadoEm ? { publicadoEm: new Date() } : {}),
      motivoModeracao: motivo ?? p.motivoModeracao,
      revisadoPorId: eu(req).id,
      revisadoEm: new Date(),
    })
    .where(eq(posts.id, id));
  await fecharSinalizacoes(id, eu(req).id, acao === 'APROVAR' ? 'DESCARTADA' : 'RESOLVIDA');
  await registrarAuditoria(eu(req).id, `POST_${acao}`, 'POST', id, { motivo });
  res.json({ ok: true, status: status ?? p.status });
});

/** Resposta da moderação à autora (principalmente para relatos "só para a moderação"). */
equipeRouter.post('/moderacao/posts/:id/responder', soModeracao, async (req, res) => {
  const id = validar(uuid, req.params.id);
  const { resposta } = validar(z.object({ resposta: z.string().trim().min(2).max(5000) }), req.body);
  const [p] = await db
    .update(posts)
    .set({ respostaModeracao: resposta, respondidoEm: new Date(), revisadoPorId: eu(req).id, revisadoEm: new Date() })
    .where(eq(posts.id, id))
    .returning({ id: posts.id });
  if (!p) throw naoEncontrado('Relato');
  await registrarAuditoria(eu(req).id, 'POST_RESPONDIDO', 'POST', id);
  res.json({ ok: true });
});

equipeRouter.get('/moderacao/comentarios', soModeracao, async (_req, res) => {
  const lista = await db
    .select({
      c: comentarios,
      apelido: usuarias.apelido,
      post: { id: posts.id, titulo: posts.titulo },
      sinalizacoes: sql<number>`(select count(*)::int from sinalizacoes s where s.alvo_id = "comentarios"."id" and s.status = 'ABERTA')`,
    })
    .from(comentarios)
    .innerJoin(posts, eq(posts.id, comentarios.postId))
    .leftJoin(usuarias, eq(usuarias.id, comentarios.autoraId))
    .where(eq(comentarios.status, 'EM_REVISAO'))
    .orderBy(asc(comentarios.criadoEm))
    .limit(100);
  res.json(
    lista.map(({ c, apelido, post, sinalizacoes: total }) => ({
      id: c.id,
      corpo: c.corpo,
      alertas: c.alertas,
      criadoEm: c.criadoEm,
      post,
      autoria: autoriaParaModeracao(c.anonimo, apelido, c.autoraId),
      sinalizacoes: total,
    })),
  );
});

equipeRouter.post('/moderacao/comentarios/:id/decisao', soModeracao, async (req, res) => {
  const id = validar(uuid, req.params.id);
  const { acao, motivo } = validar(decisaoSchema, req.body);
  const status = novoStatus(acao);
  if (!status) throw invalido('Ação inválida para comentários.');
  const [c] = await db
    .update(comentarios)
    .set({ status, motivoModeracao: motivo, revisadoPorId: eu(req).id, revisadoEm: new Date() })
    .where(eq(comentarios.id, id))
    .returning({ id: comentarios.id });
  if (!c) throw naoEncontrado('Comentário');
  await fecharSinalizacoes(id, eu(req).id, acao === 'APROVAR' ? 'DESCARTADA' : 'RESOLVIDA');
  await registrarAuditoria(eu(req).id, `COMENTARIO_${acao}`, 'COMENTARIO', id, { motivo });
  res.json({ ok: true, status });
});

equipeRouter.get('/moderacao/videos', soModeracao, async (_req, res) => {
  const lista = await db
    .select({ v: videos, apelido: usuarias.apelido })
    .from(videos)
    .leftJoin(usuarias, eq(usuarias.id, videos.autoraId))
    .where(eq(videos.status, 'EM_REVISAO'))
    .orderBy(asc(videos.criadoEm))
    .limit(50);
  res.json(
    lista.map(({ v, apelido }) => ({
      id: v.id,
      titulo: v.titulo,
      descricao: v.descricao,
      sensivel: v.sensivel,
      mostrarApelido: v.mostrarApelido,
      duracaoSeg: v.duracaoSeg,
      tamanhoBytes: v.tamanhoBytes,
      criadoEm: v.criadoEm,
      autoria: autoriaParaModeracao(!v.mostrarApelido, apelido, v.autoraId),
      ...urlsVideo(v.id, Boolean(v.capaChave)),
    })),
  );
});

equipeRouter.post('/moderacao/videos/:id/decisao', soModeracao, async (req, res) => {
  const id = validar(uuid, req.params.id);
  const { acao, motivo } = validar(decisaoSchema, req.body);
  const status = novoStatus(acao);
  if (!status) throw invalido('Ação inválida para vídeos.');
  if (status !== 'PUBLICADO' && !motivo) throw invalido('Explique o motivo — a autora vai ver essa mensagem.');
  const [v] = await db
    .update(videos)
    .set({
      status,
      motivoModeracao: motivo,
      revisadoPorId: eu(req).id,
      revisadoEm: new Date(),
      ...(status === 'PUBLICADO' ? { publicadoEm: new Date() } : {}),
    })
    .where(eq(videos.id, id))
    .returning({ id: videos.id });
  if (!v) throw naoEncontrado('Vídeo');
  await fecharSinalizacoes(id, eu(req).id, acao === 'APROVAR' ? 'DESCARTADA' : 'RESOLVIDA');
  await registrarAuditoria(eu(req).id, `VIDEO_${acao}`, 'VIDEO', id, { motivo });
  res.json({ ok: true, status });
});

equipeRouter.get('/moderacao/sinalizacoes', soModeracao, async (_req, res) => {
  const abertas = await db
    .select()
    .from(sinalizacoes)
    .where(eq(sinalizacoes.status, 'ABERTA'))
    .orderBy(asc(sinalizacoes.criadoEm))
    .limit(200);

  // Agrupa por conteúdo e anexa uma prévia.
  const porAlvo = new Map<string, typeof abertas>();
  for (const s of abertas) porAlvo.set(s.alvoId, [...(porAlvo.get(s.alvoId) ?? []), s]);

  const ids = (tipo: string) => abertas.filter((s) => s.alvoTipo === tipo).map((s) => s.alvoId);
  const [listaPosts, listaComentarios, listaVideos] = await Promise.all([
    ids('POST').length ? db.select().from(posts).where(inArray(posts.id, ids('POST'))) : [],
    ids('COMENTARIO').length ? db.select().from(comentarios).where(inArray(comentarios.id, ids('COMENTARIO'))) : [],
    ids('VIDEO').length ? db.select().from(videos).where(inArray(videos.id, ids('VIDEO'))) : [],
  ]);

  const previa = (tipo: string, id: string) => {
    if (tipo === 'POST') {
      const p = listaPosts.find((x) => x.id === id);
      return p && { titulo: p.titulo, texto: p.corpo, status: p.status };
    }
    if (tipo === 'COMENTARIO') {
      const c = listaComentarios.find((x) => x.id === id);
      return c && { titulo: 'Comentário', texto: c.corpo, status: c.status, postId: c.postId };
    }
    const v = listaVideos.find((x) => x.id === id);
    return v && { titulo: v.titulo, texto: v.descricao ?? '', status: v.status, ...urlsVideo(v.id, Boolean(v.capaChave)) };
  };

  res.json(
    [...porAlvo.entries()]
      .map(([alvoId, lista]) => ({
        alvoId,
        alvoTipo: lista[0].alvoTipo,
        total: lista.length,
        motivos: lista.map((s) => ({ id: s.id, motivo: s.motivo, detalhes: s.detalhes, criadoEm: s.criadoEm })),
        conteudo: previa(lista[0].alvoTipo, alvoId),
      }))
      .filter((g) => g.conteudo),
  );
});

/** Resolve todas as sinalizações de um conteúdo: remover o conteúdo ou mantê-lo. */
equipeRouter.post('/moderacao/sinalizacoes/:alvoId/resolver', soModeracao, async (req, res) => {
  const alvoId = validar(uuid, req.params.alvoId);
  const { acao, motivo } = validar(
    z.object({ acao: z.enum(['REMOVER_CONTEUDO', 'MANTER']), motivo: z.string().trim().max(1000).optional() }),
    req.body,
  );
  const [s] = await db.select().from(sinalizacoes).where(eq(sinalizacoes.alvoId, alvoId)).limit(1);
  if (!s) throw naoEncontrado('Sinalização');

  const tabela = { POST: posts, COMENTARIO: comentarios, VIDEO: videos }[s.alvoTipo];
  if (acao === 'REMOVER_CONTEUDO') {
    if (!motivo) throw invalido('Explique o motivo — a autora vai ver essa mensagem.');
    await db.update(tabela).set({ status: 'REMOVIDO', motivoModeracao: motivo }).where(eq(tabela.id, alvoId));
  } else {
    // Mantido: volta ao ar se tinha saído por excesso de sinalizações.
    await db
      .update(tabela)
      .set({ status: 'PUBLICADO' })
      .where(and(eq(tabela.id, alvoId), eq(tabela.status, 'EM_REVISAO')));
  }
  await fecharSinalizacoes(alvoId, eu(req).id, acao === 'MANTER' ? 'DESCARTADA' : 'RESOLVIDA');
  await registrarAuditoria(eu(req).id, `SINALIZACAO_${acao}`, s.alvoTipo, alvoId, { motivo });
  res.json({ ok: true });
});

/** Suspende/bane uma conta (encerra todas as sessões dela). */
equipeRouter.post('/moderacao/usuarias/:id/status', soModeracao, async (req, res) => {
  const id = validar(uuid, req.params.id);
  const { status, motivo } = validar(
    z.object({ status: z.enum(['ATIVA', 'SUSPENSA', 'BANIDA']), motivo: z.string().trim().min(3).max(1000) }),
    req.body,
  );
  if (id === eu(req).id) throw invalido('Você não pode alterar a própria conta.');
  const [alvo] = await db.select({ papel: usuarias.papel }).from(usuarias).where(eq(usuarias.id, id));
  if (!alvo) throw naoEncontrado('Conta');
  if (alvo.papel !== 'USUARIA' && eu(req).papel !== 'ADMIN') throw new HttpError(403, 'Só a administração pode alterar contas da equipe.');
  await db
    .update(usuarias)
    .set({ status, versaoToken: sql`${usuarias.versaoToken} + 1` })
    .where(eq(usuarias.id, id));
  await registrarAuditoria(eu(req).id, `CONTA_${status}`, 'USUARIA', id, { motivo });
  res.json({ ok: true });
});

// ════════════════════════════ ACOLHIMENTO ════════════════════════════

equipeRouter.get('/casos', soAcolhimento, async (req, res) => {
  const { filtro } = validar(
    z.object({ filtro: z.enum(['aguardando', 'meus', 'todos', 'encerrados']).default('aguardando') }),
    req.query,
  );
  const onde = {
    aguardando: eq(casos.status, 'COMPARTILHADO'),
    meus: and(eq(casos.responsavelId, eu(req).id), or(eq(casos.status, 'EM_ACOMPANHAMENTO'), eq(casos.status, 'ENCAMINHADO'))),
    todos: or(eq(casos.status, 'COMPARTILHADO'), eq(casos.status, 'EM_ACOMPANHAMENTO'), eq(casos.status, 'ENCAMINHADO')),
    encerrados: eq(casos.status, 'ENCERRADO'),
  }[filtro];

  const lista = await db
    .select({ caso: casos, responsavel: usuarias.apelido })
    .from(casos)
    .leftJoin(usuarias, eq(usuarias.id, casos.responsavelId))
    .where(and(isNotNull(casos.compartilhadoEm), onde))
    .orderBy(filtro === 'aguardando' ? asc(casos.compartilhadoEm) : desc(casos.atualizadoEm))
    .limit(100);

  res.json(
    await Promise.all(
      lista.map(async ({ caso, responsavel }) => ({
        ...resumoCaso(caso, decifrarJson<DadosCaso>(caso.dadosEnc, abrirDek(caso.chaveProtegida))),
        responsavel,
        totalProvas: await contarProvas(caso.id),
      })),
    ),
  );
});

equipeRouter.post('/casos/:id/assumir', soAcolhimento, async (req, res) => {
  const id = validar(uuid, req.params.id);
  const [c] = await db
    .update(casos)
    .set({ responsavelId: eu(req).id, status: 'EM_ACOMPANHAMENTO', atualizadoEm: new Date() })
    .where(and(eq(casos.id, id), isNotNull(casos.compartilhadoEm)))
    .returning({ id: casos.id });
  if (!c) throw naoEncontrado('Caso');
  await registrarEventoCaso(id, 'ASSUMIDO', { atorId: eu(req).id, daEquipe: true });
  res.json({ ok: true, status: 'EM_ACOMPANHAMENTO' });
});

equipeRouter.patch('/casos/:id/status', soAcolhimento, async (req, res) => {
  const id = validar(uuid, req.params.id);
  const { status } = validar(z.object({ status: z.enum(['EM_ACOMPANHAMENTO', 'ENCAMINHADO', 'ENCERRADO']) }), req.body);
  const [c] = await db
    .update(casos)
    .set({ status, atualizadoEm: new Date() })
    .where(and(eq(casos.id, id), isNotNull(casos.compartilhadoEm)))
    .returning({ id: casos.id });
  if (!c) throw naoEncontrado('Caso');
  await registrarEventoCaso(id, 'STATUS_ALTERADO', { atorId: eu(req).id, daEquipe: true, detalhe: { status } });
  res.json({ ok: true, status });
});

// ════════════════════════════ ADMINISTRAÇÃO ════════════════════════════

equipeRouter.post('/papeis', exigirPapel('ADMIN'), async (req, res) => {
  const { apelido, papel } = validar(
    z.object({ apelido: z.string().trim(), papel: z.enum(['USUARIA', 'MODERADORA', 'ACOLHIMENTO', 'ADMIN']) }),
    req.body,
  );
  const [u] = await db
    .update(usuarias)
    .set({ papel, versaoToken: sql`${usuarias.versaoToken} + 1` })
    .where(sql`lower(${usuarias.apelido}) = lower(${apelido})`)
    .returning({ id: usuarias.id, apelido: usuarias.apelido, papel: usuarias.papel });
  if (!u) throw naoEncontrado('Conta');
  await registrarAuditoria(eu(req).id, 'PAPEL_ALTERADO', 'USUARIA', u.id, { papel });
  res.json(u);
});

equipeRouter.get('/auditoria', exigirPapel('ADMIN'), async (_req, res) => {
  const lista = await db
    .select({
      id: schema.auditoria.id,
      acao: schema.auditoria.acao,
      alvoTipo: schema.auditoria.alvoTipo,
      alvoId: schema.auditoria.alvoId,
      detalhe: schema.auditoria.detalhe,
      criadoEm: schema.auditoria.criadoEm,
      ator: usuarias.apelido,
    })
    .from(schema.auditoria)
    .leftJoin(usuarias, eq(usuarias.id, schema.auditoria.atorId))
    .orderBy(desc(schema.auditoria.criadoEm))
    .limit(200);
  res.json(lista);
});
