import { Platform } from 'react-native';
import { requireOptionalNativeModule } from 'expo';

/**
 * Disfarces do app: cada um troca o ícone (Android e iOS) e o nome que aparece
 * na tela inicial (só no Android — o iOS não permite mudar o nome do app).
 *
 * Os ícones são registrados em app.json (plugin expo-alternate-app-icons) e os
 * nomes no plugin local plugins/with-disfarce-android.js. Mantenha os três em sincronia.
 * A troca só funciona no app instalado (build de desenvolvimento ou de loja), não no Expo Go.
 */
export const DISFARCES = [
  { id: 'padrao', nome: 'Amparo', descricao: 'Ícone e nome originais', icone: require('../../assets/disfarces/padrao.png'), nativo: null },
  { id: 'calculadora', nome: 'Calculadora', descricao: 'Parece uma calculadora comum', icone: require('../../assets/disfarces/calculadora.png'), nativo: 'Calculadora' },
  { id: 'notas', nome: 'Notas', descricao: 'Parece um bloco de notas', icone: require('../../assets/disfarces/notas.png'), nativo: 'Notas' },
  { id: 'clima', nome: 'Clima', descricao: 'Parece um app de previsão do tempo', icone: require('../../assets/disfarces/clima.png'), nativo: 'Clima' },
  { id: 'agenda', nome: 'Agenda', descricao: 'Parece um calendário', icone: require('../../assets/disfarces/agenda.png'), nativo: 'Agenda' },
] as const;

export type IdDisfarce = (typeof DISFARCES)[number]['id'];

type ModuloIcones = {
  supportsAlternateIcons: boolean;
  setAlternateAppIcon: (nome: string | null) => Promise<string | null>;
};

const modulo = Platform.OS === 'web' ? null : requireOptionalNativeModule<ModuloIcones>('ExpoAlternateAppIcons');

/** false no Expo Go e na web — nesses casos só a aparência dentro do app muda. */
export const trocaDeIconeDisponivel = Boolean(modulo?.supportsAlternateIcons);

export async function aplicarDisfarce(id: IdDisfarce) {
  if (!modulo) return false;
  const opcao = DISFARCES.find((d) => d.id === id);
  await modulo.setAlternateAppIcon(opcao?.nativo ?? null);
  return true;
}

export const nomeDoDisfarce = (id: string) => DISFARCES.find((d) => d.id === id)?.nome ?? 'Amparo';
