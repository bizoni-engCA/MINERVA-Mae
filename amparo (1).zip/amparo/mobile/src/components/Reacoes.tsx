import { Pressable, StyleSheet, Text, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import type { ReacaoTipo, Reacoes as TReacoes } from '@/api/tipos';
import { REACOES } from '@/lib/rotulos';
import { cores, fontes, raio } from '@/theme';
import { Icone } from './ui';

/** Reações de apoio — não existem votos negativos. */
export function Reacoes({
  reacoes,
  minhas,
  aoReagir,
  escuro,
  vertical,
}: {
  reacoes: TReacoes;
  minhas: ReacaoTipo[];
  aoReagir: (t: ReacaoTipo) => void;
  escuro?: boolean;
  vertical?: boolean;
}) {
  return (
    <View style={[estilos.linha, vertical && { flexDirection: 'column', gap: 14 }]}>
      {REACOES.map((r) => {
        const ativa = minhas.includes(r.tipo);
        const corBase = escuro ? '#FFFFFF' : cores.tintaSuave;
        return (
          <Pressable
            key={r.tipo}
            onPress={() => {
              Haptics.selectionAsync().catch(() => {});
              aoReagir(r.tipo);
            }}
            accessibilityRole="button"
            accessibilityState={{ selected: ativa }}
            accessibilityLabel={`${r.rotulo}, ${reacoes[r.tipo]}`}
            style={[
              estilos.botao,
              vertical && estilos.vertical,
              escuro && { backgroundColor: 'rgba(0,0,0,0.35)', borderColor: 'transparent' },
              ativa && !escuro && { backgroundColor: cores.lilasClaro, borderColor: cores.lilas },
            ]}
          >
            <Icone nome={ativa ? r.icone : (`${r.icone}-outline` as typeof r.icone)} tamanho={vertical ? 24 : 16} cor={ativa ? (escuro ? '#E6D6FF' : cores.lilas) : corBase} />
            <Text style={[estilos.texto, { color: ativa ? (escuro ? '#E6D6FF' : cores.lilas) : corBase }]}>
              {vertical ? reacoes[r.tipo] : `${r.rotulo}${reacoes[r.tipo] ? ` · ${reacoes[r.tipo]}` : ''}`}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const estilos = StyleSheet.create({
  linha: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  botao: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: raio.pilula,
    borderWidth: 1,
    borderColor: cores.linha,
  },
  vertical: { flexDirection: 'column', paddingHorizontal: 8, paddingVertical: 8, borderRadius: 30, gap: 2 },
  texto: { fontFamily: fontes.textoMedio, fontSize: 13.5 },
});
