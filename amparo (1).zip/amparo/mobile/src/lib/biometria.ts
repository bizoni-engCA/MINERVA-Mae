import { Platform } from 'react-native';
import * as LocalAuthentication from 'expo-local-authentication';

export async function biometriaDisponivel() {
  if (Platform.OS === 'web') return false;
  try {
    return (await LocalAuthentication.hasHardwareAsync()) && (await LocalAuthentication.isEnrolledAsync());
  } catch {
    return false;
  }
}

export async function autenticarComBiometria(mensagem = 'Desbloquear') {
  try {
    const r = await LocalAuthentication.authenticateAsync({ promptMessage: mensagem, cancelLabel: 'Usar PIN', disableDeviceFallback: true });
    return r.success;
  } catch {
    return false;
  }
}
