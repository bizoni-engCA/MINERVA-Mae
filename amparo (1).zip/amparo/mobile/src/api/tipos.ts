export type Papel = 'USUARIA' | 'MODERADORA' | 'ACOLHIMENTO' | 'ADMIN';
export type ReacaoTipo = 'APOIO' | 'ME_IDENTIFICO' | 'FORCA';
export type ConteudoStatus = 'PUBLICADO' | 'EM_REVISAO' | 'REJEITADO' | 'REMOVIDO';
export type CasoStatus = 'REGISTRADO' | 'COMPARTILHADO' | 'EM_ACOMPANHAMENTO' | 'ENCAMINHADO' | 'ENCERRADO';

export type Usuaria = { id: string; apelido: string; papel: Papel; vinculoTipo: string; criadoEm: string };
export type Sessao = { usuaria: Usuaria; tokenAcesso: string; tokenRenovacao: string };
export type Pagina<T> = { itens: T[]; proximoCursor: string | null };
export type Autoria = { apelido: string; anonimo: boolean };
export type Reacoes = Record<ReacaoTipo, number>;

export type Comunidade = {
  id: string;
  slug: string;
  nome: string;
  descricao: string;
  regras: string | null;
  icone: string;
  cor: string;
  membros: number;
  relatos: number;
  souMembro: boolean;
};

export type Post = {
  id: string;
  titulo: string;
  corpo: string;
  sensivel: boolean;
  publicadoEm: string;
  comunidade: { id: string; slug: string; nome: string; cor: string; icone: string };
  autoria: Autoria;
  reacoes: Reacoes;
  minhasReacoes: ReacaoTipo[];
  totalComentarios: number;
  souAutora: boolean;
  status?: ConteudoStatus;
  visibilidade?: 'PUBLICO' | 'SO_MODERACAO';
  motivoModeracao?: string | null;
  respostaModeracao?: string | null;
  respondidoEm?: string | null;
  temDetalhesModeracao?: boolean;
};

export type Comentario = {
  id: string;
  corpo: string;
  criadoEm: string;
  autoria: Autoria;
  autoraDoRelato: boolean;
  souAutora: boolean;
  status?: ConteudoStatus;
  motivoModeracao?: string | null;
};

export type AlertaIdentificacao = { tipo: string; trecho: string; mensagem: string };

export type Video = {
  id: string;
  titulo: string;
  descricao: string | null;
  sensivel: boolean;
  duracaoSeg: number | null;
  publicadoEm: string;
  autoria: Autoria;
  reacoes: Reacoes;
  minhasReacoes: ReacaoTipo[];
  souAutora: boolean;
  url: string;
  capaUrl: string | null;
  status?: ConteudoStatus;
  motivoModeracao?: string | null;
};

export type DadosCaso = {
  titulo: string;
  relato: string;
  dataOcorrido?: string;
  periodo?: string;
  local?: string;
  tiposViolencia: string[];
  vinculoAutor?: string;
  pessoasEnvolvidas?: string;
  testemunhas?: string;
  impactos?: string;
  providenciasTomadas?: string;
  observacoes?: string;
};

export type ResumoCaso = {
  id: string;
  titulo: string;
  tiposViolencia: string[];
  status: CasoStatus;
  compartilhadoEm: string | null;
  criadoEm: string;
  atualizadoEm: string;
  totalProvas?: number;
  responsavel?: string | null;
};

export type Prova = {
  id: string;
  tipo: 'IMAGEM' | 'VIDEO' | 'AUDIO' | 'DOCUMENTO' | 'OUTRO';
  mimeType: string;
  tamanhoBytes: number;
  sha256: string;
  recebidoEm: string;
  assinatura: string;
  nomeOriginal: string;
  descricao?: string;
  dataCaptura?: string;
};

export type MensagemCaso = { id: string; daEquipe: boolean; minha: boolean; autoria: string; corpo: string; criadoEm: string };
export type EventoCaso = {
  id: string;
  tipo: string;
  daEquipe: boolean;
  detalhe: Record<string, unknown> | null;
  criadoEm: string;
  apelido: string | null;
};

export type Caso = ResumoCaso & {
  dados: DadosCaso;
  provas: Prova[];
  mensagens: MensagemCaso[];
  eventos: EventoCaso[];
  souDona: boolean;
  acessoEquipe: boolean;
};

export type Contato = {
  id: string;
  nome: string;
  descricao: string;
  categoria: 'EMERGENCIA' | 'UFRJ' | 'JURIDICO' | 'APOIO' | 'POLICIA';
  telefone?: string;
  whatsapp?: string;
  email?: string;
  site?: string;
  endereco?: string;
  horario?: string;
  fonte: string;
};

export type GuiaResumo = {
  slug: string;
  titulo: string;
  resumo: string;
  categoria: 'ACOLHIMENTO' | 'PSICOLOGICA' | 'JURIDICA' | 'DENUNCIA';
  icone: string;
  tempoLeituraMin: number;
};
export type Guia = GuiaResumo & { corpo: string; fontes: string[] };

// ── Equipe ──────────────────────────────────────────────────────
export type AutoriaModeracao = { autoraId: string; rotulo: string };

export type PostModeracao = {
  id: string;
  titulo: string;
  corpo: string;
  sensivel: boolean;
  anonimo: boolean;
  status: ConteudoStatus;
  visibilidade: 'PUBLICO' | 'SO_MODERACAO';
  alertas: string[];
  detalhesModeracao: string | null;
  respostaModeracao: string | null;
  criadoEm: string;
  comunidade: { id: string; nome: string; cor: string };
  autoria: AutoriaModeracao;
  sinalizacoes: number;
};

export type ComentarioModeracao = {
  id: string;
  corpo: string;
  alertas: string[];
  criadoEm: string;
  post: { id: string; titulo: string };
  autoria: AutoriaModeracao;
  sinalizacoes: number;
};

export type VideoModeracao = {
  id: string;
  titulo: string;
  descricao: string | null;
  sensivel: boolean;
  duracaoSeg: number | null;
  tamanhoBytes: number;
  criadoEm: string;
  autoria: AutoriaModeracao;
  url: string;
  capaUrl: string | null;
};

export type GrupoSinalizacao = {
  alvoId: string;
  alvoTipo: 'POST' | 'COMENTARIO' | 'VIDEO';
  total: number;
  motivos: { id: string; motivo: string; detalhes: string | null; criadoEm: string }[];
  conteudo: { titulo: string; texto: string; status: string; postId?: string; url?: string };
};

export type ResumoEquipe = {
  papel: Papel;
  moderacao: {
    relatosEmRevisao: number;
    relatosSoModeracao: number;
    comentariosEmRevisao: number;
    videosEmRevisao: number;
    sinalizacoesAbertas: number;
  } | null;
  acolhimento: { casosAguardando: number; casosEmAcompanhamento: number; meusCasos: number } | null;
};
