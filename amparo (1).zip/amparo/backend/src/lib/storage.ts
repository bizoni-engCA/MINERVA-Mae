/**
 * Armazenamento de arquivos em disco local (MVP).
 * Para produção, troque por um bucket S3/MinIO mantendo esta mesma interface.
 */
import { createReadStream, createWriteStream } from 'node:fs';
import { mkdir, rm, stat } from 'node:fs/promises';
import { dirname, join, resolve, sep } from 'node:path';
import { config } from '../config';

const RAIZ = resolve(config.STORAGE_DIR);

function caminho(chave: string) {
  const p = resolve(join(RAIZ, chave));
  if (!p.startsWith(RAIZ + sep)) throw new Error('Chave de armazenamento inválida');
  return p;
}

export const storage = {
  raiz: RAIZ,
  async abrirEscrita(chave: string) {
    const p = caminho(chave);
    await mkdir(dirname(p), { recursive: true });
    return createWriteStream(p, { mode: 0o600 });
  },
  abrirLeitura(chave: string, intervalo?: { start: number; end: number }) {
    return createReadStream(caminho(chave), intervalo);
  },
  async tamanho(chave: string) {
    return (await stat(caminho(chave))).size;
  },
  async existe(chave: string) {
    try {
      await stat(caminho(chave));
      return true;
    } catch {
      return false;
    }
  },
  async apagar(chave: string) {
    await rm(caminho(chave), { force: true });
  },
  caminhoLocal: caminho,
};
