/**
 * Filtro heurístico que procura trechos que possam identificar pessoas
 * (nomes, cargos + nome, códigos de disciplina, e-mails, telefones, perfis).
 *
 * Não bloqueia nada: relatos com alertas vão para revisão da moderação antes
 * de aparecerem. Falsos positivos só atrasam a publicação.
 *
 * O app usa este mesmo filtro pela rota POST /api/posts/verificar-texto para avisar antes de enviar.
 */

export type AlertaIdentificacao = { tipo: string; trecho: string; mensagem: string };

const PERMITIDAS = new Set(
  `ufrj fundão fundao praia vermelha cidade universitária universitaria ilha governador rio janeiro
  macaé macae caxias campus bandejão bandejao restaurante universitário universitario alojamento biblioteca
  centro instituto escola faculdade departamento reitoria prefeitura siga intranet sigaa moodle
  whatsapp instagram twitter tiktok discord telegram google zoom teams meet youtube facebook
  deus brasil segunda terça terca quarta quinta sexta sábado sabado domingo
  fevereiro março marco abril maio junho julho agosto setembro outubro novembro dezembro
  enem sisu dce amparo letras medicina direito engenharia psicologia história historia química quimica
  física fisica matemática matematica biologia comunicação comunicacao música musica belas artes
  educação educacao economia administração administracao enfermagem odontologia farmácia farmacia
  arquitetura geografia filosofia ciências ciencias sociais computação computacao nutrição nutricao
  pós pos graduação graduacao mestrado doutorado iniciação iniciacao científica cientifica
  coppe poli ifcs cfch ccs cct cla ccje ccmn igeo eba fau fnd eci eef ipub nutes coppead
  ouvidoria defensoria delegacia deam polícia policia civil militar ministério ministerio público publico
  lei maria penha ligue cvv sus caps cras creas`.split(/\s+/).filter(Boolean),
);

/** Cargos e tratamentos que, seguidos de um nome, identificam a pessoa. */
const CARGOS = new Set(
  `prof profa professor professora dr dra doutor doutora coordenador coordenadora orientador orientadora
  coorientador coorientadora diretor diretora chefe técnico técnica tecnico tecnica monitor monitora reitor reitora
  decano decana tutor tutora segurança seguranca veterano veterana calouro caloura colega seu dona tio tia mestre
  pesquisador pesquisadora supervisor supervisora`.split(/\s+/).filter(Boolean),
);

const NOME = '\\p{Lu}[\\p{Ll}\\p{M}]+(?:[-\'][\\p{Lu}\\p{Ll}][\\p{Ll}]*)?';

const REGRAS: { tipo: string; mensagem: string; regex: RegExp; grupo?: number; checarPermitida?: boolean }[] = [
  {
    tipo: 'NOME_PROPRIO',
    mensagem: 'Possível nome de pessoa',
    // "o Carlos", "pela Fernanda", "com o Pedro"
    regex: new RegExp(`(?<=\\s|^)(?:o|a|pelo|pela|do|da|ao|à|com o|com a|que o|que a)\\s+(${NOME})\\b`, 'gu'),
    grupo: 1,
    checarPermitida: true,
  },
  {
    tipo: 'CODIGO_DISCIPLINA',
    mensagem: 'Código de disciplina ou turma',
    regex: /\b[A-Z]{3}\s?\d{3}\b/g,
  },
  {
    tipo: 'EMAIL',
    mensagem: 'Endereço de e-mail',
    regex: /[\w.+-]+@[\w-]+\.[\w.-]+/g,
  },
  {
    tipo: 'TELEFONE',
    mensagem: 'Número de telefone',
    regex: /\(?\b\d{2}\)?\s?9\d{4}[-\s]?\d{4}\b|\b9?\d{4}-\d{4}\b/g,
  },
  {
    tipo: 'PERFIL',
    mensagem: 'Perfil de rede social',
    regex: /(?:^|\s)@[\w.]{3,}|(?:instagram|twitter|x|tiktok|facebook|linkedin)\.com\/[\w.]+/gi,
  },
  {
    tipo: 'MATRICULA',
    mensagem: 'Número de matrícula (DRE/SIAPE) ou documento',
    regex: /\b\d{7,11}\b/g,
  },
];

/** Encontra sequências de 2+ palavras com inicial maiúscula fora do início da frase (ex.: "Ana Souza"). */
function nomesCompostos(texto: string): AlertaIdentificacao[] {
  const alertas: AlertaIdentificacao[] = [];
  const frases = texto.split(/(?<=[.!?…:\n])\s+/u);
  const conector = /^(?:da|de|do|das|dos|e)$/u;
  const maiuscula = new RegExp(`^${NOME}$`, 'u');
  for (const frase of frases) {
    const palavras = frase.split(/\s+/u).map((p) => p.replace(/[,;!?.()"“”]+$/u, ''));
    let atual: string[] = [];
    const fechar = () => {
      const reais = atual.filter((p) => !conector.test(p));
      if (reais.length >= 2 && !reais.every((p) => PERMITIDAS.has(p.toLowerCase()))) {
        alertas.push({ tipo: 'NOME_COMPLETO', trecho: atual.join(' '), mensagem: 'Possível nome completo' });
      }
      atual = [];
    };
    palavras.forEach((p, i) => {
      if (i > 0 && maiuscula.test(p)) atual.push(p);
      else if (atual.length && conector.test(p)) atual.push(p);
      else fechar();
    });
    fechar();
  }
  return alertas;
}

/** "prof. Carlos", "a orientadora Mariana", "Seu Zé"… (sem flag "i" para não perder a maiúscula do nome). */
function cargosComNome(texto: string): AlertaIdentificacao[] {
  const regex = new RegExp(`(?<![\\p{L}])(\\p{L}+)\\.?\\s+(${NOME}(?:\\s+${NOME})*)`, 'gu');
  const alertas: AlertaIdentificacao[] = [];
  for (const m of texto.matchAll(regex)) {
    if (!CARGOS.has(m[1].toLowerCase())) continue;
    const nome = m[2];
    if (nome.split(/\s+/).every((p) => PERMITIDAS.has(p.toLowerCase()))) continue;
    alertas.push({ tipo: 'CARGO_E_NOME', trecho: nome, mensagem: 'Cargo ou tratamento seguido de nome' });
  }
  return alertas;
}

export function detectarIdentificacao(texto: string): AlertaIdentificacao[] {
  const achados: AlertaIdentificacao[] = [...cargosComNome(texto)];
  for (const regra of REGRAS) {
    for (const m of texto.matchAll(regra.regex)) {
      const trecho = (regra.grupo ? m[regra.grupo] : m[0])?.trim();
      if (!trecho) continue;
      if (regra.checarPermitida && trecho.split(/\s+/).every((p) => PERMITIDAS.has(p.toLowerCase()))) continue;
      achados.push({ tipo: regra.tipo, trecho, mensagem: regra.mensagem });
    }
  }
  achados.push(...nomesCompostos(texto));

  const vistos = new Set<string>();
  return achados.filter((a) => {
    const k = a.trecho.toLowerCase();
    if (vistos.has(k)) return false;
    vistos.add(k);
    return true;
  });
}

export const resumoAlertas = (alertas: AlertaIdentificacao[]) =>
  alertas.map((a) => `${a.mensagem}: "${a.trecho}"`);
