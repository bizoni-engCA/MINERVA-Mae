import type { ComponentProps, ReactNode } from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
  type StyleProp,
  type TextInputProps,
  type TextStyle,
  type ViewStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { cores, espaco, fontes, raio, tamanhos } from '@/theme';

export type NomeIcone = ComponentProps<typeof Ionicons>['name'];
export const Icone = ({ nome, tamanho = 20, cor = cores.tinta }: { nome: NomeIcone; tamanho?: number; cor?: string }) => (
  <Ionicons name={nome} size={tamanho} color={cor} />
);

// ── Texto ─────────────────────────────────────────────────────────
type TextoProps = ComponentProps<typeof Text> & { cor?: string; centro?: boolean };

export const Titulo = ({ style, cor, centro, nivel = 1, ...p }: TextoProps & { nivel?: 1 | 2 | 3 }) => {
  return (
    <Text
      accessibilityRole="header"
      {...p}
      style={[
        estilos.titulo,
        nivel === 2 && estilos.titulo2,
        nivel === 3 && estilos.titulo3,
        cor ? { color: cor } : null,
        centro ? { textAlign: 'center' } : null,
        style,
      ]}
    />
  );
};

export const Texto = ({ style, cor, centro, fraco, pequeno, negrito, ...p }: TextoProps & { fraco?: boolean; pequeno?: boolean; negrito?: boolean }) => (
  <Text
    {...p}
    style={[
      estilos.texto,
      fraco && { color: cores.nevoa },
      pequeno && { fontSize: tamanhos.pequeno, lineHeight: 20 },
      negrito && { fontFamily: fontes.textoNegrito },
      cor ? { color: cor } : null,
      centro ? { textAlign: 'center' } : null,
      style,
    ]}
  />
);

// ── Estrutura ─────────────────────────────────────────────────────
export function Tela({
  children,
  rolar = true,
  semMargem,
  estilo,
  rodape,
}: {
  children: ReactNode;
  rolar?: boolean;
  semMargem?: boolean;
  estilo?: StyleProp<ViewStyle>;
  rodape?: ReactNode;
}) {
  const insets = useSafeAreaInsets();
  const conteudo = [estilos.tela, semMargem && { paddingHorizontal: 0 }, estilo];
  return (
    <View style={{ flex: 1, backgroundColor: cores.papel }}>
      {rolar ? (
        <ScrollView
          contentContainerStyle={[conteudo, { paddingBottom: espaco.xxl + (rodape ? 0 : insets.bottom) }]}
          keyboardShouldPersistTaps="handled"
        >
          {children}
        </ScrollView>
      ) : (
        <View style={[conteudo, { flex: 1 }]}>{children}</View>
      )}
      {rodape ? <View style={[estilos.rodape, { paddingBottom: espaco.m + insets.bottom }]}>{rodape}</View> : null}
    </View>
  );
}

export const Linha = ({ children, estilo, espacamento = espaco.s }: { children: ReactNode; estilo?: StyleProp<ViewStyle>; espacamento?: number }) => (
  <View style={[{ flexDirection: 'row', alignItems: 'center', gap: espacamento }, estilo]}>{children}</View>
);

export const Espaco = ({ altura = espaco.l }: { altura?: number }) => <View style={{ height: altura }} />;

export const Divisor = () => <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: cores.linha, marginVertical: espaco.l }} />;

/** Bloco com fundo branco — usado com parcimônia para agrupar formulários e listas. */
export const Bloco = ({ children, estilo }: { children: ReactNode; estilo?: StyleProp<ViewStyle> }) => (
  <View style={[estilos.bloco, estilo]}>{children}</View>
);

// ── Botões ────────────────────────────────────────────────────────
type Variante = 'primario' | 'secundario' | 'perigo' | 'fantasma' | 'apoio';
export function Botao({
  titulo,
  onPress,
  variante = 'primario',
  icone,
  carregando,
  desativado,
  estilo,
  compacto,
}: {
  titulo: string;
  onPress?: () => void;
  variante?: Variante;
  icone?: NomeIcone;
  carregando?: boolean;
  desativado?: boolean;
  estilo?: StyleProp<ViewStyle>;
  compacto?: boolean;
}) {
  const v = VARIANTES[variante];
  const inativo = desativado || carregando;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: inativo, busy: carregando }}
      onPress={onPress}
      disabled={inativo}
      style={({ pressed }) => [
        estilos.botao,
        compacto && estilos.botaoCompacto,
        { backgroundColor: v.fundo, borderColor: v.borda },
        pressed && { opacity: 0.8 },
        inativo && { opacity: 0.5 },
        estilo,
      ]}
    >
      {carregando ? (
        <ActivityIndicator color={v.texto} />
      ) : (
        <Linha espacamento={espaco.s}>
          {icone ? <Icone nome={icone} cor={v.texto} tamanho={compacto ? 16 : 19} /> : null}
          <Text style={[estilos.botaoTexto, compacto && { fontSize: tamanhos.pequeno }, { color: v.texto }]}>{titulo}</Text>
        </Linha>
      )}
    </Pressable>
  );
}

const VARIANTES: Record<Variante, { fundo: string; texto: string; borda: string }> = {
  primario: { fundo: cores.lilas, texto: '#FFFFFF', borda: cores.lilas },
  secundario: { fundo: cores.superficie, texto: cores.lilas, borda: cores.linha },
  perigo: { fundo: cores.superficie, texto: cores.sinal, borda: cores.sinalClaro },
  fantasma: { fundo: 'transparent', texto: cores.lilas, borda: 'transparent' },
  apoio: { fundo: cores.mata, texto: '#FFFFFF', borda: cores.mata },
};

export const BotaoIcone = ({
  icone,
  onPress,
  rotulo,
  cor = cores.tinta,
  tamanho = 22,
}: {
  icone: NomeIcone;
  onPress: () => void;
  rotulo: string;
  cor?: string;
  tamanho?: number;
}) => (
  <Pressable
    onPress={onPress}
    accessibilityRole="button"
    accessibilityLabel={rotulo}
    hitSlop={10}
    style={({ pressed }) => [{ padding: 6, borderRadius: raio.pilula }, pressed && { backgroundColor: cores.lilasClaro }]}
  >
    <Icone nome={icone} cor={cor} tamanho={tamanho} />
  </Pressable>
);

// ── Formulários ───────────────────────────────────────────────────
export function Campo({
  rotulo,
  ajuda,
  erro,
  contador,
  style,
  multiline,
  value,
  ...p
}: TextInputProps & { rotulo: string; ajuda?: string; erro?: string | null; contador?: number }) {
  {
    return (
      <View style={{ marginBottom: espaco.l }}>
        <Linha estilo={{ justifyContent: 'space-between' }}>
          <Text style={estilos.rotulo}>{rotulo}</Text>
          {contador ? (
            <Text style={[estilos.ajuda, { marginTop: 0 }]}>
              {String(value ?? '').length}/{contador}
            </Text>
          ) : null}
        </Linha>
        <TextInput
          placeholderTextColor={cores.nevoa}
          multiline={multiline}
          value={value}
          maxLength={contador}
          accessibilityLabel={rotulo}
          accessibilityHint={ajuda}
          {...p}
          style={[estilos.campo, multiline && estilos.campoMulti, erro ? { borderColor: cores.sinal } : null, style as TextStyle]}
        />
        {erro ? <Text style={[estilos.ajuda, { color: cores.sinal }]}>{erro}</Text> : ajuda ? <Text style={estilos.ajuda}>{ajuda}</Text> : null}
      </View>
    );
  }
}

export const Interruptor = ({
  titulo,
  descricao,
  valor,
  aoMudar,
}: {
  titulo: string;
  descricao?: string;
  valor: boolean;
  aoMudar: (v: boolean) => void;
}) => (
  <Pressable onPress={() => aoMudar(!valor)} style={estilos.interruptor} accessibilityRole="switch" accessibilityState={{ checked: valor }}>
    <View style={{ flex: 1, paddingRight: espaco.m }}>
      <Texto negrito>{titulo}</Texto>
      {descricao ? <Texto pequeno fraco>{descricao}</Texto> : null}
    </View>
    <Switch value={valor} onValueChange={aoMudar} trackColor={{ true: cores.lilas, false: cores.linha }} thumbColor="#FFFFFF" />
  </Pressable>
);

export const Chip = ({
  rotulo,
  ativo,
  onPress,
  cor = cores.lilas,
  icone,
}: {
  rotulo: string;
  ativo?: boolean;
  onPress?: () => void;
  cor?: string;
  icone?: NomeIcone;
}) => (
  <Pressable
    onPress={onPress}
    accessibilityRole={onPress ? 'button' : 'text'}
    accessibilityState={{ selected: ativo }}
    style={[estilos.chip, ativo ? { backgroundColor: cor, borderColor: cor } : null]}
  >
    {icone ? <Icone nome={icone} tamanho={15} cor={ativo ? '#FFF' : cor} /> : null}
    <Text style={[estilos.chipTexto, ativo ? { color: '#FFF' } : { color: cores.tintaSuave }]}>{rotulo}</Text>
  </Pressable>
);

export const Etiqueta = ({ texto, cor, fundo }: { texto: string; cor: string; fundo: string }) => (
  <View style={[estilos.etiqueta, { backgroundColor: fundo }]}>
    <Text style={[estilos.etiquetaTexto, { color: cor }]}>{texto}</Text>
  </View>
);

// ── Estados ───────────────────────────────────────────────────────
type TomAviso = 'info' | 'cuidado' | 'sucesso' | 'perigo';
const TONS: Record<TomAviso, { fundo: string; cor: string; icone: NomeIcone }> = {
  info: { fundo: cores.lilasClaro, cor: cores.tinta, icone: 'information-circle' },
  cuidado: { fundo: cores.ambarClaro, cor: '#5C3B00', icone: 'alert-circle' },
  sucesso: { fundo: cores.mataClaro, cor: '#1C4A3E', icone: 'checkmark-circle' },
  perigo: { fundo: cores.sinalClaro, cor: '#6B1F1B', icone: 'warning' },
};

export const Aviso = ({ tom = 'info', titulo, children }: { tom?: TomAviso; titulo?: string; children?: ReactNode }) => {
  const t = TONS[tom];
  return (
    <View style={[estilos.aviso, { backgroundColor: t.fundo }]} accessibilityRole="alert">
      <Icone nome={t.icone} cor={t.cor} tamanho={20} />
      <View style={{ flex: 1, gap: 2 }}>
        {titulo ? <Text style={[estilos.avisoTitulo, { color: t.cor }]}>{titulo}</Text> : null}
        {typeof children === 'string' ? <Text style={[estilos.avisoTexto, { color: t.cor }]}>{children}</Text> : children}
      </View>
    </View>
  );
};

export const Carregando = ({ texto }: { texto?: string }) => (
  <View style={estilos.centro}>
    <ActivityIndicator color={cores.lilas} size="large" />
    {texto ? <Texto fraco style={{ marginTop: espaco.m }}>{texto}</Texto> : null}
  </View>
);

export const Vazio = ({ icone, titulo, texto, acao }: { icone: NomeIcone; titulo: string; texto?: string; acao?: ReactNode }) => (
  <View style={[estilos.centro, { paddingVertical: espaco.xxl * 1.5 }]}>
    <View style={estilos.vazioIcone}>
      <Icone nome={icone} tamanho={30} cor={cores.lilas} />
    </View>
    <Titulo nivel={3} centro>
      {titulo}
    </Titulo>
    {texto ? (
      <Texto fraco centro style={{ marginTop: espaco.s, maxWidth: 320 }}>
        {texto}
      </Texto>
    ) : null}
    {acao ? <View style={{ marginTop: espaco.l }}>{acao}</View> : null}
  </View>
);

export const ErroTela = ({ mensagem, tentarDeNovo }: { mensagem: string; tentarDeNovo?: () => void }) => (
  <View style={[estilos.centro, { padding: espaco.xl }]}>
    <Icone nome="cloud-offline" tamanho={36} cor={cores.nevoa} />
    <Texto centro style={{ marginTop: espaco.m }}>
      {mensagem}
    </Texto>
    {tentarDeNovo ? <Botao titulo="Tentar de novo" variante="secundario" onPress={tentarDeNovo} estilo={{ marginTop: espaco.l }} /> : null}
  </View>
);

export const estilos = StyleSheet.create({
  tela: { paddingHorizontal: espaco.l, paddingTop: espaco.l },
  rodape: {
    paddingHorizontal: espaco.l,
    paddingTop: espaco.m,
    backgroundColor: cores.papel,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: cores.linha,
  },
  titulo: { fontFamily: fontes.titulo, fontSize: tamanhos.titulo, lineHeight: 33, color: cores.tinta, letterSpacing: -0.4 },
  titulo2: { fontSize: tamanhos.subtitulo, lineHeight: 27 },
  titulo3: { fontFamily: fontes.tituloMedio, fontSize: tamanhos.destaque, lineHeight: 24 },
  texto: { fontFamily: fontes.texto, fontSize: tamanhos.corpo, lineHeight: 24, color: cores.tinta },
  bloco: { backgroundColor: cores.superficie, borderRadius: raio.medio, padding: espaco.l, borderWidth: StyleSheet.hairlineWidth, borderColor: cores.linha },
  botao: {
    minHeight: 50,
    borderRadius: raio.medio,
    paddingHorizontal: espaco.xl,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
  },
  botaoCompacto: { minHeight: 38, paddingHorizontal: espaco.l, borderRadius: raio.pilula },
  botaoTexto: { fontFamily: fontes.textoNegrito, fontSize: tamanhos.corpo },
  rotulo: { fontFamily: fontes.textoNegrito, fontSize: tamanhos.pequeno, color: cores.tinta, marginBottom: 6 },
  ajuda: { fontFamily: fontes.texto, fontSize: tamanhos.legenda, color: cores.nevoa, marginTop: 6, lineHeight: 18 },
  campo: {
    backgroundColor: cores.superficie,
    borderWidth: 1.5,
    borderColor: cores.linha,
    borderRadius: raio.pequeno,
    paddingHorizontal: espaco.m,
    paddingVertical: 12,
    fontFamily: fontes.texto,
    fontSize: tamanhos.corpo,
    color: cores.tinta,
  },
  campoMulti: { minHeight: 140, textAlignVertical: 'top' },
  interruptor: { flexDirection: 'row', alignItems: 'center', paddingVertical: espaco.m },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: raio.pilula,
    borderWidth: 1.5,
    borderColor: cores.linha,
    backgroundColor: cores.superficie,
  },
  chipTexto: { fontFamily: fontes.textoMedio, fontSize: tamanhos.pequeno },
  etiqueta: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 3, borderRadius: raio.pilula },
  etiquetaTexto: { fontFamily: fontes.textoNegrito, fontSize: 12.5 },
  aviso: { flexDirection: 'row', gap: espaco.m, padding: espaco.m + 2, borderRadius: raio.medio, alignItems: 'flex-start' },
  avisoTitulo: { fontFamily: fontes.textoNegrito, fontSize: tamanhos.corpo },
  avisoTexto: { fontFamily: fontes.texto, fontSize: tamanhos.pequeno, lineHeight: 20 },
  centro: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: espaco.l },
  vazioIcone: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: cores.lilasClaro,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: espaco.l,
  },
});
