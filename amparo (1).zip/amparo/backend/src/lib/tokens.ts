import jwt from 'jsonwebtoken';
import { and, eq, isNull } from 'drizzle-orm';
import { config } from '../config';
import { db, schema } from '../db';
import type { Papel } from '../db/schema';
import { sha256, tokenAleatorio } from './crypto';
import { HttpError } from './errors';

const ACESSO_VALIDADE = '15m';
const REFRESH_DIAS = 30;

export type TokenAcesso = { sub: string; papel: Papel; v: number };
export type TokenVerificacao = {
  vinculoTipo: 'ESTUDANTE' | 'DOCENTE' | 'TECNICA' | 'TERCEIRIZADA';
  vinculoHash: string;
  finalidade: 'CADASTRO' | 'REDEFINIR_SENHA';
};

export const emitirAcesso = (p: TokenAcesso) =>
  jwt.sign(p, config.JWT_SECRET, { expiresIn: ACESSO_VALIDADE, audience: 'acesso', algorithm: 'HS256' });

export function lerAcesso(token: string): TokenAcesso {
  return jwt.verify(token, config.JWT_SECRET, { audience: 'acesso', algorithms: ['HS256'] }) as TokenAcesso;
}

export const emitirVerificacao = (p: TokenVerificacao) =>
  jwt.sign(p, config.JWT_SECRET, { expiresIn: '20m', audience: 'verificacao', algorithm: 'HS256' });

export function lerVerificacao(token: string, finalidade: TokenVerificacao['finalidade']): TokenVerificacao {
  try {
    const p = jwt.verify(token, config.JWT_SECRET, { audience: 'verificacao', algorithms: ['HS256'] }) as TokenVerificacao;
    if (p.finalidade !== finalidade) throw new Error('finalidade');
    return p;
  } catch {
    throw new HttpError(401, 'A verificação expirou. Confirme seu DRE novamente.', 'VERIFICACAO_EXPIRADA');
  }
}

export async function emitirSessao(usuaria: { id: string; papel: Papel; versaoToken: number }) {
  const refresh = tokenAleatorio();
  await db.insert(schema.refreshTokens).values({
    usuariaId: usuaria.id,
    tokenHash: sha256(refresh),
    expiraEm: new Date(Date.now() + REFRESH_DIAS * 24 * 3600 * 1000),
  });
  return {
    tokenAcesso: emitirAcesso({ sub: usuaria.id, papel: usuaria.papel, v: usuaria.versaoToken }),
    tokenRenovacao: refresh,
  };
}

/** Troca o refresh token por um novo (rotação). Reuso de token revogado derruba todas as sessões. */
export async function renovarSessao(refresh: string) {
  const hash = sha256(refresh);
  const [registro] = await db.select().from(schema.refreshTokens).where(eq(schema.refreshTokens.tokenHash, hash));
  if (!registro) throw new HttpError(401, 'Sessão inválida. Entre novamente.', 'SESSAO_INVALIDA');

  if (registro.revogadoEm) {
    await db
      .update(schema.refreshTokens)
      .set({ revogadoEm: new Date() })
      .where(and(eq(schema.refreshTokens.usuariaId, registro.usuariaId), isNull(schema.refreshTokens.revogadoEm)));
    throw new HttpError(401, 'Sessão encerrada por segurança. Entre novamente.', 'SESSAO_REUTILIZADA');
  }
  if (registro.expiraEm < new Date()) throw new HttpError(401, 'Sessão expirada. Entre novamente.', 'SESSAO_EXPIRADA');

  const [usuaria] = await db.select().from(schema.usuarias).where(eq(schema.usuarias.id, registro.usuariaId));
  if (!usuaria || usuaria.status !== 'ATIVA') throw new HttpError(403, 'Conta indisponível.', 'CONTA_INDISPONIVEL');

  await db.update(schema.refreshTokens).set({ revogadoEm: new Date() }).where(eq(schema.refreshTokens.id, registro.id));
  return { usuaria, ...(await emitirSessao(usuaria)) };
}

export async function revogarSessao(refresh: string) {
  await db
    .update(schema.refreshTokens)
    .set({ revogadoEm: new Date() })
    .where(eq(schema.refreshTokens.tokenHash, sha256(refresh)));
}
