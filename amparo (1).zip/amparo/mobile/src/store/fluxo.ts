import { create } from 'zustand';

/** Dados temporários entre as telas de verificação e cadastro (nunca gravados no aparelho). */
export const useFluxo = create<{ tokenVerificacao: string | null; definir: (t: string | null) => void }>((set) => ({
  tokenVerificacao: null,
  definir: (tokenVerificacao) => set({ tokenVerificacao }),
}));
