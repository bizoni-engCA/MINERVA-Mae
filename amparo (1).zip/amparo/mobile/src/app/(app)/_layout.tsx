import { Stack } from 'expo-router';
import { SaidaRapida } from '@/components/SaidaRapida';
import { opcoesCabecalho } from '@/lib/navegacao';

export const unstable_settings = { initialRouteName: '(abas)' };

export default function AppLayout() {
  return (
    <Stack screenOptions={{ ...opcoesCabecalho, headerRight: () => <SaidaRapida /> }}>
      <Stack.Screen name="(abas)" options={{ headerShown: false }} />
      <Stack.Screen name="comunidades" options={{ title: 'Subcomunidades' }} />
      <Stack.Screen name="comunidade/[slug]" options={{ title: '' }} />
      <Stack.Screen name="relato/[id]" options={{ title: 'Relato' }} />
      <Stack.Screen name="relato/novo" options={{ title: 'Novo relato', presentation: 'modal' }} />
      <Stack.Screen name="meus-relatos" options={{ title: 'Meus relatos' }} />
      <Stack.Screen name="video-novo" options={{ title: 'Compartilhar um vídeo', presentation: 'modal' }} />
      <Stack.Screen name="meus-videos" options={{ title: 'Meus vídeos' }} />
      <Stack.Screen name="caso/formulario" options={{ title: 'Registrar caso' }} />
      <Stack.Screen name="caso/[id]" options={{ title: 'Caso' }} />
      <Stack.Screen name="caso/compartilhar" options={{ title: 'Compartilhar com o acolhimento', presentation: 'modal' }} />
      <Stack.Screen name="caso/mensagens" options={{ title: 'Conversa com o acolhimento' }} />
      <Stack.Screen name="caso/prova" options={{ title: 'Adicionar prova', presentation: 'modal' }} />
      <Stack.Screen name="orientacao/index" options={{ title: 'Orientação' }} />
      <Stack.Screen name="orientacao/[slug]" options={{ title: '' }} />
      <Stack.Screen name="ajustes/index" options={{ title: 'Ajustes' }} />
      <Stack.Screen name="ajustes/disfarce" options={{ title: 'Disfarce' }} />
      <Stack.Screen name="ajustes/pin" options={{ title: 'Trocar PIN' }} />
      <Stack.Screen name="equipe/moderacao" options={{ title: 'Moderação' }} />
      <Stack.Screen name="equipe/casos" options={{ title: 'Casos compartilhados' }} />
    </Stack>
  );
}
