import { useCallback, useRef, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { Tabs } from 'expo-router/js-tabs';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useVideos } from '@/api/consultas';
import { mensagemDeErro } from '@/api/cliente';
import { ItemVideo } from '@/components/ItemVideo';
import { SaidaRapida } from '@/components/SaidaRapida';
import { Botao, Carregando, ErroTela, Icone, Vazio } from '@/components/ui';
import { cores, espaco, fontes, raio } from '@/theme';

export default function Videos() {
  const insets = useSafeAreaInsets();
  const q = useVideos();
  const [altura, setAltura] = useState(0);
  const [ativo, setAtivo] = useState(0);
  const [focada, setFocada] = useState(true);
  const itens = q.data?.pages.flatMap((p) => p.itens) ?? [];

  // Pausa tudo ao sair da aba.
  useFocusEffect(
    useCallback(() => {
      setFocada(true);
      return () => setFocada(false);
    }, []),
  );

  const aoMudarVisiveis = useRef(({ viewableItems }: { viewableItems: { index?: number | null }[] }) => {
    if (viewableItems[0]?.index != null) setAtivo(viewableItems[0].index);
  }).current;

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }} onLayout={(e) => setAltura(e.nativeEvent.layout.height)}>
      <Tabs.Screen options={{ headerShown: false }} />
      {q.isLoading || !altura ? (
        <Carregando />
      ) : q.isError ? (
        <View style={{ flex: 1, backgroundColor: cores.papel }}>
          <ErroTela mensagem={mensagemDeErro(q.error)} tentarDeNovo={q.refetch} />
        </View>
      ) : itens.length === 0 ? (
        <View style={{ flex: 1, backgroundColor: cores.papel, paddingTop: insets.top + 60 }}>
          <Vazio
            icone="play-circle-outline"
            titulo="Ainda não há vídeos publicados"
            texto="Aqui ficam relatos de quem superou uma situação de violência. Sua história pode ajudar outra pessoa a dar o primeiro passo."
            acao={<Botao titulo="Compartilhar minha história" compacto onPress={() => router.push('/video-novo')} />}
          />
        </View>
      ) : (
        <FlatList
          data={itens}
          keyExtractor={(v) => v.id}
          renderItem={({ item, index }) => <ItemVideo video={item} altura={altura} ativo={focada && index === ativo} />}
          pagingEnabled
          showsVerticalScrollIndicator={false}
          getItemLayout={(_, index) => ({ length: altura, offset: altura * index, index })}
          onViewableItemsChanged={aoMudarVisiveis}
          viewabilityConfig={{ itemVisiblePercentThreshold: 70 }}
          onEndReached={() => q.hasNextPage && !q.isFetchingNextPage && q.fetchNextPage()}
          onEndReachedThreshold={2}
          windowSize={3}
          maxToRenderPerBatch={2}
          initialNumToRender={1}
          onRefresh={() => void q.refetch()}
          refreshing={q.isRefetching}
        />
      )}

      <View style={[estilos.topo, { paddingTop: insets.top + espaco.s }]} pointerEvents="box-none">
        <Text style={[estilos.titulo, itens.length === 0 && { color: cores.tinta }]}>Vídeos</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: espaco.s }}>
          <Pressable onPress={() => router.push('/meus-videos')} style={estilos.pilula} accessibilityRole="button">
            <Text style={estilos.pilulaTexto}>Meus vídeos</Text>
          </Pressable>
          <Pressable onPress={() => router.push('/video-novo')} style={estilos.pilula} accessibilityRole="button" accessibilityLabel="Compartilhar um vídeo">
            <Icone nome="add" cor="#FFF" tamanho={18} />
          </Pressable>
          <SaidaRapida />
        </View>
      </View>
    </View>
  );
}

const estilos = StyleSheet.create({
  topo: { position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: espaco.l },
  titulo: { fontFamily: fontes.titulo, fontSize: 22, color: '#FFF' },
  pilula: { backgroundColor: 'rgba(43,27,63,0.7)', paddingHorizontal: 12, paddingVertical: 7, borderRadius: raio.pilula },
  pilulaTexto: { color: '#FFF', fontFamily: fontes.textoNegrito, fontSize: 13.5 },
});
