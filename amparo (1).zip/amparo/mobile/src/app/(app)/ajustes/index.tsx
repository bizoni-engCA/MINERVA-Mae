import { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Alert } from '@/lib/alerta';
import { router } from 'expo-router';
import { api, mensagemDeErro } from '@/api/cliente';
import { queryClient } from '@/api/consultas';
import type { Usuaria } from '@/api/tipos';
import { Markdown } from '@/components/Markdown';
import { PedirTexto } from '@/components/PedirTexto';
import { Bloco, Botao, Chip, Divisor, Icone, Interruptor, Linha, Texto, Titulo, Tela, type NomeIcone } from '@/components/ui';
import { autenticarComBiometria, biometriaDisponivel } from '@/lib/biometria';
import { nomeDoDisfarce } from '@/lib/disfarce';
import { TERMOS } from '@/lib/termos';
import { useSeguranca } from '@/store/seguranca';
import { useSessao } from '@/store/sessao';
import { cores, espaco, fontes } from '@/theme';

const TEMPOS = [
  { seg: 0, rotulo: 'Na hora' },
  { seg: 30, rotulo: '30 s' },
  { seg: 120, rotulo: '2 min' },
  { seg: 300, rotulo: '5 min' },
];

export default function Ajustes() {
  const usuaria = useSessao((s) => s.usuaria);
  const seg = useSeguranca();
  const [temBiometria, setTemBiometria] = useState(false);
  const [dialogo, setDialogo] = useState<null | 'apelido' | 'excluir'>(null);
  const [termos, setTermos] = useState(false);

  useEffect(() => {
    biometriaDisponivel().then(setTemBiometria);
  }, []);

  async function sair() {
    try {
      const { tokenRenovacao } = useSessao.getState();
      if (tokenRenovacao) await api('/api/auth/sair', { corpo: { tokenRenovacao } }).catch(() => {});
    } finally {
      queryClient.clear();
      await useSeguranca.getState().apagarTudo();
      await useSessao.getState().limpar();
    }
  }

  return (
    <Tela>
      <Titulo nivel={2}>Conta</Titulo>
      <Bloco estilo={{ marginTop: espaco.m }}>
        <Linha estilo={{ justifyContent: 'space-between' }}>
          <View>
            <Texto pequeno fraco>
              Apelido
            </Texto>
            <Texto negrito>{usuaria?.apelido}</Texto>
          </View>
          <Botao titulo="Mudar" variante="secundario" compacto onPress={() => setDialogo('apelido')} />
        </Linha>
        {usuaria && usuaria.papel !== 'USUARIA' ? (
          <Texto pequeno fraco style={{ marginTop: espaco.s }}>
            Você faz parte da equipe ({usuaria.papel === 'MODERADORA' ? 'moderação' : usuaria.papel === 'ACOLHIMENTO' ? 'acolhimento' : 'administração'}).
          </Texto>
        ) : null}
      </Bloco>

      <Titulo nivel={2} style={{ marginTop: espaco.xl }}>
        Segurança
      </Titulo>
      <Bloco estilo={{ marginTop: espaco.m }}>
        <ItemNavegacao icone="shapes-outline" titulo="Disfarce do app" detalhe={nomeDoDisfarce(seg.disfarce)} onPress={() => router.push('/ajustes/disfarce')} />
        <ItemNavegacao icone="keypad-outline" titulo="Trocar PIN" onPress={() => router.push('/ajustes/pin')} />
        {temBiometria ? (
          <Interruptor
            titulo="Desbloquear com biometria"
            valor={seg.biometria}
            aoMudar={async (v) => seg.atualizar({ biometria: v ? await autenticarComBiometria('Confirme para ativar') : false })}
          />
        ) : null}
        <Interruptor
          titulo="Abrir sempre como calculadora"
          descricao="Para entrar, digite o PIN na calculadora e toque em “=”."
          valor={seg.abrirComoCalculadora}
          aoMudar={(v) => seg.atualizar({ abrirComoCalculadora: v })}
        />
        <Texto negrito style={{ marginTop: espaco.m }}>
          Bloquear quando sair do app
        </Texto>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: espaco.s, marginTop: espaco.s }}>
          {TEMPOS.map((t) => (
            <Chip key={t.seg} rotulo={t.rotulo} ativo={seg.bloqueioAutomaticoSeg === t.seg} onPress={() => seg.atualizar({ bloqueioAutomaticoSeg: t.seg })} />
          ))}
        </View>
      </Bloco>

      <Titulo nivel={2} style={{ marginTop: espaco.xl }}>
        Conteúdo
      </Titulo>
      <Bloco estilo={{ marginTop: espaco.m }}>
        <Interruptor
          titulo="Mostrar conteúdo sensível sem borrar"
          descricao="Relatos e vídeos marcados como sensíveis aparecem direto."
          valor={seg.mostrarSensiveis}
          aoMudar={(v) => seg.atualizar({ mostrarSensiveis: v })}
        />
      </Bloco>

      <Divisor />
      <Pressable onPress={() => setTermos(!termos)} accessibilityRole="button" accessibilityState={{ expanded: termos }}>
        <Text style={estilos.link}>{termos ? 'Esconder termos e privacidade' : 'Termos e privacidade'}</Text>
      </Pressable>
      {termos ? (
        <View style={{ marginTop: espaco.m }}>
          <Markdown texto={TERMOS} />
        </View>
      ) : null}

      <View style={{ gap: espaco.m, marginTop: espaco.xl }}>
        <Botao titulo="Sair da conta neste aparelho" variante="secundario" onPress={sair} />
        <Botao
          titulo="Encerrar sessões em todos os aparelhos"
          variante="secundario"
          onPress={() =>
            Alert.alert('Encerrar todas as sessões?', 'Use se perdeu um celular ou acha que alguém entrou na sua conta. Você também vai sair deste aparelho.', [
              { text: 'Cancelar', style: 'cancel' },
              {
                text: 'Encerrar',
                style: 'destructive',
                onPress: async () => {
                  await api('/api/eu/encerrar-sessoes', { metodo: 'POST' }).catch(() => {});
                  await sair();
                },
              },
            ])
          }
        />
        <Botao titulo="Excluir minha conta" variante="perigo" onPress={() => setDialogo('excluir')} />
      </View>

      <PedirTexto
        visivel={dialogo === 'apelido'}
        titulo="Novo apelido"
        rotulo="Apelido"
        confirmar="Salvar"
        aoFechar={() => setDialogo(null)}
        aoConfirmar={async (apelido) => {
          try {
            const u = await api<Usuaria>('/api/eu', { metodo: 'PATCH', corpo: { apelido } });
            await useSessao.getState().atualizarUsuaria(u);
            setDialogo(null);
          } catch (e) {
            Alert.alert('Não foi possível mudar', mensagemDeErro(e));
          }
        }}
      />
      <PedirTexto
        visivel={dialogo === 'excluir'}
        titulo="Excluir conta definitivamente"
        descricao="Seus relatos, comentários, vídeos, casos e provas serão apagados para sempre. Gere o dossiê dos seus casos antes, se quiser guardar uma cópia."
        rotulo="Digite sua senha para confirmar"
        confirmar="Excluir tudo"
        perigo
        senha
        aoFechar={() => setDialogo(null)}
        aoConfirmar={async (senha) => {
          try {
            await api('/api/eu', { metodo: 'DELETE', corpo: { senha } });
            setDialogo(null);
            await sair();
          } catch (e) {
            Alert.alert('Não foi possível excluir', mensagemDeErro(e));
          }
        }}
      />
    </Tela>
  );
}

const ItemNavegacao = ({ icone, titulo, detalhe, onPress }: { icone: NomeIcone; titulo: string; detalhe?: string; onPress: () => void }) => (
  <Pressable onPress={onPress} style={({ pressed }) => [estilos.item, pressed && { opacity: 0.7 }]} accessibilityRole="button">
    <Icone nome={icone} cor={cores.lilas} />
    <Texto negrito style={{ flex: 1 }}>
      {titulo}
    </Texto>
    {detalhe ? <Texto fraco>{detalhe}</Texto> : null}
    <Icone nome="chevron-forward" cor={cores.nevoa} tamanho={18} />
  </Pressable>
);

const estilos = StyleSheet.create({
  item: { flexDirection: 'row', alignItems: 'center', gap: espaco.m, paddingVertical: espaco.m },
  link: { fontFamily: fontes.textoNegrito, color: cores.lilas, fontSize: 15 },
});
